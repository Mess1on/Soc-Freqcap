/*
 * socfreqd.c — Soc智能限频 守护进程
 *
 * 常态按百分比封顶 CPU 各簇与 GPU；检测到游戏在前台时解除封顶，
 * 并把相关节点权限放宽交还系统调度，让厂商框架真正接管。
 *
 * 构建：aarch64-linux-android21-clang -O2 -static -o socfreqd socfreqd.c
 * 只依赖 libc，无第三方库。
 */
#define _GNU_SOURCE
#include <ctype.h>
#include <dirent.h>
#include <fcntl.h>
#include <signal.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/file.h>
#include <sys/prctl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
#include <stdint.h>
#include <sys/system_properties.h>
#include <unistd.h>

/* icon.c：取应用图标，与限频逻辑无关，只在 icon 子命令里调用。
   want = 已确定的图标条目名（appinfo.c 从 manifest+arsc 读出），
   给了就直接按它取，不给则走按名字打分、按尺寸猜测的流程。 */
int icon_from_apk(const char *apk, const char *want);
/* score 子命令：stdin 收条目名，stdout 打 "分数\t名字"，给 api.sh 的
   unzip 兜底挑图用。挑图规则只在 icon.c 的 score_name 一处实现
   （score_name 是 static，实现在 icon.c）。 */
int icon_score_stdin(void);
/* appinfo.c：从 APK 里读「应用名」和「声明的桌面图标路径」。
   同样和限频逻辑无关，只在 label / labels / iconpath 三个子命令里用到。 */
int appinfo_label(const char *apk, char *out, size_t osz);
int appinfo_iconpath(const char *apk, char *out, size_t osz);
int appinfo_labels_stdin(void);
/* adapt.c：三个实时传感器（PSI / 温度 / 充电态）合成一个"封顶偏移"。
   偏移只加在生效值上，从不写配置 —— 见 adapt.h。 */
#include "adapt.h"

#ifndef SF_MODDIR
#define SF_MODDIR "/data/adb/modules/soc_freqcap"
#endif
/* 可变状态的家。**不能放在模块目录里**：管理器升级模块会重建
 * /data/adb/modules/<id>，配置和名单放在里面会被新包默认值覆盖。
 * 也不放 /sdcard：那是 FUSE/sdcardfs，root 直接写 /data/media/0 会绕过
 * MediaProvider（文件管理器看不见、时间戳错乱），读取还要处理 sdcardfs
 * 的 SELinux 标签。/data/adb 下的同级目录既在升级范围之外，又是 root
 * 私有的普通 ext4。 */
#ifndef SF_DATADIR
#define SF_DATADIR "/data/adb/soc_freqcap"
#endif
#ifndef SF_VERSION
#define SF_VERSION "2.3"
#endif

/* policy 的容器目录。里面只有 policyN/ 子目录，没有 cpuN/。
 * 逐核路径要用 CPUBASE，见 core_exists 的注释。 */
#define CPUFREQ "/sys/devices/system/cpu/cpufreq"
/* 核心的容器目录。逐核路径是 CPUBASE "/cpuN/cpufreq/..."。 */
#define CPUBASE "/sys/devices/system/cpu"
#define RUN_DIR   SF_DATADIR "/run"
/* 运行态文件放 /dev 内存盘：心跳/状态/逐核窗口每轮都在写，落在 F2FS
 * 会周期性弄脏元数据、唤醒 UFS。账本（*.saved）和开机截止时间仍留在
 * /data：崩溃/重启后要靠它们还原节点，丢了就会把厂商节点留在模块值上。 */
#define TMP_RUN   "/dev/soc_freqcap"
#define STATE_FILE SF_DATADIR "/state"
#define LOCK_FILE SF_DATADIR "/socfreqd.lock"
#define LOG_FILE  SF_DATADIR "/socfreqd.log"
#define PAUSE_FILE SF_DATADIR "/pause"
#define NODES_JOURNAL RUN_DIR "/nodes.saved"
#define PERM_JOURNAL RUN_DIR "/perms.saved"
#define GOV_JOURNAL RUN_DIR "/govs.saved"
/* 开机满血窗口的截止秒。service.sh 写、守护读并在到点时删除。 */
#define BOOT_BOOST_FILE RUN_DIR "/boot_boost_until"
#define CFG_FILE   SF_DATADIR "/socfreq.conf"
#define GAME_LIST  SF_DATADIR "/games.txt"
/* 分应用档位：pkg=full / pkg=60 / pkg=60:40。优先级 应用专属 > 全局百分比。
 * 由 api.sh / WebUI 维护，守护只读——写的一侧有校验，读的一侧就不需要第二套。 */
#define MODE_FILE  SF_DATADIR "/app_modes.conf"
#define STATUS_FILE TMP_RUN "/status"
#define HEARTBEAT_FILE TMP_RUN "/heartbeat"
#define CORE_STATE_FILE TMP_RUN "/cores.state"
#define CORE_STATE_LOCK TMP_RUN "/cores.lock"
/* MTK 天玑（gpufreqv2）：没有 GPU devfreq，上限走 limit_table 的层约束。
 * stack_working_opp_table 是 57 档频率表，index 0=最高频；limit_table 的
 * 一行是 id/name/priority/ceiling/floor/c_enable/f_enable，写 "set id c f"。
 * 实测写 layer 1(DEBUG) 37/56 后 PPM Ceiling 从 24 变 37，还原正常。 */
#define MTK_LIMIT   "/proc/gpufreqv2/limit_table"
#define MTK_OPP     "/proc/gpufreqv2/stack_working_opp_table"
#define MTK_GPU_SNAP RUN_DIR "/gpu_mtk.saved"

/* ── CPU 封顶的第二道锁（MTK PPM / 高通 msm_performance）──────────
 * 主路径仍然是 scaling_max_freq，后端只在 sysfs 写成功后再加一层
 * 厂商自己的硬限。这样巡检、回读、RESTORE 判断都不需要重写；
 * 后端写失败只记录并继续用 sysfs，不让封顶整体失效。
 *
 * PPM 节点是 proc 命令节点，不能塞进 nodes.saved 的 path=value 账本：
 *   - ppm.saved 记每个 cluster 的原值（/data，重启后还能还原）
 *   - ppm.last  记我们最后写入值（tmpfs，进程崩溃后还能判断是不是我们写的）
 * 恢复原则：只撤自己写的；厂商已经改过的值不动。
 */
#define PPM_DIR        "/proc/ppm"
#define PPM_ENABLED    "/proc/ppm/enabled"
#define PPM_MAX_NODE   "/proc/ppm/policy/hard_userlimit_max_cpu_freq"
#define PPM_MIN_NODE   "/proc/ppm/policy/hard_userlimit_min_cpu_freq"
#define PPM_JOURNAL    RUN_DIR "/ppm.saved"
#define PPM_LAST       TMP_RUN "/ppm.last"

#define MSM_MAX_NODE   "/sys/module/msm_performance/parameters/cpu_max_freq"
#define MSM_MAX_ALT    "/sys/kernel/msm_performance/parameters/cpu_max_freq"
#define MSM_MIN_NODE   "/sys/module/msm_performance/parameters/cpu_min_freq"
#define MSM_MIN_ALT    "/sys/kernel/msm_performance/parameters/cpu_min_freq"
#define MSM_JOURNAL    RUN_DIR "/msm.saved"
#define MSM_LAST       TMP_RUN "/msm.last"

/* 老 MTK（无 devfreq max 节点）的 GPU 上限：写的是 OPP index，不是频率。 */
#define MTK_GED_UPBOUND "/sys/kernel/ged/hal/custom_upbound_gpu_freq"
#define MTK_OLD_OPP     "/proc/gpufreq/gpufreq_opp_dump"

enum {
  CAP_BE_AUTO = 0,
  CAP_BE_SYSFS,
  CAP_BE_PPM,
  CAP_BE_MSM,
};

#define MAX_POLICY 16
/* 核心数上限。8 核是当前主流（骁龙 8 Elite 到 8 核，天玑 9400 也 8+1）。
 * 取 16 是给"超大核独立成 policy + 小核多簇"的布局留余量，
 * 真到 16 核也不会越界，因为下面 core_exists 会挡住不存在的核。 */
#define MAX_CORES 16
#define MAX_NODE 64
#define MAX_PKG 512
#define PKG_LEN 256

/* ------------------------------------------------------------------ */
/* 配置与全局状态                                                     */
/* ------------------------------------------------------------------ */

#define SCREEN_KEEP  0   /* 熄屏不改变封顶，但按亮屏全量路径巡检（旧行为） */
#define SCREEN_UNCAP 1   /* 熄屏交还系统，轻巡检 */
#define SCREEN_CAP   2   /* 熄屏保持封顶，轻巡检（只压回被顶高的上限） */

struct cfg {
  int interval;        /* 常态巡检间隔秒 */
  /* 调度策略：0=限频（固定百分比），1=智能（按负载状态给目标）。
     smart 下 CPU_PCT_* 退化成"天花板"——状态机的目标不会超过它。 */
  int strategy;
  int grace;           /* 游戏退出宽限秒 */
  /* 动态封顶（「Boost 与压制」页，默认关）：一个开关 = 完整压制——
     亮屏常态 1s 快拍两档天花板（最优解 / 风格地板）、低载静置压下限、
     walt 拉频源中和、升频限速；交权/关闭按账本还原。 */
  int suppress;        /* 1 = 动态封顶（1s 快拍动态天花板） */
  int sup_style;       /* 0 = 均衡（地板 80%），1 = 省电（地板 70%、降档更快） */
  int gov_up_us[3];    /* 升频限速 µs：0=BIG 1=MID 2=LITTLE（100~50000） */
  int gov_down_us[3];  /* 降频限速 µs，同上 */
  /* 智能模式切前台首拍预热档：0=关，1=轻载(65%)，2=中载(85%)，3=重载(100%)。
     冷启动/首屏渲染不用等负载爬升；默认 2。 */
  int app_switch_tier;
  int pct[4];          /* big / mid2 / mid / little 封顶百分比 */
  /* 进阶最低频：每个簇的 scaling_min_freq 下限，百分比；0 = 跟随系统。 */
  int min_pct[4];
  /* M 簇封顶下限（Hz）：只作用于最低频档（2 簇机型的 LITTLE/M 簇）。
     动态封顶/智能/温控/电量偏移都不会把它的 scaling_max_freq 压到这个值以下。
     0 = 不设。用于 Find N5 这类 7 核 SM8750：M 簇只剩 5 颗，压太低会把
     任务甩给两颗 L 核，同频每瓦性能更差。 */
  int cap_floor_m;
  int gpu_pct;         /* GPU 封顶百分比 */
  int gpu_min_lock;    /* 1 = 把 GPU 下限压回最低档（devfreq 一路，非关 boost） */
  int gpu_boost_off;   /* 1 = 关掉 GPU boost 源（dcvs_boost / touch_wake / devfreq_boost） */
  int bg_light;        /* 1 = 后台分组常驻轻压制（与动态封顶无关） */
  int screen_uncap;    /* 旧键：1 = 熄屏时解除限频；仅无 SCREEN_POLICY 时参与映射 */
  int screen_policy;   /* SCREEN_KEEP / SCREEN_UNCAP */
  int soff_interval;   /* 熄屏轻巡检周期秒 */
  char screen_state_path[192]; /* 亮屏信号；空 = 启动时自动挑 */
  /* P0b：深度空闲（电流归一化后判定） */
  int idle_current_ma;
  int idle_hold_cycle;
  int idle_interval;
  int wake_delta_ma;
  char batt_current_path[192];
  int batt_current_ma_unit; /* 1 = 原始值已经是 mA；0 = µA */
  int boot_full_s;     /* 开机后满血秒数，0 = 关 */
  char governor[32];   /* 日常调速器，空 = 不干预 */
  int big_min;         /* 1 = 超大核压到最低频（不关闭核心） */
  int cpu_min_lock;    /* 1 = 常态把各簇下限压到 cpuinfo_min（有节流+退避） */
  /* CPU 封顶后端：auto=有 PPM/msm 节点就加第二道锁；sysfs=只写 sysfs；
     ppm/msm=强制指定。隐藏键，页面不摆开关。 */
  int cap_backend;
  /* 实时偏移（adapt.c）。都是"百分点"，只加在生效值上，不写回配置。 */
  struct adapt_cfg ad;
};

static struct cfg cfg;
static char g_state[16] = "normal";
/* 交还系统的原因：game / screen / boot / app。
 * state = normal | game | full：game 是游戏名单/满血应用，full 是熄屏交还。
 * 细分原因走 reason= 这个键单独报。 */
static char g_reason[16] = "-";
static char g_game[PKG_LEN];
/* 本轮读到的前台包名（不代表命中游戏名单）。
 * 状态页要它：分应用档位的入口是"当前前台是谁"，不是"在不在名单里"。 */
static char g_fg[PKG_LEN];
/* 熄屏轻巡检（SCREEN_POLICY=uncap）。g_screen_off 与封顶状态分开：
 * 熄屏时可能仍是 game 态（游戏里锁屏），不能把它冲成 full。 */
static int g_screen_off;
static char g_scr_path[192];  /* 亮屏信号文件；空 = 没有可用文件 */
static int g_scr_invert;      /* 1 = blank 语义（0=亮）；0 = 亮度（>0=亮） */
static int g_scr_bad;         /* 信号与 dumpsys 不符的次数；连续 3 次就停用 */
static int g_scr_fallback;    /* 1 = 已降级为 dumpsys，配置重载不再重新启用坏节点 */
static char g_scr_cfg_seen[192]; /* 上次 SCREEN_STATE_PATH，区分"配置没变" */
static int g_scr_check;       /* 兜底校验计数 */
static int g_soff_th;         /* 熄屏温控节拍：每 4 拍采一次 */
/* P0b：熄屏深睡。g_deep 只影响周期和电流判定；亮屏信号每轮仍读。 */
static int g_deep;
static long g_idle_ema;
static int g_idle_hold;
static int g_soff_keep;       /* 熄屏瞬间的快照应用是 pkg=keep */
static char g_soff_pkg[PKG_LEN];
static int g_have_lock;
static int g_lock_fd = -1;

static void cpu_min_patrol(void);
static void cpu_min_refresh(void);
static void cpu_min_restore_user(void);
static void cpu_min_restore(void);
static volatile sig_atomic_t g_stop;

static void load_cfg(void);

static long mono_sec(void) {
  struct timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return ts.tv_sec;
}

static long mono_ms(void) {
  struct timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return (long)ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
}

/* 看门狗心跳：每轮巡检写一次 mtime。service.sh 只 stat 这个文件，
 * 超过动态阈值（最大睡眠 + 60s）没更新才拉起；比读锁文件 pid 更能发现"活着但卡死"。
 * 60 秒写一次就够看门狗判活，没必要每 5 秒闪一次元数据；状态变化仍由
 * publish_status 每拍发布，页面不受影响。 */
static long g_hb_at;
static void heartbeat(void) {
  long now = mono_sec();
  if (g_hb_at && now - g_hb_at < 60) return;
  char tmp[256];
  snprintf(tmp, sizeof tmp, "%s.tmp", HEARTBEAT_FILE);
  FILE *f = fopen(tmp, "w");
  if (!f) return;
  fprintf(f, "%ld\n", now);
  fclose(f);
  rename(tmp, HEARTBEAT_FILE);
  g_hb_at = now;
}

/* ------------------------------------------------------------------ */
/* 日志                                                               */
/* ------------------------------------------------------------------ */

static int g_logfd = -1;
static unsigned g_logcount;

static void log_open(void) {
  /*
   * 只追加，不截断。卸载路径也会走到这里，保留已收集的诊断日志。
   */
  g_logfd = open(LOG_FILE, O_WRONLY | O_CREAT | O_APPEND, 0644);
}

/* 每 64 次才量一次大小，超 256KB 就砍掉旧的一半，避免长跑撑爆存储。
 *
 * 为什么是"写临时文件 + rename"，不是 ftruncate：
 *   1) 要留的是**新的一半**。ftruncate(fd, size/2) 砍的是尾部，
 *      留下的全是开机那阵的旧内容；再叠加 O_APPEND 之后新行全写在旧内容后面，
 *      于是每次裁剪都把新日志丢掉、文件永远停在开机时刻，等于日志冻住了。
 *      service.sh 裁自己的日志用的是 tail -c 131072，同一个口径。
 *   2) 不能拿 O_RDWR 的 fd 去 dup2 覆盖 g_logfd：dup2 只复制 fd 号，
 *      复制不过来 O_APPEND，偏移还会归零。之后每行日志都从文件头开始盖，
 *      把刚留下的那一半反复覆盖掉。所以裁剪完必须重新 log_open()，
 *      走同一条带 O_APPEND 的路。
 *
 * shortcut: 不加文件锁。action.sh 也会往同一个文件追加（>> socfreqd.log），
 * 它持有的旧 fd 在 rename 之后指向被换掉的 inode，那一两行会丢。
 * 丢的是日志不是状态，为一个 append 上锁不值得。
 */
static void log_trim(void) {
  if (++g_logcount % 64) return;
  struct stat st;
  if (fstat(g_logfd, &st) || st.st_size < 256 * 1024) return;
  char tmp[sizeof LOG_FILE + 8];
  snprintf(tmp, sizeof tmp, "%s.trim", LOG_FILE);
  int in = open(LOG_FILE, O_RDONLY);
  if (in < 0) return;
  off_t skip = st.st_size / 2;
  if (lseek(in, skip, SEEK_SET) != skip) { close(in); return; }
  int out = open(tmp, O_WRONLY | O_CREAT | O_TRUNC, 0644);
  if (out < 0) { close(in); return; }
  char buf[4096];
  ssize_t r = 0;
  while ((r = read(in, buf, sizeof buf)) > 0) {
    if (write(out, buf, r) != r) { r = -1; break; }
  }
  close(in);
  if (close(out) != 0 || r < 0) { unlink(tmp); return; }
  if (rename(tmp, LOG_FILE) != 0) { unlink(tmp); return; }
  close(g_logfd);
  g_logfd = -1;
  log_open();
}

static void logf_(const char *fmt, ...) {
  if (g_logfd < 0) return;
  char buf[512];
  time_t t = time(NULL);
  struct tm tm;
  localtime_r(&t, &tm);
  int n = snprintf(buf, sizeof buf, "[%02d:%02d:%02d] ", tm.tm_hour, tm.tm_min,
                   tm.tm_sec);
  va_list ap;
  va_start(ap, fmt);
  n += vsnprintf(buf + n, sizeof buf - n, fmt, ap);
  va_end(ap);
  if (n > (int)sizeof buf - 2) n = sizeof buf - 2;
  buf[n++] = '\n';
  ssize_t w = write(g_logfd, buf, n);
  (void)w;
  log_trim();
}

#define log(...) logf_(__VA_ARGS__)

/* ------------------------------------------------------------------ */
/* sysfs 基础读写                                                     */
/* ------------------------------------------------------------------ */

static int read_file(const char *path, char *buf, size_t len) {
  int fd = open(path, O_RDONLY);
  if (fd < 0) return -1;
  ssize_t n = read(fd, buf, len - 1);
  close(fd);
  if (n <= 0) return -1;
  buf[n] = 0;
  while (n > 0 && strchr(" \t\r\n", buf[n - 1])) buf[--n] = 0;
  return 0;
}

static long read_num(const char *path) {
  char b[64];
  if (read_file(path, b, sizeof b) || !isdigit((unsigned char)b[0])) return -1;
  return strtol(b, NULL, 10);
}

/* 配置文件指纹：秒级 mtime 会让"同一秒连写两次"漏重载；带上纳秒、
   大小和 inode（tmp+mv 原子替换后 inode 必变）。 */
static uint64_t file_stamp(const char *path) {
  struct stat st;
  if (stat(path, &st)) return 0;
  uint64_t ns = (uint64_t)st.st_mtim.tv_sec * 1000000000ULL +
                (uint64_t)st.st_mtim.tv_nsec;
  return ns ^ ((uint64_t)st.st_size << 32) ^ (uint64_t)st.st_ino;
}

/* procfs 命令节点（limit_table）：一次写一整行，不截断。 */
static int write_text(const char *path, const char *s) {
  int fd = open(path, O_WRONLY);
  if (fd < 0) return -1;
  size_t len = strlen(s);
  ssize_t n = write(fd, s, len);
  close(fd);
  return (n == (ssize_t)len) ? 0 : -1;
}

/* 普通文件快照：需要截断旧内容。 */
static int write_text_file(const char *path, const char *s) {
  int fd = open(path, O_WRONLY | O_CREAT | O_TRUNC, 0644);
  if (fd < 0) return -1;
  size_t len = strlen(s);
  ssize_t n = write(fd, s, len);
  close(fd);
  return (n == (ssize_t)len) ? 0 : -1;
}

/* 有符号读数。battery/current_now 在充电时可能是负值（PJZ110 实测 -404），
 * 用 read_num 会把它当成"读失败"；深睡判据会因此永远不触发。 */
static int read_signed(const char *path, long *out) {
  char b[64];
  if (read_file(path, b, sizeof b)) return 0;
  char *p = b;
  while (*p && isspace((unsigned char)*p)) p++;
  if (*p != '-' && !isdigit((unsigned char)*p)) return 0;
  char *end = NULL;
  long v = strtol(p, &end, 10);
  if (end == p) return 0;
  *out = v;
  return 1;
}

/* 这个核心在不在。
 *
 * 路径必须是 /sys/devices/system/cpu/cpuN/cpufreq/...，
 * **不能**写成 CPUFREQ "/cpuN/..."：
 * CPUFREQ 是 policy 的容器目录，里面只有 policyN/，没有 cpuN/。
 * 该节点挂在 policyN/ 和 cpuN/cpufreq/ 两处，唯独不在 cpuN/ 下，
 * 写成 CPUFREQ "/cpu%d/cpuinfo_max_freq" 拼出的路径内核不提供。
 *
 * 判据用 cpuinfo_max_freq 而不是"目录在不在"：
 * 目录存在不等于能读到值，判据要的是"这颗核有真实频率"。
 */
static int core_path(char *b, size_t n, int c, const char *leaf) {
  return snprintf(b, n, CPUBASE "/cpu%d/cpufreq/%s", c, leaf);
}

static int core_exists(int c) {
  char b[96];
  core_path(b, sizeof b, c, "cpuinfo_max_freq");
  return read_num(b) > 0;
}

/* 这颗核的 cpufreq 是不是符号链接。内核会建
 * /sys/devices/system/cpu/cpuN/cpufreq → …/cpufreq/policyM，
 * 读它比解析 related_cpus 可靠：related_cpus 的格式
 * （十进制列表 还是 十六进制掩码）各内核不统一，按十进制解析
 * 遇到掩码会全解析成 0，映射整个失效且照样不报错。 */
static int core_policy_of(int c) {
  char b[96], link[160];
  /* 路径**不能带尾斜杠**。
   * 模板结尾是 "/cpu%d/cpufreq/%s"，传空 leaf 拼出来末尾会多一个 /。
   * 按 POSIX 路径解析，结尾带斜杠时最后一个分量会被穿过符号链接去解析，
   * 该路径不再命名一个符号链接，readlink() 直接失败（EINVAL）。
   * 所以这里直接写死不带斜杠的完整路径。 */
  snprintf(b, sizeof b, CPUBASE "/cpu%d/cpufreq", c);
  ssize_t k = readlink(b, link, sizeof link - 1);
  if (k <= 0) return -1;
  link[k] = 0;
  const char *s = strrchr(link, '/');
  if (!s) return -1;
  if (strncmp(s + 1, "policy", 6)) return -1;
  return atoi(s + 7);
}

/* ── 逐核频率历史 ─────────────────────────────────────────────
 * 不是频率分布直方图。每 1 秒采一次「当前频率 + 这一秒的 CPU 占用」，
 * 旧样本左移、新样本放最右；页面画 8 根柱，最右是现在。
 * 高度 = 占用百分比；窗口里最高的一根标黄。
 * 占用来自 /proc/stat 的逐核 total/idle 差值；cores 每秒一个新进程，
 * 所以上一拍计数器和 8 个样本一起落到 run/cores.state。
 */
#define CORE_HIST_N 8
struct core_hist {
  long freq[CORE_HIST_N];   /* 旧 → 新 */
  long load[CORE_HIST_N];   /* 0~100 */
  int  n;
  long prev_total, prev_idle;
  int  have_prev;
};
static struct core_hist g_ch[MAX_CORES];

static int core_load_pct(long total, long idle, long pt, long pi) {
  long dt = total - pt, di = idle - pi;
  if (dt <= 0 || di < 0) return 0;
  long v = (dt - di) * 100 / dt;
  if (v < 0) v = 0;
  if (v > 100) v = 100;
  return (int)v;
}

/* 旧样本左移，新样本放最右；第一次直接铺满 8 格，
   避免页面刚打开时只有一根柱。 */
static void core_hist_push(struct core_hist *h, long freq, long load) {
  if (h->n <= 0) {
    for (int i = 0; i < CORE_HIST_N; i++) { h->freq[i] = freq; h->load[i] = load; }
    h->n = CORE_HIST_N;
    return;
  }
  int n = h->n < CORE_HIST_N ? h->n : CORE_HIST_N - 1;
  for (int i = 0; i < n; i++) {
    h->freq[i] = h->freq[i + 1];
    h->load[i] = h->load[i + 1];
  }
  h->freq[n] = freq;
  h->load[n] = load;
  if (h->n < CORE_HIST_N) h->n++;
}

static void core_hist_range(const struct core_hist *h, long *lo, long *hi) {
  *lo = 0; *hi = 0;
  for (int i = 0; i < h->n; i++) {
    long f = h->freq[i];
    if (f <= 0) continue;
    if (!*lo || f < *lo) *lo = f;
    if (f > *hi) *hi = f;
  }
}

/* 读 /proc/stat 的 cpuN 行：total（前 8 项和）/ idle（idle+iowait）。 */
static int core_stat_read(long *total, long *idle) {
  FILE *f = fopen("/proc/stat", "r");
  if (!f) return 0;
  char line[256];
  int got = 0;
  while (fgets(line, sizeof line, f)) {
    if (strncmp(line, "cpu", 3) || line[3] < '0' || line[3] > '9') continue;
    int c = atoi(line + 3);
    if (c < 0 || c >= MAX_CORES) continue;
    long v[8] = {0};
    int k = sscanf(line, "cpu%d %ld %ld %ld %ld %ld %ld %ld %ld",
                   &c, &v[0], &v[1], &v[2], &v[3], &v[4], &v[5], &v[6], &v[7]);
    if (k < 5) continue;
    long sum = 0;
    for (int i = 0; i < 8; i++) sum += v[i];
    total[c] = sum;
    idle[c] = v[3] + v[4];
    got++;
  }
  fclose(f);
  return got;
}

/* cores 每秒是一个新进程，内存里的窗口活不过一次调用。
 * 把上一拍读数和 5 格环落到 run/cores.state（先写 tmp 再 rename），
 * 下一次调用接着算增量；页面不开就没人调用，不会后台常驻采样。
 * 用单独的 lock 文件串行化 cores / export 两个入口。 */
/* 运行态文件已迁到 /dev/soc_freqcap；旧路径留软链，
 * service.sh / api.sh / hotinstall.sh 仍按 /data/.../run/... 读，
 * 不用改一行脚本。软链只在这些路径上，账本路径不动。 */
static void tmp_link(const char *target, const char *link) {
  char cur[192];
  ssize_t n = readlink(link, cur, sizeof cur - 1);
  if (n > 0) {
    cur[n] = 0;
    if (!strcmp(cur, target)) return;
  }
  unlink(link);
  symlink(target, link);
}

static void tmp_runtime_init(void) {
  mkdir(TMP_RUN, 0700);
  mkdir(RUN_DIR, 0755);
  tmp_link(HEARTBEAT_FILE, RUN_DIR "/heartbeat");
  tmp_link(STATUS_FILE, RUN_DIR "/status");
}

static int g_core_lock_fd = -1;

static void core_state_lock(void) {
  mkdir(TMP_RUN, 0700);
  mkdir(RUN_DIR, 0755);
  g_core_lock_fd = open(CORE_STATE_LOCK, O_RDWR | O_CREAT, 0644);
  if (g_core_lock_fd >= 0) flock(g_core_lock_fd, LOCK_EX);
}
static void core_state_unlock(void) {
  if (g_core_lock_fd >= 0) {
    flock(g_core_lock_fd, LOCK_UN);
    close(g_core_lock_fd);
    g_core_lock_fd = -1;
  }
}

static void core_state_load(void) {
  FILE *f = fopen(CORE_STATE_FILE, "r");
  if (!f) return;
  char line[4096];
  /* 页面关了很久再打开时，上一拍的 /proc/stat 基线已经过期；
     直接拿几小时的差值会算出一个假占用。超过 10 秒就重立。 */
  long stamp = 0;
  if (!fgets(line, sizeof line, f) || sscanf(line, "v3 %ld", &stamp) != 1 ||
      stamp <= 0) {
    fclose(f);
    return;
  }
  long gap = mono_ms() - stamp;
  if (gap < 0 || gap > 10000) {   /* gap<0 = 重启过，monotonic 归零 */
    fclose(f);
    return;
  }
  while (fgets(line, sizeof line, f)) {
    int cid, hp, n;
    long pt, pi;
    if (sscanf(line, "C %d %d %ld %ld %d", &cid, &hp, &pt, &pi, &n) != 5) continue;
    if (cid < 0 || cid >= MAX_CORES) continue;
    struct core_hist *h = &g_ch[cid];
    memset(h, 0, sizeof *h);
    h->have_prev = hp ? 1 : 0;
    h->prev_total = pt;
    h->prev_idle = pi;
    h->n = n < 0 ? 0 : (n > CORE_HIST_N ? CORE_HIST_N : n);
    if (!fgets(line, sizeof line, f) || strncmp(line, "F ", 2)) continue;
    if (sscanf(line, "F %ld %ld %ld %ld %ld %ld %ld %ld",
               &h->freq[0], &h->freq[1], &h->freq[2], &h->freq[3],
               &h->freq[4], &h->freq[5], &h->freq[6], &h->freq[7]) != 8) {
      h->n = 0;
      continue;
    }
    if (!fgets(line, sizeof line, f) || strncmp(line, "L ", 2)) { h->n = 0; continue; }
    if (sscanf(line, "L %ld %ld %ld %ld %ld %ld %ld %ld",
               &h->load[0], &h->load[1], &h->load[2], &h->load[3],
               &h->load[4], &h->load[5], &h->load[6], &h->load[7]) != 8) {
      h->n = 0;
      continue;
    }
  }
  fclose(f);
}

static void core_state_save(void) {
  char tmp[256];
  snprintf(tmp, sizeof tmp, "%s.tmp.%d", CORE_STATE_FILE, (int)getpid());
  FILE *f = fopen(tmp, "w");
  if (!f) return;
  fprintf(f, "v3 %ld\n", mono_ms());
  for (int c = 0; c < MAX_CORES; c++) {
    struct core_hist *h = &g_ch[c];
    if (h->n <= 0 && !h->have_prev) continue;
    fprintf(f, "C %d %d %ld %ld %d\n", c, h->have_prev ? 1 : 0,
            h->prev_total, h->prev_idle, h->n);
    fprintf(f, "F %ld %ld %ld %ld %ld %ld %ld %ld\n",
            h->freq[0], h->freq[1], h->freq[2], h->freq[3],
            h->freq[4], h->freq[5], h->freq[6], h->freq[7]);
    fprintf(f, "L %ld %ld %ld %ld %ld %ld %ld %ld\n",
            h->load[0], h->load[1], h->load[2], h->load[3],
            h->load[4], h->load[5], h->load[6], h->load[7]);
  }
  fclose(f);
  rename(tmp, CORE_STATE_FILE);
}

static int write_num(const char *path, long val) {
  int fd = open(path, O_WRONLY);
  if (fd < 0) return -1;
  char b[32];
  int n = snprintf(b, sizeof b, "%ld\n", val);
  ssize_t w = write(fd, b, n);
  close(fd);
  return w == n ? 0 : -1;
}

static int write_str(const char *path, const char *val) {
  int fd = open(path, O_WRONLY);
  if (fd < 0) return -1;
  size_t l = strlen(val);
  ssize_t w = write(fd, val, l);
  close(fd);
  return w == (ssize_t)l ? 0 : -1;
}

static int read_mode(const char *path) {
  struct stat st;
  if (stat(path, &st)) return 0644;
  return st.st_mode & 07777;
}

static void trim(char *s) {
  size_t l = strlen(s);
  while (l && strchr(" \t\r\n", s[l - 1])) s[--l] = 0;
  char *p = s;
  while (*p && isspace((unsigned char)*p)) memmove(p, p + 1, strlen(p));
}

/* ------------------------------------------------------------------ */
/* journal：写之前先记账，恢复失败也不丢，下次启动再试                 */
/* ------------------------------------------------------------------ */

static int journal_has(const char *file, const char *node) {
  FILE *f = fopen(file, "r");
  if (!f) return 0;
  char line[512], p[512];
  int found = 0;
  while (fgets(line, sizeof line, f))
    if (sscanf(line, "%511s", p) == 1 && !strcmp(p, node)) {
      found = 1;
      break;
    }
  fclose(f);
  return found;
}

/* 取 journal 里这个节点记的原始权限；没有返回 -1。
 * 交还系统时要用它，不能用 read_mode()：那时节点已经被我们 chmod 成 0644，
 * 记下来的"原始权限"就成了 0644，出厂 0664（root:system 可写）的机型
 * 从此让厂商框架写不动节点。 */
static int journal_mode(const char *file, const char *node) {
  FILE *f = fopen(file, "r");
  if (!f) return -1;
  char line[512], p[512];
  long v;
  unsigned m;
  int ret = -1;
  while (fgets(line, sizeof line, f))
    if (sscanf(line, "%511s %ld %o", p, &v, &m) == 3 && !strcmp(p, node)) {
      ret = (int)m;
      break;
    }
  fclose(f);
  return ret;
}

/* 取 journal 里记的原始值；没记过返回 0。 */
static int journal_value(const char *file, const char *node, long *out) {
  FILE *f = fopen(file, "r");
  if (!f) return 0;
  char line[512], p[512];
  long v;
  unsigned m;
  int ret = 0;
  while (fgets(line, sizeof line, f))
    if (sscanf(line, "%511s %ld %o", p, &v, &m) == 3 && !strcmp(p, node)) {
      *out = v;
      ret = 1;
      break;
    }
  fclose(f);
  return ret;
}

static void journal_add(const char *file, const char *node, long val, int mode) {
  FILE *f = fopen(file, "a");
  if (!f) return;
  fprintf(f, "%s %ld %o\n", node, val, mode);
  fflush(f);
  fsync(fileno(f));
  fclose(f);
}

/* 数值节点写入：先记账原值+权限，再写。val<0 表示只记不改 */
static int write_journaled(const char *file, const char *node, long val) {
  if (access(node, F_OK)) return -1;
  if (!journal_has(file, node)) {
    long orig = read_num(node);
    if (orig < 0) return -1;
    journal_add(file, node, orig, read_mode(node));
  }
  if (val < 0) return 0;
  chmod(node, 0644);
  return write_num(node, val);
}

/* 恢复 journal 中所有数值节点；任一失败保留文件，下次启动重试 */
static int journal_restore(const char *file) {
  if (access(file, F_OK)) return 0;
  FILE *f = fopen(file, "r");
  if (!f) return -1;
  char line[512], node[512];
  long val;
  int mode, failed = 0, count = 0;
  /* 先还 max/普通节点，最后再还 min：内核要求 min <= max，
     先写回一个较高的 min 会被 -EINVAL 拒绝。 */
  for (int pass = 0; pass < 2; pass++) {
    rewind(f);
    while (fgets(line, sizeof line, f)) {
      if (sscanf(line, "%511s %ld %o", node, &val, &mode) != 3) continue;
      int is_min = strstr(node, "/scaling_min_freq") ||
                   strstr(node, "/min_freq");
      if ((pass == 1) != !!is_min) continue;
      chmod(node, 0644);
      if (write_num(node, val) || read_num(node) != val) failed = 1;
      chmod(node, mode);
      count++;
    }
  }
  fclose(f);
  if (failed) {
    log("WARN 恢复未完成（%d 节点），保留快照下次重试", count);
    return -1;
  }
  unlink(file);
  log("已恢复 %d 个节点", count);
  return 0;
}

/*
 * 只还权限，不动数值。
 *
 * 权限 journal 里的值列是占位的 0 —— 它只用来记 mode。
 * 走 journal_restore 会把 0 真的写进节点：
 *   - scaling_max_freq 收到 "0" 被内核拒 → failed → 快照永不删除
 *   - max_pwrlevel 这种 0 是合法索引值的节点，会被真的写没
 * 所以权限还原必须单开一条路径。
 */
static int perms_restore(void) {
  if (access(PERM_JOURNAL, F_OK)) return 0;
  FILE *f = fopen(PERM_JOURNAL, "r");
  if (!f) return -1;
  char line[512], node[512];
  long val;
  int mode, failed = 0, count = 0;
  while (fgets(line, sizeof line, f)) {
    if (sscanf(line, "%511s %ld %o", node, &val, &mode) != 3) continue;
    /* 节点已经没了也算处理完，不然快照永远删不掉 */
    if (access(node, F_OK)) continue;
    if (chmod(node, (mode_t)mode)) failed = 1;
    else count++;
  }
  fclose(f);
  if (failed) {
    log("WARN 权限收回未完成，保留 perms.saved 下次重试");
    return -1;
  }
  unlink(PERM_JOURNAL);
  if (count) log("已收回 %d 个节点权限", count);
  return 0;
}

/* ------------------------------------------------------------------ */
/* SoC 芯片代号                                                        */
/* ------------------------------------------------------------------ */

/*
 * 顺序不能随便换：ro.soc.model 是最准的，但只在部分机型上存在；
 * ro.board.platform 覆盖面最广，值就是芯片代号（sm8550 / mt6893…）。
 * 都取不到就回机型名，总比空着好——WebUI 顶上要显示这一行。
 */

/* 按空格/逗号/制表符切词，取最后一个词并转小写。 */
static void last_word(const char *v, char *out, size_t n) {
  const char *t = v, *tok = NULL, *end = NULL;
  for (;;) {
    while (*t == ' ' || *t == ',' || *t == '\t') t++;
    if (!*t) break;
    tok = t; /* 记词的开头 */
    while (*t && *t != ' ' && *t != ',' && *t != '\t') t++;
    end = t; /* 词尾现在就得记：外层还会把 t 推过尾部分隔符 */
  }
  if (!tok) { snprintf(out, n, ""); return; }
  size_t i = 0;
  for (; tok + i < end && i + 1 < n; i++)
    out[i] = (char)tolower((unsigned char)tok[i]);
  out[i] = 0;
}

static void read_soc_name(char *out, size_t n) {
  static const char *props[] = {"ro.soc.model", "ro.board.platform",
                                "ro.chipname", "ro.product.model"};
  snprintf(out, n, "未知");
  for (size_t i = 0; i < sizeof props / sizeof *props; i++) {
    char v[128], w[128];
    if (__system_property_get(props[i], v) <= 0) continue;
    last_word(v, w, sizeof w);
    if (w[0]) { snprintf(out, n, "%s", w); return; }
  }
}

/* ------------------------------------------------------------------ */
/* CPU policy 探测与分档                                              */
/* ------------------------------------------------------------------ */

struct policy {
  char name[32];
  char dir[160];
  long hw_max;
  long hw_min;  /* cpuinfo_min_freq：熄屏态压下限用 */
  /* 厂商出厂/原始 scaling_max_freq。普通态和智能模式的百分比都以它为顶，
     不能拿硬件最高频去算，否则会把 ColorOS 等已经压低的厂商上限又抬回去。 */
  long vendor_max;
  long cap;  /* 封顶值，已吸附到频点 */
  long pct;  /* 意图百分比（已含实时偏移前的策略目标） */
  int  tpct; /* 策略目标：cap 下 = CPU_PCT_*，smart 下 = 状态机给的值 */

  int tier;  /* 用的哪一档：0=BIG 1=MID2 2=MID 3=LITTLE，WebUI 靠它对滑杆 */
  int pol_no; /* policy 号（atoi(name+6)）。反查"某档管哪几颗核"要拿它和
               * core_policy_of(c) 比，后者来自 readlink、不是数组下标；
               * 按 hw_max 去重后下标与 policy 号不再相等，须单独保存。 */
  /* 1 = 该簇节点暂不可读（核心离线/热插拔）：巡检跳过、不刷错误日志；
     节点回来后自动清零并重新压回封顶。 */
  int offline;
  /* 最近一次模块写入的意图值和实际回读值。force 升帽前用它判断
     "当前值是模块自己写的，还是厂商压得更低"——后者不许盖掉。 */
  long last_cap;
  long last_got;
  /* 上一次"写下去没生效"的目标与回读值。内核实际下限可能比
     scaling_min_freq 读到的还高（本机 BIG_MIN 时 1,017,600 写下去
     会被夹在 1,958,400），同一目标同一读数不再每拍重写，10 分钟后再试。 */
  long unreach_cap;
  long unreach_got;
  long unreach_at;
  /* 第二道锁（PPM/MSM）：用哪条后端、PPM cluster 号、最后写入值和连续失败数。
     be_last 与 tmpfs 里的 last 文件配合，恢复时只撤自己写的值。 */
  int be;          /* CAP_BE_SYSFS / CAP_BE_PPM / CAP_BE_MSM */
  int ppm_idx;     /* PPM cluster 号，-1 = 不使用 */
  long be_last;    /* 最后写入后端的值；0 = 还没有写过 */
  int be_fail;     /* 连续写失败次数，达到阈值就停用该簇后端 */
};

static int policy_index(const char *dir) {
  const char *s = strrchr(dir, '/');
  s = s ? s + 1 : dir;
  if (strncmp(s, "policy", 6)) return 999;
  return atoi(s + 6);
}

/* 百分比按硬件最高频算，再把结果压回厂商原始上限以内。
   不能拿厂商上限当分母：那会把用户 46% 实际变成 39%，白掉一档；
   也不能完全不压：智能模式 72% 可能算到厂商上限之上，等于放松限频。 */
static long cap_from_pct(const struct policy *p, int pct) {
  long want = p->hw_max * pct / 100;
  if (p->vendor_max > 0 && want > p->vendor_max) want = p->vendor_max;
  return want;
}

/* 交还系统时写回的厂商上限；没有记录才退回硬件最高频。 */
static long cap_base(const struct policy *p) {
  if (p->vendor_max > 0 && p->vendor_max < p->hw_max) return p->vendor_max;
  return p->hw_max;
}

static void policy_vendor_max_init(struct policy *p) {
  char path[256];
  snprintf(path, sizeof path, "%s/scaling_max_freq", p->dir);
  long v = 0;
  if (journal_value(NODES_JOURNAL, path, &v) && v > 0) {
    p->vendor_max = v;
  } else {
    p->vendor_max = read_num(path);
  }
  if (p->vendor_max <= 0) p->vendor_max = p->hw_max;
  if (p->hw_max > 0 && p->vendor_max > p->hw_max) p->vendor_max = p->hw_max;
}

/* 从频点表文本里挑出 <= want 的最高频点。 */
/* 只返回真实频点；没有 <= want 的候选就返回 0。给 snap_freq 合并
 * available + boost 两张表用。 */
static long snap_best_from_list(const char *list, long want) {
  char b[4096];
  snprintf(b, sizeof b, "%s", list);
  long best = 0;
  char *save = NULL;
  for (char *t = strtok_r(b, " \t\n", &save); t; t = strtok_r(NULL, " \t\n", &save)) {
    if (!isdigit((unsigned char)*t)) continue;
    long f = strtol(t, NULL, 10);
    if (f > 0 && f <= want && f > best) best = f;
  }
  return best;
}

/* 兼容旧自检：没有候选时保留原值。snap_freq 自己用 snap_best_from_list。 */
static long __attribute__((unused)) snap_from_list(const char *list, long want) {
  long v = snap_best_from_list(list, want);
  return v > 0 ? v : want;
}

/* 把期望值吸附到 <= 它的最高可用频点：封顶语义要求实际永远不超过意图。
 * 100% 例外：直接写 cpuinfo_max_freq。部分内核把最高频（boost 频点）
 * 放在 scaling_boost_frequencies 里，available 表没有它；再向下吸附会让
 * 100% 实际变成次高频。写进去被内核夹回也没关系，回读会如实记录。
 *
 * 中间档位同时看 available 和 boost 两张表：有些内核把短时 boost 频点
 * 单独列在 scaling_boost_frequencies，只读 available 会少几个可吸附点。
 * 100% 仍以 cpuinfo_max_freq 为顶，不主动用高于它的超频点。 */
static long snap_freq(const struct policy *p, long want) {
  if (p->hw_max > 0 && want >= p->hw_max) return p->hw_max;
  char b[4096], path[224];
  long best = 0;
  snprintf(path, sizeof path, "%s/scaling_available_frequencies", p->dir);
  if (!read_file(path, b, sizeof b)) best = snap_best_from_list(b, want);
  snprintf(path, sizeof path, "%s/scaling_boost_frequencies", p->dir);
  if (!read_file(path, b, sizeof b)) {
    long v = snap_best_from_list(b, want);
    if (v > best) best = v;
  }
  return best > 0 ? best : want;
}

/* 只返回 >= want 的最小真实频点；没有就在调用处回退。 */
static long snap_up_best_from_list(const char *list, long want) {
  char b[4096];
  snprintf(b, sizeof b, "%s", list);
  long best = 0;
  char *save = NULL;
  for (char *t = strtok_r(b, " \t\n", &save); t; t = strtok_r(NULL, " \t\n", &save)) {
    if (!isdigit((unsigned char)*t)) continue;
    long f = strtol(t, NULL, 10);
    if (f >= want && (best == 0 || f < best)) best = f;
  }
  return best;
}

/* 静置上限要“向上对齐”真实频点：960MHz 不一定每颗芯片都有，
 * 向下取会白掉一档；向上取到第一个 >= 目标的频点，再受用户 cap 限制。 */
static long snap_up_freq(const struct policy *p, long want) {
  if (want <= 0) return 0;
  if (p->hw_max > 0 && want > p->hw_max) want = p->hw_max;
  char b[4096], path[224];
  long best = 0;
  snprintf(path, sizeof path, "%s/scaling_available_frequencies", p->dir);
  if (!read_file(path, b, sizeof b)) best = snap_up_best_from_list(b, want);
  snprintf(path, sizeof path, "%s/scaling_boost_frequencies", p->dir);
  if (!read_file(path, b, sizeof b)) {
    long v = snap_up_best_from_list(b, want);
    if (v > 0 && (best == 0 || v < best)) best = v;
  }
  if (!best) best = p->hw_max > 0 ? p->hw_max : want;
  if (p->cap > 0 && best > p->cap) best = snap_freq(p, p->cap);
  return best;
}

/* M 簇封顶下限：只作用于最低频档（2 簇机的 LITTLE/M 簇）。
 * 动态封顶、智能、温控、电量偏移最后都要经过这里，避免 M 簇被压到
 * 1.78GHz 以下后，调度把任务甩给两颗 L 核。0 = 不设。 */
static long cap_floor_m_for(const struct policy *p) {
  if (cfg.cap_floor_m <= 0 || (p->tier & 3) != 3) return 0;
  long f = cfg.cap_floor_m;
  if (p->hw_max > 0 && f > p->hw_max) f = p->hw_max;
  return f;
}

static long cap_floor_apply(const struct policy *p, long cap) {
  long f = cap_floor_m_for(p);
  return (f > 0 && cap < f) ? f : cap;
}

/* 收集全部 policy 目录，**不去重**，并记下 policy 号。
 * detect_policies 去重是为了得到干净的簇阶梯（封顶只需一条代表），
 * 但"某档管哪几颗核"必须按未去重的列表反查：同一硬件上限的多个
 * policy 去重后只剩一个，另一个管的核心会整档丢失。 */
/* ── 芯片适配覆盖（override.conf）───────────────────────────────
 * 有的机器节点名、目录结构和常规不一样，自动探测一个都读不到，
 * 表现就是"装上模块但看不到核心表 / GPU 不限频"。这种机器靠人工适配：
 * 让对方在页面上「导出适配包」，按包里的现场路径改出一份 override.conf，
 * 放回去重启守护即可。
 *
 * 只在自动探测拿不到结果时才用它：正常机器不读这些值，
 * 覆盖也就永远不会盖掉实测出来的东西。
 *
 * 一行一条，认这四种键（其余行忽略，方便人写注释）：
 *   cpu-dir   <目录绝对路径> <硬件最高频>
 *   gpu-max   <节点路径>
 *   gpu-min   <节点路径>
 *   gpu-freqs <空格分隔的频率表>
 */
#define OVR_FILE SF_DATADIR "/override.conf"

static char ovr_dir[MAX_POLICY][224];
static long ovr_hw[MAX_POLICY];
static int ovr_n;
static char ovr_gpu_max[256], ovr_gpu_min[256], ovr_gpu_freqs[512];

static void ovr_load(void) {
  FILE *f = fopen(OVR_FILE, "r");
  if (!f) return;
  char line[800];
  while (fgets(line, sizeof line, f)) {
    if (!strncmp(line, "cpu-dir ", 8)) {
      if (ovr_n >= MAX_POLICY) continue;
      long hw = 0;
      if (sscanf(line + 8, "%223s %ld", ovr_dir[ovr_n], &hw) == 2 && hw > 0 &&
          !access(ovr_dir[ovr_n], F_OK)) {
        ovr_hw[ovr_n] = hw;
        ovr_n++;
      }
    } else if (!strncmp(line, "gpu-max ", 8)) {
      sscanf(line + 8, "%255[^\r\n]", ovr_gpu_max);
    } else if (!strncmp(line, "gpu-min ", 8)) {
      sscanf(line + 8, "%255[^\r\n]", ovr_gpu_min);
    } else if (!strncmp(line, "gpu-freqs ", 10)) {
      sscanf(line + 10, "%511[^\r\n]", ovr_gpu_freqs);
    }
  }
  fclose(f);
}

/* 自动探测一个 policy 都没拿到时的兜底。
 * 目录路径由人给出，所以不要求它一定在 /sys/devices/system/cpu/cpufreq 下面，
 * 也不要求目录名一定叫 policyN。 */
static int ovr_policies(struct policy *out) {
  int n = 0;
  for (int i = 0; i < ovr_n && n < MAX_POLICY; i++) {
    char cut[240], path[256];
    const char *base = strrchr(ovr_dir[i], '/');
    base = base ? base + 1 : ovr_dir[i];
    /* 逐核目录（…/cpu0/cpufreq）的末段每条都一样，直接拿来当名字，
       页面上就是一排重名的"cpufreq"。取上一段（cpu0）才分得清哪一簇。 */
    if (!strcmp(base, "cpufreq")) {
      size_t len = (size_t)(base - 1 - ovr_dir[i]);   /* 去掉末段，留 …/cpu0 */
      if (base == ovr_dir[i] || len >= sizeof cut) len = 0;
      snprintf(cut, sizeof cut, "%.*s", (int)len, ovr_dir[i]);
      const char *p2 = strrchr(cut, '/');
      base = p2 ? p2 + 1 : cut;
    }
    snprintf(out[n].dir, sizeof out[n].dir, "%s", ovr_dir[i]);
    snprintf(out[n].name, sizeof out[n].name, "%s", base);
    out[n].pol_no = policy_index(out[n].dir);
    snprintf(path, sizeof path, "%s/cpuinfo_max_freq", out[n].dir);
    out[n].hw_max = read_num(path);
    if (out[n].hw_max <= 0) out[n].hw_max = ovr_hw[i];
    snprintf(path, sizeof path, "%s/cpuinfo_min_freq", out[n].dir);
    out[n].hw_min = read_num(path);
    if (out[n].hw_max > 0) {
      policy_vendor_max_init(&out[n]);
      n++;
    }
  }
  return n;
}

static int detect_policies_raw(struct policy *out) {
  DIR *d = opendir(CPUFREQ);
  if (!d) return 0;
  char path[256];
  int n = 0;
  struct dirent *e;
  while ((e = readdir(d)) && n < MAX_POLICY) {
    if (strncmp(e->d_name, "policy", 6)) continue;
    snprintf(out[n].dir, sizeof out[n].dir, "%s/%s", CPUFREQ, e->d_name);
    snprintf(out[n].name, sizeof out[n].name, "%s", e->d_name);
    /* policy 号直接从目录名取，别用数组下标：下标会随目录顺序变，
     * 而 core_policy_of(c) 给的是 readlink 读出来的真实 policy 号，
     * 两者必须能对上，反查才成立。 */
    out[n].pol_no = atoi(e->d_name + 6);
    snprintf(path, sizeof path, "%s/cpuinfo_max_freq", out[n].dir);
    out[n].hw_max = read_num(path);
    snprintf(path, sizeof path, "%s/cpuinfo_min_freq", out[n].dir);
    out[n].hw_min = read_num(path);
    if (out[n].hw_max > 0) {
      policy_vendor_max_init(&out[n]);
      n++;
    }
  }
  closedir(d);
  /* 按 policy 号升序，让同样的机器每次导出顺序一致 */
  for (int i = 1; i < n; i++) {
    struct policy key = out[i];
    int j = i - 1;
    while (j >= 0 && policy_index(out[j].dir) > policy_index(key.dir)) {
      out[j + 1] = out[j];
      j--;
    }
    out[j + 1] = key;
  }
  return n;
}

/* 不能用 hw_max 去重来省事：同频但独立的 policy（例如部分 4+4 机型的
   CPU7）必须各自写 scaling_max_freq 和 scaling_governor，否则会一直停在
   最高频、换调速器也不生效。分档阶梯由 build_ladder 去重，写入按全部
   policy 走。 */
static int detect_policies(struct policy *out) {
  struct policy tmp[MAX_POLICY];
  int n = detect_policies_raw(tmp);
  if (!n) n = ovr_policies(tmp);   /* 一个都没探测到时才用适配覆盖 */
  for (int i = 0; i < n; i++) out[i] = tmp[i];
  return n;
}

/* 簇阶梯：把全部 policy 的硬件上限去重后升序排好，m 是"不同上限的档数"。
   assign_pct 分档和 export 反查"某档管哪几颗核"共用同一份阶梯，
   以保证两处判据一致。 */
static int build_ladder(const struct policy *p, int n, long *ladder) {
  int m = 0;
  for (int i = 0; i < n; i++) {
    int seen = 0;
    for (int j = 0; j < m; j++)
      if (ladder[j] == p[i].hw_max) seen = 1;
    if (!seen) ladder[m++] = p[i].hw_max;
  }
  for (int i = 1; i < m; i++) {
    long k = ladder[i];
    int j = i - 1;
    while (j >= 0 && ladder[j] > k) {
      ladder[j + 1] = ladder[j];
      j--;
    }
    ladder[j + 1] = k;
  }
  return m;
}

/* 某个硬件上限属于哪一档，返回 0=BIG 1=MID2 2=MID 3=LITTLE（= tierkey）。
 * 判据与 assign_pct 共用同一函数，保证两处一致。
 *
 * m==2 的机器（小核 3533 + 超核 4320 这类两档布局）会**跳过**
 * MID2 和 MID 两档：最高和最低占 tier 0 和 1，
 * CPU_PCT_MID2 / CPU_PCT_MID 这两个配置键在这类机器上不生效——
 * 这两档没有对应的簇，不是保存失败。
 * 因此"这台机有几档"由 ntier 报出，页面对未落到的档显示（未检测到）。 */
static int tier_key_of(const long *ladder, int m, long hw_max) {
  int tier = 0;
  for (int j = 0; j < m; j++)
    if (ladder[j] == hw_max) tier = j;
  if (m <= 1) return 0;
  if (tier == m - 1) return 0;
  if (tier == 0) return 3;
  if (m >= 4 && tier == m - 2) return 1;
  return 2;
}

/* ── 智能模式：负载状态机 ────────────────────────────────────────
 * 四档 idle / light / medium / heavy。状态机给的是"这一档该用多少百分比"，
 * 真正写下去的仍是 min(它, CPU_PCT_*)：滑杆在智能模式下当天花板，
 * 状态机就算判错也顶不到 100%。
 *
 * 判据是 /proc/stat 的**逐簇平均占用取最大值**（每拍一次 open+read），
 * 单核满载不会被 8 核求和稀释；不引入 dumpsys。
 *
 * 滞回：进档 8/30/60，退档 4/25/55。升档 1 拍、降档 2 拍。 */
/* 各档占"用户天花板"的比例：重载用满，其余依次收紧。
 * 不用绝对百分比：每台机的 CPU_PCT_* 已经被机型预设定过（8E 是 46/51，
 * 别的机器可能 70+），写死 65/60 会在 46/51 上被天花板夹回、智能等于没开。
 *
 * 双簇机型（m==2，如 SM8750/8850）单独一套：没有中核缓冲，主簇
 * （6 颗 Oryon 性能核）如果也按 45/65 压，轻中载很快撞到 EAS 的
 * upmigrate 阈值，线程被推到漏电更高的超大核——越省越费。
 * 所以主簇整体上浮（55/75/90），超大核反而收紧（40/60/80），
 * 让 90% 的日常负载在主簇里消化。m=1/3/4 走通用比例。 */
static const int kSmartFrac[4] = {
  45,   /* idle   */
  65,   /* light  */
  85,   /* medium */
  100,  /* heavy  */
};
static const int kSmartFracM2Low[4] = { 55, 75, 90, 100 }; /* 主簇（tier 3） */
static const int kSmartFracM2Big[4] = { 40, 60, 80, 100 }; /* 超大核（tier 0） */
/* assign_pct 每拍都会用同一份阶梯算 m；存下来给 smart_pct 用。 */
static int g_ladder_m;

struct smart_state {
  int  state;
  int  pending;
  int  pend_n;
  long switches;
};
static struct smart_state g_sm;
static int g_sm_fast_n;

/* 每簇平均占用里最忙的一簇。全系统 /proc/stat 是 8 核求和，
 * 单核满载只有 12.5%，会被稀释成"轻载"；按 policy 分组后，
 * 两颗大核里一颗满载 = 50%（中载），六颗小核里一颗满载 = 16.7%。
 * 背景小核忙不会再把大核档位直接顶到 heavy。 */
static int cluster_max_load(const int *sum, const int *cnt, int n) {
  int best = -1;
  for (int i = 0; i < n; i++) {
    if (cnt[i] <= 0) continue;
    int avg = sum[i] / cnt[i];
    if (avg > best) best = avg;
  }
  return best;
}

static long g_cpu_prev_total[MAX_CORES], g_cpu_prev_idle[MAX_CORES];
static int g_cpu_prev_ok;
static long g_cpu_prev_ms;
/* 超大核（最高阶梯、tierkey==0）那一簇的平均占用；-1 = 无效，不向下钳。 */
static int g_prime_busy = -1;
/* 超大核自己的有效档：跟 smart_target 用同一套迟滞，避免占用在 8/30/60
 * 附近来回抖时每 5s 改写一次超大核封顶。-1 = 还没有有效样本。 */
static int g_prime_state = -1;
/* 1 = 本圈 smart_tick 走切前台预热（亮屏 / cap→smart，不靠 fg_changed）。 */
static int g_smart_warmup;
#ifdef SF_TEST
static int g_test_busy = -2;  /* -2 = 走真实 cpu_busy_pct */
static int g_test_half = -1;  /* -1 = 走真实 clusters_below_half */
static long g_test_now_ms = -1;
#endif

static int prime_cluster_busy(const int *sum, const int *cnt);

static long cpu_busy_now_ms(void) {
#ifdef SF_TEST
  if (g_test_now_ms >= 0) return g_test_now_ms;
#endif
  return mono_ms();
}

/* T = max(2×INTERVAL, 10) 秒，返回毫秒。 */
static long cpu_busy_stale_ms(int interval_s) {
  int t = interval_s * 2;
  if (t < 10) t = 10;
  return (long)t * 1000;
}

static int cpu_busy_gap_stale(long dt_ms, int interval_s) {
  return dt_ms < 0 || dt_ms > cpu_busy_stale_ms(interval_s);
}

/* 首次或长间隙：调用方重立计数器并返回 -1。 */
static int cpu_busy_must_rearm(long now_ms) {
  if (!g_cpu_prev_ok) {
    g_cpu_prev_ms = now_ms;
    return 1;
  }
  if (cpu_busy_gap_stale(now_ms - g_cpu_prev_ms, cfg.interval)) {
    g_cpu_prev_ms = now_ms;
    return 1;
  }
  return 0;
}

static void cpu_busy_invalidate(void) {
  g_cpu_prev_ok = 0;
  g_prime_busy = -1;
  g_prime_state = -1;
}

/* 有效档：仅 m!=1 且 tierkey==0（超大核）时按本簇占用向下钳。
 * prime_state 是已经过迟滞的超大核档位，-1 表示还没有有效样本。 */
static int smart_effective_state(int tierkey, int global_state,
                                int prime_state, int m) {
  int state = global_state;
  if (state < 0 || state > 3) state = 0;
  if (m == 1 || (tierkey & 3) != 0) return state;
  if (prime_state < 0 || prime_state > 3) return state;
  return prime_state < state ? prime_state : state;
}

static void smart_reset_idle(void) {
  g_sm.state = 0;
  g_sm.pending = 0;
  g_sm.pend_n = 0;
  g_sm_fast_n = 0;
  cpu_busy_invalidate();
}

/* 仅 smart + 保持封顶路径把档收到空闲。返回 1 表示已清状态。 */
static int smart_on_enter_screen_off(int keep) {
  if (cfg.strategy != 1 || !keep) return 0;
  smart_reset_idle();
  return 1;
}

static void smart_request_warmup(void) {
  g_smart_warmup = 0;
  if (cfg.strategy == 1 && cfg.app_switch_tier > 0 && strcmp(g_state, "game") != 0)
    g_smart_warmup = 1;
}

static void smart_on_leave_screen_off(void) {
  cpu_busy_invalidate();
  smart_request_warmup();
}

/* STRATEGY 边沿：重置状态机与占用基线；切入 smart 时再按规则请求预热。 */
static void smart_on_strategy_edge(int prev, int now) {
  (void)prev;
  smart_reset_idle();
  if (now == 1) smart_request_warmup();
}


/* 采样一次；返回最忙簇的平均占用百分比。
 * 计数器回退/首次采样/长间隙（Δt<0 或 Δt>T，T=max(2×INTERVAL,10)s）
 * 返回 -1，调用处保持当前档位。 */
static int cpu_busy_pct_ex(int skip_cpu0) {
  long total[MAX_CORES], idle[MAX_CORES];
  memset(total, 0, sizeof total);
  memset(idle, 0, sizeof idle);
  if (!core_stat_read(total, idle)) return -1;
  long now = cpu_busy_now_ms();
  if (cpu_busy_must_rearm(now)) {
    memcpy(g_cpu_prev_total, total, sizeof total);
    memcpy(g_cpu_prev_idle, idle, sizeof idle);
    g_cpu_prev_ok = 1;
    g_prime_busy = -1;
    return -1;
  }
  int sum[MAX_CORES] = {0}, cnt[MAX_CORES] = {0};
  /* CPU0 常年被系统/输入/WALT 占用，拿它判"簇忙不忙"会让静置永远进不了
   * 低载。动态封顶用 skip_cpu0=1；智能分档保持原来的全核口径。 */
  int skip0 = 0;
  if (skip_cpu0) {
    for (int c = 1; c < MAX_CORES; c++)
      if (total[c] > 0) { skip0 = 1; break; }
  }
  for (int c = 0; c < MAX_CORES; c++) {
    if (total[c] <= 0) continue;
    if (c == 0 && skip0) {
      g_cpu_prev_total[c] = total[c];
      g_cpu_prev_idle[c] = idle[c];
      continue;
    }
    int pol = core_policy_of(c);
    if (pol < 0 || pol >= MAX_CORES) continue;
    /* 计数器没动 = 这颗核 offline/没 tick，不能当成"0% 占用"拉低簇均值 */
    if (total[c] <= g_cpu_prev_total[c]) {
      g_cpu_prev_total[c] = total[c];
      g_cpu_prev_idle[c] = idle[c];
      continue;
    }
    sum[pol] += core_load_pct(total[c], idle[c],
                              g_cpu_prev_total[c], g_cpu_prev_idle[c]);
    cnt[pol]++;
    g_cpu_prev_total[c] = total[c];
    g_cpu_prev_idle[c] = idle[c];
  }
  g_cpu_prev_ms = now;
  g_prime_busy = prime_cluster_busy(sum, cnt);
  return cluster_max_load(sum, cnt, MAX_CORES);
}

static int cpu_busy_pct(void) { return cpu_busy_pct_ex(0); }

/* 纯函数：busy% + 当前档 → 目标档。单测直接喂数。 */
static int smart_target(int cur, int busy) {
  if (busy < 0) return cur;
  int want;
  if (busy >= 60) want = 3;
  else if (busy >= 30) want = 2;
  else if (busy >= 8) want = 1;
  else want = 0;
  if (want < cur) {
    int lo = (cur == 3) ? 55 : (cur == 2) ? 25 : 4;
    if (busy > lo) want = cur;          /* 没跌破退档阈值：不动 */
  }
  return want;
}

/* 超大核自己的档位：与全局同一套阈值和迟滞，避免占用在 8/30/60
 * 附近来回抖时每拍改写一次封顶。首个有效样本从重载档向下收敛。 */
static int smart_prime_state_step(int prev, int busy) {
  if (busy < 0) return prev;
  if (prev < 0) prev = 3;
  return smart_target(prev, busy);
}

/* 这一档、这个 tier 的目标百分比（已按用户设的天花板夹过）。
 * 每个 tier 用**自己**的 CPU_PCT_*：m=3/4 机型的 MID/MID2/LITTLE
 * 不会再共用同一个固定值。 */
static int smart_pct_of(int state, int ceil) {
  if (state < 0 || state > 3) state = 0;
  if (ceil < 1) ceil = 1;
  if (ceil > 100) ceil = 100;
  int v = ceil * kSmartFrac[state] / 100;
  return v < 1 ? 1 : v;
}

/* 带拓扑的版本：m==2 时超大核与主簇分开缩放。 */
static int smart_pct_tier(int tierkey, int m) {
  int state = smart_effective_state(tierkey, g_sm.state, g_prime_state, m);
  int ceil = cfg.pct[tierkey & 3];
  if (ceil < 1) ceil = 1;
  if (ceil > 100) ceil = 100;
  if (m != 2) return smart_pct_of(state, ceil);   /* m=1/3/4 走通用比例 */
  const int *tab = ((tierkey & 3) == 0) ? kSmartFracM2Big : kSmartFracM2Low;
  int v = ceil * tab[state] / 100;
  return v < 1 ? 1 : v;
}

static int smart_pct(int tierkey) {
  return smart_pct_tier(tierkey, g_ladder_m);
}

/* 每拍推进一次。app_switch=1 表示这一拍检测到前台包名换了。
 * 返回 1 = 档位变了，调用处要重算封顶。 */
static int smart_boost_state(int cur, int tier) {
  return tier > cur ? tier : cur;
}

static int freq_below_half(long cur, long cap) {
  return cur > 0 && cap > 0 && cur * 2 <= cap;
}

static int clusters_below_half(void);

static const char *smart_state_cn(int s) {
  static const char *const n[4] = { "空闲", "轻载", "中载", "重载" };
  return n[s & 3];
}

static int smart_tick_ex(int busy, int app_switch, int below_half) {
  int want = smart_target(g_sm.state, busy);
  int changed = 0, forced = 0;

  /* 切前台首拍：直接顶到预热档，冷启动/首屏渲染不用等状态机爬升。
     只升不降；下一拍开始走正常迟滞，不会一直挂着高档。 */
  if (app_switch && cfg.app_switch_tier > 0) {
    int boosted = smart_boost_state(g_sm.state, cfg.app_switch_tier);
    if (want > boosted) boosted = want;   /* 负载本身已经更高就别压回去 */
    if (boosted > g_sm.state) {
      g_sm.state = boosted;
      g_sm.pending = boosted;
      g_sm.pend_n = 0;
      g_sm.switches++;
      g_sm_fast_n = 0;
      changed = forced = 1;
      log("智能模式：切前台，预热到%s档（大核 %d%% / 其余 %d%%）",
          smart_state_cn(g_sm.state), smart_pct(0), smart_pct(3));
    }
  }

  /* 静置快降：连续 2 拍目标空闲、且各簇实际频率都低于当前封顶一半，
     直接从 2/3 档回 0 档，不用逐档衰减。 */
  if (!forced && want == 0 && g_sm.state >= 2 && below_half) {
    if (++g_sm_fast_n >= 2) {
      g_sm.state = 0;
      g_sm.pending = 0;
      g_sm.pend_n = 0;
      g_sm.switches++;
      g_sm_fast_n = 0;
      changed = forced = 1;
      log("智能模式：静置且各簇低于半帽，直接回空闲档（大核 %d%% / 其余 %d%%）",
          smart_pct(0), smart_pct(3));
    }
  } else if (!forced) {
    g_sm_fast_n = 0;
  }

  if (!forced) {
    if (want == g_sm.state) { g_sm.pending = want; g_sm.pend_n = 0; }
    else {
      if (want == g_sm.pending) g_sm.pend_n++;
      else { g_sm.pending = want; g_sm.pend_n = 1; }
      /* 升档 1 拍（5s）就切，降档仍要 2 拍（10s）：
         突发负载不用等 10s 才拿到高频，档位才敢定得比 cap 低。 */
      int need = want > g_sm.state ? 1 : 2;
      if (g_sm.pend_n >= need) {
        g_sm.state = want;
        g_sm.pend_n = 0;
        g_sm.switches++;
        changed = 1;
      }
    }
  }
  if (changed && !forced)
    log("智能模式：负载 %d%% → 档位 %d（大核 %d%% / 其余 %d%%）", busy,
        g_sm.state, smart_pct(0), smart_pct(3));
  return changed;
}

static int smart_tick(int app_switch) {
  if (g_smart_warmup) {
    app_switch = 1;
    g_smart_warmup = 0;
  }
  int preheat = app_switch && cfg.app_switch_tier > 0;
  /* 预热这一拍不拿旧的超大核档位去钳：冷启动/亮屏瞬间超大核本来就还没忙，
     用旧的低占用钳住会把预热抵消掉。下一拍起按新占用重新收敛。 */
  if (preheat) g_prime_state = -1;
#ifdef SF_TEST
  if (g_test_busy != -2)
    return smart_tick_ex(g_test_busy, app_switch,
                         g_test_half >= 0 ? g_test_half : 0);
#endif
  int busy = cpu_busy_pct();
  if (busy >= 0 && !preheat)
    g_prime_state = smart_prime_state_step(g_prime_state, g_prime_busy);
  /* 半帽读取只在 2/3 档才需要；空闲/轻载不去碰 cur_freq。 */
  int below = g_sm.state >= 2 ? clusters_below_half() : 0;
  return smart_tick_ex(busy, app_switch, below);
}

/* 按簇阶梯分档：最高档 big，次高 mid2，中间 mid，最低 little */
/* 生效封顶 = 用户设的值 + 实时偏移（adapt.c 每轮算好放在快照里）。
 * 充电态是"抬地板"：插着电发热由充电器承担，没必要压着；
 * 但它只作用于全局分档 —— 用户给某个应用单独设的档位是他的明确选择，
 * 插电不该替他改掉。温控和 PSI 叠在地板之上，所以热的时候插着电照样降。 */
/* 生效偏移。智能模式自己按负载调目标，不再叠 PSI 的向上借额度：
 * PSI 会把 45% 的轻载档临时顶到 55%，等于把智能刚省下的又还回去。
 * 温控/电量收紧仍然保留（它们的方向是保护，不是放宽）。 */
static int effective_delta(const struct adapt *a) {
  if (cfg.strategy != 1) return a->delta;
  int d = -(a->th_steps * cfg.ad.th_step) - a->batt_cut;
  if (d > cfg.ad.up_max) d = cfg.ad.up_max;
  if (d < -cfg.ad.down_max) d = -cfg.ad.down_max;
  return d;
}

static int eff_pct(int base, int per_app) {
  struct adapt a;
  adapt_snapshot(&a);
  /* 电量阶梯也属于"全局让路"，不盖用户给某个应用明确设的档位。 */
  int d = effective_delta(&a);
  if (per_app) d += a.batt_cut;
  /* 充电地板只抬"放宽侧"：本拍有收紧（温控/电量）时不抬。
     否则 65% 设定插电变 100%，温控 -25 只落到 75%，比不插电的 40% 松 35 个点，
     发热保护被充电地板抵消。 */
  /* 熄屏不吃充电地板：夜里插电是"发热 + 待机"的主场景，白天插电才要性能。 */
  if (!per_app && !g_screen_off && a.chg_on && a.chg_pct > base && d >= 0)
    base = a.chg_pct;
  base += d;
  if (base < 1) base = 1;
  if (base > 100) base = 100;
  return base;
}

static void assign_pct(struct policy *p, int n) {
  long ladder[MAX_POLICY];
  int m = build_ladder(p, n, ladder);
  g_ladder_m = m;
  for (int i = 0; i < n; i++) {
    int tier = 0;
    for (int j = 0; j < m; j++)
      if (ladder[j] == p[i].hw_max) tier = j;
    int pct, tierkey;
    tierkey = tier_key_of(ladder, m, p[i].hw_max);
    /* 键到值的下标和 tierkey 一样（cfg.pct 的下标就是 BIG/MID2/MID/LITTLE） */
    pct = (cfg.strategy == 1) ? smart_pct(tierkey) : cfg.pct[tierkey];
    /* 超大核压到最低频：不关闭核心，只把 BIG 簇的目标放到 1%。
     * 游戏/满血/熄屏交还走 hand_back_full，不经过这里。 */
    int big_min_hit = (cfg.big_min && tierkey == 0);
    if (big_min_hit) pct = 1;
    if (pct < 1 || pct > 100) pct = 1;
    p[i].tpct = pct;
    /* big_min 的目标就是最低频：充电地板、PSI 借档都不许把它抬起来 */
    int eff = big_min_hit ? 1 : eff_pct(pct, 0);
    p[i].pct = eff;
    p[i].tier = tierkey;
    long vendor = p[i].vendor_max;
    p[i].cap = cap_floor_apply(&p[i], snap_freq(&p[i], cap_from_pct(&p[i], eff)));
    log("  %-8s 档位%d/%d 厂商%ld 硬件%ld 意图%d%% 生效%d%% 封顶%ld (%.1f%%)",
        p[i].name, tier, m - 1, vendor, p[i].hw_max, pct, eff,
        p[i].cap, p[i].hw_max > 0 ? 100.0 * p[i].cap / p[i].hw_max : 0.0);
  }
}

/* ------------------------------------------------------------------ */
/* GPU 探测（高通 KGSL + MTK Mali）                                   */
/* ------------------------------------------------------------------ */

struct gpu {
  char max_node[256];
  int max_is_mhz;
  char min_node[256];
  int min_is_mhz;
  char pwr_node[256];
  long normal, max_hz, min_hz;
  long active;            /* 本轮真正要压到的频点；实时偏移会改它 */
  long tbl[MAX_NODE];     /* 降序频点表，吸附和 pwrlevel 都用同一份 */
  int ntbl;
  int pwr_normal;
  int ok;
  /* MTK gpufreqv2 limit_table 后端（没有 devfreq 节点的天玑机） */
  int mtk;
  int mtk_layer;
  int mtk_orig_ceiling, mtk_orig_floor;
  int mtk_dirty;
  /* 老 MTK：GED custom_upbound_gpu_freq 写 OPP index，不是频率 */
  int ged;
  int opidx[MAX_NODE];
};

static struct gpu g_gpu;

static const char *gpu_max_candidates[] = {
    "/sys/class/devfreq/3d00000.qcom,kgsl-3d0/max_freq",
    "/sys/class/devfreq/5000000.qcom,kgsl-3d0/max_freq",
    "/sys/class/devfreq/2c00000.qcom,kgsl-3d0/max_freq",
    "/sys/class/kgsl/kgsl-3d0/devfreq/max_freq",
    "/sys/class/kgsl/kgsl-3d0/max_gpuclk",
    "/sys/class/kgsl/kgsl-3d0/max_clock_mhz",
    "/sys/class/devfreq/13000000.mali/max_freq",
    "/sys/class/devfreq/48000000.mali/max_freq",
    "/sys/class/devfreq/mtk-mali/max_freq",
    "/sys/class/devfreq/mali0/max_freq",
    "/sys/class/devfreq/gpufreq/max_freq",
    "/sys/class/misc/mali0/device/devfreq/max_freq",
    "/sys/devices/platform/soc/13000000.mali/devfreq/max_freq",
    "/sys/devices/platform/13000000.mali/devfreq/max_freq",
    "/sys/kernel/gpu/gpu_max_clock",
};

static const char *gpu_freq_candidates[] = {
    "/sys/class/kgsl/kgsl-3d0/gpu_available_frequencies",
    "/sys/class/kgsl/kgsl-3d0/devfreq/available_frequencies",
    "/sys/class/devfreq/3d00000.qcom,kgsl-3d0/available_frequencies",
    "/sys/class/devfreq/5000000.qcom,kgsl-3d0/available_frequencies",
    "/sys/class/kgsl/kgsl-3d0/freq_table_mhz",
    "/sys/class/devfreq/3d00000.qcom,kgsl-3d0/freq_table_mhz",
    "/sys/class/devfreq/5000000.qcom,kgsl-3d0/freq_table_mhz",
    "/sys/class/devfreq/13000000.mali/available_frequencies",
    "/sys/class/devfreq/48000000.mali/available_frequencies",
    "/sys/class/devfreq/mtk-mali/available_frequencies",
    "/sys/class/devfreq/mali0/available_frequencies",
    "/sys/class/devfreq/gpufreq/available_frequencies",
    "/sys/class/misc/mali0/device/devfreq/available_frequencies",
    "/sys/devices/platform/soc/13000000.mali/devfreq/available_frequencies",
    "/sys/devices/platform/13000000.mali/devfreq/available_frequencies",
};

/* 读频率表并统一归一到 Hz；数字小于一万判为 MHz */
static int parse_freq_table(const char *path, long *out, int max) {
  char b[8192];
  if (read_file(path, b, sizeof b)) return 0;
  int n = 0, mhz_tbl = strstr(path, "freq_table_mhz") != NULL;
  long peak = 0;
  char *save = NULL;
  for (char *t = strtok_r(b, " \t\n,", &save); t; t = strtok_r(NULL, " \t\n,", &save)) {
    if (!isdigit((unsigned char)*t)) continue;
    long v = strtol(t, NULL, 10);
    if (v <= 0) continue;
    if (v > peak) peak = v;
    if (n < max) out[n++] = v;
  }
  if (!n) return 0;
  if (mhz_tbl || peak < 10000)
    for (int i = 0; i < n; i++) out[i] *= 1000000;
  return n;
}

/* ── MTK gpufreqv2 ─────────────────────────────────────────────── */
/* stack_working_opp_table 一行形如 "[00] freq: 1716000, volt: ..."；
 * 只取 freq: 后面的数，单位 kHz，归一到 Hz。 */
static int mtk_parse_opp_text(const char *text, long *out, int max) {
  if (!text) return 0;
  char *copy = strdup(text);
  if (!copy) return 0;
  int n = 0;
  char *save = NULL;
  for (char *line = strtok_r(copy, "\n", &save); line;
       line = strtok_r(NULL, "\n", &save)) {
    char *p = strstr(line, "freq:");
    if (!p) continue;
    p += 5;
    while (*p == ' ' || *p == '\t') p++;
    if (!isdigit((unsigned char)*p)) continue;
    long v = strtol(p, NULL, 10);
    if (v <= 0) continue;
    if (v < 10000000L) v *= 1000;   /* MTK OPP 表用 kHz */
    if (n < max) out[n++] = v;
  }
  free(copy);
  return n;
}

static int mtk_parse_opp(const char *path, long *out, int max) {
  char b[16384];
  if (read_file(path, b, sizeof b)) return 0;
  return mtk_parse_opp_text(b, out, max);
}

/* 老 MTK 的 OPP dump：一行形如 "[07] freq = 900000, volt = 75000"。
 * 同时给出频率（Hz）和 OPP 序号；GED 的 custom_upbound_gpu_freq
 * 收的是序号，不是频率。 */
static int mtk_old_parse_opp_text(const char *text, long *freq, int *opidx, int max) {
  if (!text) return 0;
  char *copy = strdup(text);
  if (!copy) return 0;
  char *save = NULL;
  int n = 0;
  for (char *ln = strtok_r(copy, "\n", &save); ln && n < max;
       ln = strtok_r(NULL, "\n", &save)) {
    char *p = strchr(ln, '[');
    if (!p) continue;
    int idx = atoi(p + 1);
    char *f = strstr(ln, "freq");
    if (!f) continue;
    f = strchr(f, '=');
    if (!f) continue;
    f++;
    while (*f == ' ' || *f == '\t') f++;
    if (!isdigit((unsigned char)*f)) continue;
    long v = strtol(f, NULL, 10);
    if (v <= 0) continue;
    if (v < 10000000L) v *= 1000;   /* kHz -> Hz */
    freq[n] = v;
    opidx[n] = idx;
    n++;
  }
  free(copy);
  return n;
}

static int mtk_old_parse_opp(const char *path, long *freq, int *opidx, int max) {
  char b[16384];
  if (read_file(path, b, sizeof b)) return 0;
  return mtk_old_parse_opp_text(b, freq, opidx, max);
}

/* 从 limit_table 读某一层的 ceiling/floor；找不到返回 0。 */
static int mtk_read_row(int id, int *ceil, int *floor) {
  char b[4096];
  if (read_file(MTK_LIMIT, b, sizeof b)) return 0;
  char *save = NULL;
  for (char *ln = strtok_r(b, "\n", &save); ln; ln = strtok_r(NULL, "\n", &save)) {
    int fid = -1, prio = 0, ce = -1, fl = -1, ce_en = 0, fe_en = 0;
    char name[64] = {0};
    if (sscanf(ln, "%d %63s %d %d %d %d %d",
               &fid, name, &prio, &ce, &fl, &ce_en, &fe_en) != 7)
      continue;
    if (fid != id) continue;
    *ceil = ce;
    *floor = fl;
    return 1;
  }
  return 0;
}

static int mtk_write_row(int id, int ceil, int floor) {
  char cmd[96];
  snprintf(cmd, sizeof cmd, "set %d %d %d\n", id, ceil, floor);
  return write_text(MTK_LIMIT, cmd);
}

static void mtk_save_snapshot(void) {
  char b[128];
  snprintf(b, sizeof b, "id=%d\nceil=%d\nfloor=%d\n",
           g_gpu.mtk_layer, g_gpu.mtk_orig_ceiling, g_gpu.mtk_orig_floor);
  if (write_text_file(MTK_GPU_SNAP, b))
    log("WARN MTK GPU 快照写入失败");
}

/* 正常退出/交权：把这一层写回原来的 ceiling/floor，删快照。 */
static void mtk_restore_row(void) {
  if (!g_gpu.mtk) return;
  mtk_write_row(g_gpu.mtk_layer, g_gpu.mtk_orig_ceiling, g_gpu.mtk_orig_floor);
  unlink(MTK_GPU_SNAP);
  g_gpu.mtk_dirty = 0;
}

/* 启动时发现上次没走正常退出：先把 limit_table 还原，再重新探测。 */
static void mtk_restore_snapshot(void) {
  char b[256];
  if (read_file(MTK_GPU_SNAP, b, sizeof b)) return;
  int id = -1, c = -1, f = -1;
  char *p;
  if ((p = strstr(b, "id="))) id = atoi(p + 3);
  if ((p = strstr(b, "ceil="))) c = atoi(p + 5);
  if ((p = strstr(b, "floor="))) f = atoi(p + 6);
  if (id >= 0 && mtk_write_row(id, c, f) == 0)
    log("MTK GPU: 按存档恢复 layer=%d %d/%d", id, c, f);
  unlink(MTK_GPU_SNAP);
}

/* readonly=1：只探测，不碰任何节点。
 * export / probe 是"只读"子命令，而 WebUI 每次 status 都跑 export ——
 * 它们如果顺手把 MTK 快照恢复掉，等于用户一打开首页就把 GPU 封顶顶回去，
 * 还删了快照；守护侧对 MTK 后端又补不回来（patrol 读不到 max_node）。 */
static int detect_gpu(int readonly) {
  /* 上次被 kill -9 留下的 cap 先还原，别把"37/56"当成原始行再存一遍。 */
  if (!readonly) mtk_restore_snapshot();
  memset(&g_gpu, 0, sizeof g_gpu);
  long tbl[MAX_NODE];
  int opidx[MAX_NODE] = {0};
  int n = 0;
  if (!access(MTK_LIMIT, F_OK) && !access(MTK_OPP, F_OK)) {
    n = mtk_parse_opp(MTK_OPP, tbl, MAX_NODE);
    if (n) {
      g_gpu.mtk = 1;
      g_gpu.mtk_layer = 1;   /* DEBUG 层：实测能压 PPM Ceiling，且不抢系统层 */
      log("GPU 频率表: MTK %s", MTK_OPP);
    }
  }
  for (size_t i = 0; !n && i < sizeof gpu_freq_candidates / sizeof *gpu_freq_candidates;
       i++) {
    n = parse_freq_table(gpu_freq_candidates[i], tbl, MAX_NODE);
    if (n) {
      log("GPU 频率表: %s", gpu_freq_candidates[i]);
      break;
    }
  }
  if (!n && ovr_gpu_freqs[0]) {
    char fb[512], *fsv = NULL;
    snprintf(fb, sizeof fb, "%s", ovr_gpu_freqs);
    for (char *t = strtok_r(fb, " \t", &fsv); t && n < MAX_NODE;
         t = strtok_r(NULL, " \t", &fsv)) {
      long v = strtol(t, NULL, 10);
      if (v > 0) tbl[n++] = v;
    }
    if (n) log("GPU 频率表来自适配覆盖");
  }
  /* 老 MTK：没有 devfreq 频率表时，用 gpufreq_opp_dump + GED 上限。
   * 这一路只在前面所有后端都拿不到频点表时启用，不影响新天玑/高通。 */
  if (!n && !access(MTK_OLD_OPP, F_OK) && !access(MTK_GED_UPBOUND, F_OK)) {
    n = mtk_old_parse_opp(MTK_OLD_OPP, tbl, opidx, MAX_NODE);
    if (n) {
      g_gpu.ged = 1;
      log("GPU 频率表: MTK 老 OPP %s（GED 上限）", MTK_OLD_OPP);
    }
  }
  if (!n) {
    log("WARN 未找到 GPU 频率表，跳过 GPU 限频");
    return -1;
  }

  g_gpu.max_hz = g_gpu.min_hz = tbl[0];
  for (int i = 1; i < n; i++) {
    if (tbl[i] > g_gpu.max_hz) g_gpu.max_hz = tbl[i];
    if (tbl[i] < g_gpu.min_hz) g_gpu.min_hz = tbl[i];
  }

  long want = g_gpu.max_hz * cfg.gpu_pct / 100;
  g_gpu.normal = 0;
  for (int i = 0; i < n; i++)
    if (tbl[i] <= want && tbl[i] > g_gpu.normal) g_gpu.normal = tbl[i];
  if (!g_gpu.normal) g_gpu.normal = g_gpu.min_hz;

  /* 降序排一遍：KGSL 的 max_pwrlevel 是索引，0 对应最高频 */
  for (int i = 0; i < n; i++)
    for (int j = i + 1; j < n; j++)
      if (tbl[j] > tbl[i]) {
        long t = tbl[i];
        tbl[i] = tbl[j];
        tbl[j] = t;
        int ti = opidx[i];
        opidx[i] = opidx[j];
        opidx[j] = ti;
      }
  memcpy(g_gpu.tbl, tbl, sizeof(long) * n);
  memcpy(g_gpu.opidx, opidx, sizeof(int) * n);
  g_gpu.ntbl = n;
  if (g_gpu.ged) {
    snprintf(g_gpu.max_node, sizeof g_gpu.max_node, "%s", MTK_GED_UPBOUND);
    g_gpu.ok = 1;
    log("GPU: MTK 老 GED 上限=%s 硬件%ld~%ldHz 封顶%ldHz",
        g_gpu.max_node, g_gpu.min_hz, g_gpu.max_hz, g_gpu.normal);
    return 0;
  }
  if (g_gpu.mtk) {
    int c = -1, f = -1;
    if (!mtk_read_row(g_gpu.mtk_layer, &c, &f)) { c = -1; f = -1; }
    g_gpu.mtk_orig_ceiling = c;
    g_gpu.mtk_orig_floor = f;
    g_gpu.ok = 1;
    log("GPU: MTK gpufreqv2 layer=%d 原始 %d/%d 硬件%ld~%ldHz 封顶%ldHz",
        g_gpu.mtk_layer, c, f, g_gpu.min_hz, g_gpu.max_hz, g_gpu.normal);
    return 0;
  }
  if (!access("/sys/class/kgsl/kgsl-3d0/max_pwrlevel", F_OK)) {
    snprintf(g_gpu.pwr_node, sizeof g_gpu.pwr_node,
             "/sys/class/kgsl/kgsl-3d0/max_pwrlevel");
    for (int i = 0; i < n; i++)
      if (tbl[i] <= g_gpu.normal) {
        g_gpu.pwr_normal = i;
        break;
      }
  }

  for (size_t i = 0; i < sizeof gpu_max_candidates / sizeof *gpu_max_candidates;
       i++) {
    if (access(gpu_max_candidates[i], F_OK)) continue;
    snprintf(g_gpu.max_node, sizeof g_gpu.max_node, "%s", gpu_max_candidates[i]);
    g_gpu.max_is_mhz = strstr(g_gpu.max_node, "gpu_max_clock") ||
                       strstr(g_gpu.max_node, "max_clock_mhz");
    break;
  }

  if (!g_gpu.max_node[0] && ovr_gpu_max[0] && !access(ovr_gpu_max, F_OK)) {
    snprintf(g_gpu.max_node, sizeof g_gpu.max_node, "%s", ovr_gpu_max);
    g_gpu.max_is_mhz = strstr(g_gpu.max_node, "mhz") ||
                       strstr(g_gpu.max_node, "MHZ") ? 1 : 0;
    log("GPU 上限节点来自适配覆盖");
  }
  if (!g_gpu.min_node[0] && ovr_gpu_min[0] && !access(ovr_gpu_min, F_OK)) {
    snprintf(g_gpu.min_node, sizeof g_gpu.min_node, "%s", ovr_gpu_min);
    g_gpu.min_is_mhz = strstr(g_gpu.min_node, "mhz") ||
                       strstr(g_gpu.min_node, "MHZ") ? 1 : 0;
  }

  /* 配对下限节点：优先统一命名，否则按后缀替换 max→min */
  if (!access("/sys/kernel/gpu/gpu_min_clock", F_OK)) {
    snprintf(g_gpu.min_node, sizeof g_gpu.min_node,
             "/sys/kernel/gpu/gpu_min_clock");
    g_gpu.min_is_mhz = 1;
  } else if (g_gpu.max_node[0]) {
    static const struct {
      const char *suffix, *repl;
      int mhz;
    } pairs[] = {
        {"max_gpuclk", "min_gpuclk", 0},
        {"max_freq", "min_freq", 0},
        {"gpu_max_clock", "gpu_min_clock", 1},
        {"max_clock_mhz", "min_clock_mhz", 1},
    };
    for (size_t i = 0; i < sizeof pairs / sizeof *pairs; i++) {
      char *hit = strstr(g_gpu.max_node, pairs[i].suffix);
      if (!hit) continue;
      char cand[256];
      snprintf(cand, sizeof cand, "%.*s%s%s", (int)(hit - g_gpu.max_node),
               g_gpu.max_node, pairs[i].repl, hit + strlen(pairs[i].suffix));
      if (!access(cand, F_OK)) {
        snprintf(g_gpu.min_node, sizeof g_gpu.min_node, "%s", cand);
        g_gpu.min_is_mhz = pairs[i].mhz;
      }
      break;
    }
  }

  if (!g_gpu.max_node[0] && !g_gpu.pwr_node[0]) {
    log("WARN 未找到可写 GPU 节点，跳过 GPU 限频");
    return -1;
  }
  g_gpu.ok = 1;
  log("GPU: 上限节点=%s(%s) 下限节点=%s 硬件%ld~%ldHz 封顶%ldHz%s", g_gpu.max_node,
      g_gpu.max_is_mhz ? "MHz" : "Hz", g_gpu.min_node[0] ? g_gpu.min_node : "无",
      g_gpu.min_hz, g_gpu.max_hz, g_gpu.normal, g_gpu.pwr_node[0] ? " +pwrlevel" : "");
  return 0;
}

/* 百分比吸附到不高于目标值的最高频点。和 detect_gpu 挑 normal 是同一套规则，
 * 只是目标值会随 PSI/温控偏移变化，不能只在加载配置时算一次。 */
static long gpu_snap(int pct) {
  if (pct < 1) pct = 1;
  if (pct > 100) pct = 100;
  long want = g_gpu.max_hz * pct / 100;
  long best = 0;
  for (int i = 0; i < g_gpu.ntbl; i++)
    if (g_gpu.tbl[i] <= want && g_gpu.tbl[i] > best) best = g_gpu.tbl[i];
  return best ? best : g_gpu.min_hz;
}

/* 降序表里第一个不高于目标的档就是 max_pwrlevel 的索引。 */
static int gpu_pwr_for(long hz) {
  for (int i = 0; i < g_gpu.ntbl; i++)
    if (g_gpu.tbl[i] <= hz) return i;
  return g_gpu.ntbl > 0 ? g_gpu.ntbl - 1 : 0;
}

/* GED custom_upbound_gpu_freq 收的是 OPP 序号，不是频率。 */
static int gpu_ged_idx_for(long hz) {
  for (int i = 0; i < g_gpu.ntbl; i++)
    if (g_gpu.tbl[i] <= hz) return g_gpu.opidx[i];
  return -1;
}

static long gpu_ged_freq_of(int idx) {
  for (int i = 0; i < g_gpu.ntbl; i++)
    if (g_gpu.opidx[i] == idx) return g_gpu.tbl[i];
  return -1;
}

/* 按节点单位换算后写入；解锁时只认写成功，被厂商钳制就如实报告不绕路 */
static const char *write_gpu(long want_hz, int unlock) {
  long got;
  if (g_gpu.ged) {
    long val;
    if (unlock) {
      if (!journal_value(NODES_JOURNAL, g_gpu.max_node, &val)) val = 0;
    } else {
      int idx = gpu_ged_idx_for(want_hz);
      if (idx < 0) return "failed";
      val = idx;
    }
    if (!write_journaled(NODES_JOURNAL, g_gpu.max_node, val)) {
      long got_idx = read_num(g_gpu.max_node);
      if (unlock) {
        if (got_idx == val) return "unlocked";
        log("WARN GPU 解锁受限 期望 OPP %ld 实际 %ld", val, got_idx);
        return "restricted";
      }
      long got_hz = gpu_ged_freq_of((int)got_idx);
      if (got_hz > 0 && got_hz <= want_hz) return "capped";
    }
    return "failed";
  }
  if (g_gpu.mtk) {
    int idx, fl;
    if (unlock) {
      idx = g_gpu.mtk_orig_ceiling;
      fl = g_gpu.mtk_orig_floor;
    } else {
      idx = gpu_pwr_for(want_hz);
      fl = cfg.gpu_min_lock ? g_gpu.ntbl - 1 : g_gpu.mtk_orig_floor;
    }
    if (mtk_write_row(g_gpu.mtk_layer, idx, fl) == 0) {
      int rc = -1, rf = -1;
      if (mtk_read_row(g_gpu.mtk_layer, &rc, &rf) && rc == idx && rf == fl) {
        if (unlock) {
          unlink(MTK_GPU_SNAP);
          g_gpu.mtk_dirty = 0;
          return "unlocked";
        }
        if (!g_gpu.mtk_dirty) {
          mtk_save_snapshot();
          g_gpu.mtk_dirty = 1;
        }
        return "capped";
      }
    }
    return "failed";
  }
  if (g_gpu.max_node[0]) {
    long val = g_gpu.max_is_mhz ? want_hz / 1000000 : want_hz;
    if (!write_journaled(NODES_JOURNAL, g_gpu.max_node, val)) {
      got = read_num(g_gpu.max_node);
      if (got > 0 && g_gpu.max_is_mhz) got *= 1000000;
      if (unlock) {
        if (got >= want_hz) return "unlocked";
        log("WARN GPU 解锁受限 期望%ldHz 实际%ldHz（厂商限制）", want_hz, got);
        return "restricted";
      }
      if (got > 0 && got <= want_hz) return "capped";
    }
  }
  /* pwrlevel 是索引不是频率，单独校验 */
  if (g_gpu.pwr_node[0]) {
    long val = unlock ? 0 : gpu_pwr_for(want_hz);
    if (!write_journaled(NODES_JOURNAL, g_gpu.pwr_node, val) &&
        read_num(g_gpu.pwr_node) == val)
      return "pwrlevel";
  }
  return "failed";
}

/* 把 GPU 下限钉回最低档，压回被 boost/触摸抬高的地板。
 * boost 是毫秒级事件（输入 boost 默认 100ms、唤醒 boost 2500ms），
 * 不是"1~2 分钟一次"，所以命中后不能退避：先读、已经在下限就直接返回
 * （绝大多数拍走这条，读很便宜），被抬上去才写。 */
static long g_gmin_writes;   /* 真正写节点的次数，status 里报出来用于验收 */
/* 初值 -600：mono_sec() 从开机起算，初值 0 会让开机头 10 分钟一条 RESTORE 都不出。 */
static long g_gmin_log_at = -600;   /* 上一行 RESTORE 日志的时刻：写进去又被盖回时不刷屏 */

static void gpu_min_to_floor(void) {
  /* MTK 的下限在同一条 set 命令里写；没有独立 min 节点。 */
  if (g_gpu.mtk) return;
  if (!cfg.gpu_min_lock || !g_gpu.min_node[0] || g_gpu.min_hz <= 0) return;
  long cur = read_num(g_gpu.min_node);
  if (cur > 0 && g_gpu.min_is_mhz) cur *= 1000000;
  if (cur <= 0) return;                 /* 读不到就别写，免得把下限写成 0 */
  if (cur <= g_gpu.min_hz) return;      /* 已经在下限：这一拍什么都不做 */
  long val = g_gpu.min_is_mhz ? g_gpu.min_hz / 1000000 : g_gpu.min_hz;
  if (write_journaled(NODES_JOURNAL, g_gpu.min_node, val)) return;
  g_gmin_writes++;
  long got = read_num(g_gpu.min_node);
  if (got > 0 && g_gpu.min_is_mhz) got *= 1000000;
  /* 写完还高于下限才算异常（被厂商钳制）。"highest floor wins" 的内核上
     这一条可能每拍都成立，所以日志 10 分钟最多一行；写次数看 status 的 gminw。 */
  if (got > g_gpu.min_hz) {
    long now = mono_sec();
    if (now - g_gmin_log_at >= 600) {
      g_gmin_log_at = now;
      log("RESTORE GPU 下限 %ldHz -> %ldHz", got, g_gpu.min_hz);
    }
  }
}

/* ------------------------------------------------------------------ */
/* GPU Boost 源                                                       */
/* ------------------------------------------------------------------ */

/* 「禁止 GPU Boost」不是改频率帽，而是把厂商抬频的源头关掉：
 * 高通的 dcvs_boost（DCVS 抬频）、触摸唤醒 touch_wake、
 * devfreq_boost 模块的输入/唤醒持续时长。节点存在才写，值都记进账本；
 * 游戏/满血/熄屏交权时还原，卸载时 journal_restore 一起还原。 */
#define MTK_BOOST_NODE "/sys/kernel/ged/hal/custom_boost_gpu_freq"
#define MTK_OPP_V1     "/proc/gpufreq/gpufreq_opp_dump"

static const char *g_boost_nodes[] = {
    "/sys/class/kgsl/kgsl-3d0/dcvs_boost",
    "/sys/class/kgsl/kgsl-3d0/touch_wake",
    "/sys/class/kgsl/kgsl-3d0/force_no_nap",
    "/sys/module/devfreq_boost/parameters/devfreq_input_boost_duration_ms",
    "/sys/module/devfreq_boost/parameters/devfreq_wake_boost_duration_ms",
};

/* 高通 KGSL 空闲计时器：默认 80ms，即停止渲染后 GPU 还要空转 80ms
 * 才进 Slumber。间歇渲染（刷信息流/聊天）里这部分尾部空转占比不低。
 * 只降不升：原值本来就比 48ms 短说明厂商已调过，不动它。
 * 48ms 高于 30fps 的单帧间隔（33.3ms），连续渲染不会被误判为空闲。 */
#define KGSL_IDLE_TIMER "/sys/class/kgsl/kgsl-3d0/idle_timer"
#define KGSL_IDLE_MS   48

static void kgsl_idle_trim(void) {
  if (!cfg.gpu_boost_off) return;
  if (access(KGSL_IDLE_TIMER, F_OK)) return;
  long orig;
  if (journal_value(NODES_JOURNAL, KGSL_IDLE_TIMER, &orig)) {
    if (orig <= KGSL_IDLE_MS) return;   /* 出厂就比目标短：不升回去 */
  } else {
    long cur = read_num(KGSL_IDLE_TIMER);
    if (cur <= 0 || cur <= KGSL_IDLE_MS) return;
  }
  if (read_num(KGSL_IDLE_TIMER) == KGSL_IDLE_MS) return;
  write_journaled(NODES_JOURNAL, KGSL_IDLE_TIMER, KGSL_IDLE_MS);
}

/* 天玑的 boost 节点要的是 OPP 索引，而索引排序各内核不一定一致
 * （多数 0=最高频，但不能赌）。从表里按频率找"最低频那一档"的索引：
 * 写 0 在某些机子上等于把 boost 锁到最高频，方向正好反了。 */
static int mtk_opp_lowest_index_text(const char *text) {
  if (!text) return -1;
  char *copy = strdup(text);
  if (!copy) return -1;
  int best_idx = -1;
  long best_hz = 0;
  char *save = NULL;
  for (char *line = strtok_r(copy, "\n", &save); line;
       line = strtok_r(NULL, "\n", &save)) {
    char *lb = strchr(line, '[');
    if (!lb) continue;
    char *end = NULL;
    long idx = strtol(lb + 1, &end, 10);
    if (end == lb + 1 || *end != ']' || idx < 0 || idx > 255) continue;
    char *f = strstr(line, "freq");        /* v2 是 freq:，v1 是 freq = */
    if (!f) continue;
    f += 4;
    while (*f == ':' || *f == '=' || *f == ' ' || *f == '\t') f++;
    if (!isdigit((unsigned char)*f)) continue;
    long v = strtol(f, NULL, 10);
    if (v <= 0) continue;
    if (v < 10000000L) v *= 1000;          /* kHz -> Hz */
    if (best_idx < 0 || v < best_hz) { best_hz = v; best_idx = (int)idx; }
  }
  free(copy);
  return best_idx;
}

static int mtk_boost_lowest_index(void) {
  char b[16384];
  if (!read_file(MTK_OPP, b, sizeof b)) return mtk_opp_lowest_index_text(b);
  if (!read_file(MTK_OPP_V1, b, sizeof b)) return mtk_opp_lowest_index_text(b);
  return -1;
}

static void boost_restore_path(const char *p) {
  if (access(p, F_OK)) return;
  long orig;
  if (!journal_value(NODES_JOURNAL, p, &orig)) return;
  if (read_num(p) == orig) return;
  write_num(p, orig);
  int m = journal_mode(NODES_JOURNAL, p);
  if (m >= 0) chmod(p, (mode_t)m);
}

static void boost_off_apply(void) {
  if (!cfg.gpu_boost_off) return;
  int n = 0;
  for (size_t i = 0; i < sizeof g_boost_nodes / sizeof *g_boost_nodes; i++) {
    const char *p = g_boost_nodes[i];
    if (access(p, F_OK)) continue;
    if (read_num(p) == 0) continue;          /* 已经是关的：不重复写 */
    if (!write_journaled(NODES_JOURNAL, p, 0)) n++;
  }
  /* 天玑：把 boost 目标改成最低频档。表读不到就不写，不猜索引。 */
  if (!access(MTK_BOOST_NODE, F_OK)) {
    static int idx = -2;                     /* -2 = 还没算过 */
    if (idx == -2) idx = mtk_boost_lowest_index();
    long cur = read_num(MTK_BOOST_NODE);
    if (idx >= 0 && cur >= 0 && cur != idx) {
      if (!write_journaled(NODES_JOURNAL, MTK_BOOST_NODE, idx)) n++;
    }
  }
  kgsl_idle_trim();
  if (n) log("GPU Boost 已关闭（%d 个节点）", n);
}

/* 只还原模块真正改过的节点（账本里有才动），常态/交权都会调。 */
static void boost_off_restore(void) {
  for (size_t i = 0; i < sizeof g_boost_nodes / sizeof *g_boost_nodes; i++)
    boost_restore_path(g_boost_nodes[i]);
  boost_restore_path(MTK_BOOST_NODE);
  boost_restore_path(KGSL_IDLE_TIMER);
}

/* ── CPU Boost 中和（walt 输入/调度拉频源）─────────────────────────
 * 触摸瞬间 walt 的 input_boost 会把 CPU 频率顶上去，是日常频率蹿升的
 * 大源之一；GPU 侧的 boost 源早已由 GPU_BOOST_OFF 处理，这里是 CPU 侧。
 * 节点存在才写 0（高通 walt；其他 SoC 没有这些节点就自然跳过），
 * 值记进账本，交权/关闭/卸载时按账本还原。写入一次不对抗：
 * powerhal 之后若再抬属于厂商决策，重写只会变成拉锯。 */
static const char *g_cpu_boost_nodes[] = {
    /* 内核把 input_boost 收进子目录（一加 13 / ColorOS 16 实测），
       文件保留全名：input_boost_ms = 100（每次触摸拉频 100ms，日常
       频率蹿升的大源）。ms 归零后 freq 表不起作用，不动它（避免把
       多值表写坏）。 */
    "/proc/sys/walt/input_boost/input_boost_ms",
    /* 其他内核的平铺布局： */
    "/proc/sys/walt/input_boost_ms",
    "/proc/sys/walt/sched_per_task_boost",
    "/proc/sys/walt/sched_boost",
};

static long g_boost_log_at = -600;

static void suppress_boost_apply(void) {
  int n = 0;
  for (size_t i = 0; i < sizeof g_cpu_boost_nodes / sizeof *g_cpu_boost_nodes; i++) {
    const char *p = g_cpu_boost_nodes[i];
    if (access(p, F_OK)) continue;
    if (read_num(p) == 0) continue;
    if (!write_journaled(NODES_JOURNAL, p, 0)) n++;
  }
  if (n) {
    long now = mono_sec();
    if (now - g_boost_log_at >= 600) {
      g_boost_log_at = now;
      log("CPU Boost 已中和（%d 个 walt 节点）", n);
    }
  }
}

static void suppress_boost_restore(void) {
  for (size_t i = 0; i < sizeof g_cpu_boost_nodes / sizeof *g_cpu_boost_nodes; i++)
    boost_restore_path(g_cpu_boost_nodes[i]);
}

/* 动态封顶的三档：0=最优解，1=风格中间档，2=风格地板。 */
#define SUP_OPT     0
#define SUP_MID_LV  1
#define SUP_FLOOR_LV 2
static int g_sup_level;     /* 0=最优解，1=风格中间档，2=风格地板 */
static int sup_profile_level(void);

/* 任务组的 uclamp.min：把前台/系统的"最低性能请求"压到 0。
 * 这不是频率上限，而是调度器选频时的下限；和只压 max_freq 是两件事。
 * 节点不存在（cgroup v2 / 厂商换了布局）就跳过，不猜路径。 */
static const char *g_sup_uclamp_nodes[] = {
    "/dev/cpuctl/top-app/cpu.uclamp.min",
    "/dev/cpuctl/system/cpu.uclamp.min",
    "/dev/cpuctl/cpu/cpu.uclamp.min",
    "/dev/cpuctl/foreground/cpu.uclamp.min",
    "/dev/cpuctl/background/cpu.uclamp.min",
};

static void suppress_uclamp_apply(void) {
  int n = 0;
  for (size_t i = 0; i < sizeof g_sup_uclamp_nodes / sizeof *g_sup_uclamp_nodes; i++) {
    const char *p = g_sup_uclamp_nodes[i];
    if (access(p, F_OK)) continue;
    if (read_num(p) == 0) continue;
    if (!write_journaled(NODES_JOURNAL, p, 0)) n++;
  }
  if (n) log("调度下限已压低（%d 个 uclamp 节点）", n);
}

static void suppress_uclamp_restore(void) {
  for (size_t i = 0; i < sizeof g_sup_uclamp_nodes / sizeof *g_sup_uclamp_nodes; i++)
    boost_restore_path(g_sup_uclamp_nodes[i]);
}

/* 字符串账本：uclamp.max 回读是 "max"/"50.00"，cpuset 是 "0-5"，
 * 数值 journal 记不了。统一记 "<path> <value> <mode>"，还原时原样写回。 */
static int str_journal_has(const char *file, const char *path) {
  FILE *f = fopen(file, "r");
  if (!f) return 0;
  char ln[640], p[512], v[64];
  int mode, hit = 0;
  while (fgets(ln, sizeof ln, f)) {
    if (sscanf(ln, "%511s %63s %o", p, v, &mode) != 3) continue;
    if (!strcmp(p, path)) { hit = 1; break; }
  }
  fclose(f);
  return hit;
}

static int str_journal_add(const char *file, const char *path, const char *val,
                           int mode) {
  FILE *f = fopen(file, "a");
  if (!f) return -1;
  fprintf(f, "%s %s %o\n", path, val, mode);
  fflush(f);
  fsync(fileno(f));
  fclose(f);
  return 0;
}

static int str_write_journaled(const char *file, const char *path,
                               const char *val) {
  if (access(path, F_OK)) return -1;
  if (!str_journal_has(file, path)) {
    char cur[64] = {0};
    if (read_file(path, cur, sizeof cur) || !cur[0]) return -1;
    if (str_journal_add(file, path, cur, read_mode(path))) return -1;
  }
  char now[64] = {0};
  if (!read_file(path, now, sizeof now) && !strcmp(now, val)) return 0;
  chmod(path, 0644);
  return write_str(path, val);
}

static void str_restore_all(const char *file, const char *tag) {
  if (access(file, F_OK)) return;
  FILE *f = fopen(file, "r");
  if (!f) return;
  char ln[640], path[512], val[64];
  int mode, failed = 0, count = 0;
  while (fgets(ln, sizeof ln, f)) {
    if (sscanf(ln, "%511s %63s %o", path, val, &mode) != 3) continue;
    if (access(path, F_OK)) { failed = 1; continue; }
    chmod(path, 0644);
    char now[64] = {0};
    if (write_str(path, val) || read_file(path, now, sizeof now) ||
        strcmp(now, val))
      failed = 1;
    chmod(path, (mode_t)mode);
    count++;
  }
  fclose(f);
  if (failed) {
    log("WARN %s 未完全还原，保留账本下次重试", tag);
    return;
  }
  unlink(file);
  log("%s 已还原 %d 个节点", tag, count);
}

/* 任务组 uclamp.max：动态封顶的第二层，只压上限、不抬下限。
 * 0/1/2 档对应性能/均衡/省电三组参数（top-app / foreground / dex2oat）。
 * 本机回读是 "max"/"50.00"（百分比），也有内核回 0-1024 整数；
 * 按回读自动选刻度，"max"/小数/<=100 按百分比写，>100 按 0-1024 换算。 */
#define UCLAMP_JOURNAL RUN_DIR "/uclamp.saved"
static const struct {
  const char *path;
  int optimal;
  int mid;
  int floor;
} g_sup_umax_nodes[] = {
    { "/dev/cpuctl/top-app/cpu.uclamp.max", 85, 70, 60 },
    { "/dev/cpuctl/foreground/cpu.uclamp.max", 65, 50, 40 },
    { "/dev/cpuctl/dex2oat/cpu.uclamp.max", 45, 30, 20 },
    /* background / system-background 已拆成常驻项（BG_LIGHT），
       不再随动态封顶档位走，也不归这个账本管。 */
};

static int uclamp_scale_of_text(const char *b) {
  if (!b || !b[0]) return 0;
  if (!strcmp(b, "max")) return 100;
  char *end;
  double v = strtod(b, &end);
  if (end == b) return 0;
  return v > 100.0 ? 1024 : 100;
}

static int uclamp_max_scale(const char *path) {
  char b[64] = {0};
  if (read_file(path, b, sizeof b)) return 0;
  trim(b);
  return uclamp_scale_of_text(b);
}

static int uclamp_val_eq(const char *a, const char *b) {
  if (!strcmp(a, b)) return 1;
  char *ea, *eb;
  double da = strtod(a, &ea), db = strtod(b, &eb);
  if (ea == a || eb == b) return 0;
  double d = da > db ? da - db : db - da;
  return d < 0.01;
}

static int uclamp_max_write(const char *path, const char *val) {
  if (access(path, F_OK)) return -1;
  if (!str_journal_has(UCLAMP_JOURNAL, path)) {
    char cur[64] = {0};
    if (read_file(path, cur, sizeof cur) || !cur[0]) return -1;
    if (str_journal_add(UCLAMP_JOURNAL, path, cur, read_mode(path))) return -1;
  }
  char now[64] = {0};
  if (!read_file(path, now, sizeof now) && uclamp_val_eq(now, val)) return 0;
  chmod(path, 0644);
  return write_str(path, val);
}

static void suppress_uclamp_max_apply(void) {
  static int scale_mem[sizeof g_sup_umax_nodes / sizeof *g_sup_umax_nodes];
  static long log_at = -600;
  int n = 0;
  for (size_t i = 0; i < sizeof g_sup_umax_nodes / sizeof *g_sup_umax_nodes; i++) {
    const char *p = g_sup_umax_nodes[i].path;
    if (access(p, F_OK)) continue;
    if (!scale_mem[i]) scale_mem[i] = uclamp_max_scale(p);
    int scale = scale_mem[i];
    if (!scale) continue;
    int prof = sup_profile_level();
    int pct = prof == SUP_FLOOR_LV ? g_sup_umax_nodes[i].floor
            : prof == SUP_MID_LV   ? g_sup_umax_nodes[i].mid
                                   : g_sup_umax_nodes[i].optimal;
    char want[24];
    if (scale == 100) snprintf(want, sizeof want, "%d", pct);
    else snprintf(want, sizeof want, "%ld", (pct * 1024L + 50) / 100);
    if (!uclamp_max_write(p, want)) n++;
  }
  if (n) {
    long now = mono_sec();
    if (now - log_at >= 600) {
      log_at = now;
      log("动态封顶：uclamp 上限已压（%d 个节点）", n);
    }
  }
}

static void suppress_uclamp_max_restore(void) {
  str_restore_all(UCLAMP_JOURNAL, "uclamp.max");
}

/* ── 后台分组常驻轻压制（与动态封顶解耦）────────────────────────
 * background / system-background 只影响后台同步、编译、日志打包这类
 * 对完成时间不敏感的任务，top-app / foreground 一概不碰，所以没有
 * 触摸/唤醒副作用。SUPPRESS 关着也生效，BG_LIGHT=0 可整体关闭。
 * uclamp.max 只降不升；background cpuset 与现有掩码取交集（只收窄，
 * 不扩张厂商已经压得更狠的机器）。原值记独立账本，交权/关闭/卸载还原。 */
#define BGCG_JOURNAL RUN_DIR "/bgcgroup.saved"

static const struct { const char *path; int pct; } g_bg_umax[] = {
    { "/dev/cpuctl/background/cpu.uclamp.max", 50 },
    { "/dev/cpuctl/system-background/cpu.uclamp.max", 60 },
};

/* 读 "0-3,5" 成位图；格式不认识返回 0（调用处不动节点）。 */
static int cpulist_parse(const char *s, unsigned char *set, int n) {
  memset(set, 0, (size_t)n);
  int any = 0;
  const char *p = s;
  while (*p) {
    while (*p == ',' || *p == ' ' || *p == '\n' || *p == '\t') p++;
    if (!*p) break;
    if (!isdigit((unsigned char)*p)) return 0;
    char *end;
    long a = strtol(p, &end, 10);
    if (end == p) return 0;
    long b = a;
    p = end;
    if (*p == '-') {
      p++;
      if (!isdigit((unsigned char)*p)) return 0;
      b = strtol(p, &end, 10);
      if (end == p) return 0;
      p = end;
    }
    if (a < 0 || b < a || b >= n) return 0;
    for (long i = a; i <= b; i++) set[i] = 1;
    any = 1;
    if (*p && *p != ',' && *p != ' ' && *p != '\n' && *p != '\t') return 0;
  }
  return any;
}

static void cpulist_format(const unsigned char *set, int n, char *out, size_t cap) {
  size_t o = 0;
  out[0] = 0;
  for (int i = 0; i < n;) {
    if (!set[i]) { i++; continue; }
    int j = i;
    while (j + 1 < n && set[j + 1]) j++;
    int w = (i == j) ? snprintf(out + o, cap - o, "%s%d", o ? "," : "", i)
                     : snprintf(out + o, cap - o, "%s%d-%d", o ? "," : "", i, j);
    if (w < 0 || (size_t)w >= cap - o) { out[0] = 0; return; }
    o += (size_t)w;
    i = j + 1;
  }
}

/* 后台掩码 = 现有掩码 ∩ 最低频簇。某台厂商已经把 background 压到
 * 0-3 时不会被扩到 0-5；交集为空就跳过，宁可不动也别把后台饿死。 */
static int bg_cpus_mask(char *out, size_t n) {
  if (g_ladder_m < 2) return 0;
  struct policy raw[MAX_POLICY];
  int nr = detect_policies_raw(raw);
  if (nr < 2) return 0;
  long low = raw[0].hw_max;
  int low_no = raw[0].pol_no;
  for (int i = 1; i < nr; i++)
    if (raw[i].hw_max > 0 && raw[i].hw_max < low) {
      low = raw[i].hw_max;
      low_no = raw[i].pol_no;
    }
  unsigned char lowset[MAX_CORES], cur[MAX_CORES], res[MAX_CORES];
  memset(lowset, 0, sizeof lowset);
  for (int c = 0; c < MAX_CORES; c++) {
    if (!core_exists(c)) continue;
    if (core_policy_of(c) == low_no) lowset[c] = 1;
  }
  char b[128] = {0};
  if (read_file("/dev/cpuset/background/cpus", b, sizeof b)) return 0;
  trim(b);
  if (!cpulist_parse(b, cur, MAX_CORES)) return 0;
  int any = 0;
  for (int c = 0; c < MAX_CORES; c++) {
    res[c] = lowset[c] && cur[c];
    any |= res[c];
  }
  if (!any) return 0;
  cpulist_format(res, MAX_CORES, out, n);
  return out[0] != 0;
}

static void bg_light_restore(void) {
  str_restore_all(BGCG_JOURNAL, "后台分组");
}

/* uclamp 回读是 "50.00"/"max"，字符串账本按原样比会永远“不相等”。
 * 返回 1 = 真写了，0 = 已是目标值，-1 = 失败；调用处据此决定要不要记日志。 */
static int bg_uclamp_write(const char *path, const char *val) {
  if (access(path, F_OK)) return -1;
  if (!str_journal_has(BGCG_JOURNAL, path)) {
    char cur[64] = {0};
    if (read_file(path, cur, sizeof cur) || !cur[0]) return -1;
    if (str_journal_add(BGCG_JOURNAL, path, cur, read_mode(path))) return -1;
  }
  char now[64] = {0};
  if (!read_file(path, now, sizeof now)) {
    trim(now);
    if (uclamp_val_eq(now, val)) return 0;
  }
  chmod(path, 0644);
  return write_str(path, val) == 0 ? 1 : -1;
}

static void bg_light_apply(void) {
  if (!cfg.bg_light) { bg_light_restore(); return; }
  int n = 0;
  for (size_t i = 0; i < sizeof g_bg_umax / sizeof *g_bg_umax; i++) {
    const char *p = g_bg_umax[i].path;
    if (access(p, F_OK)) continue;
    int scale = uclamp_max_scale(p);
    if (!scale) continue;
    char want[24];
    if (scale == 100) snprintf(want, sizeof want, "%d", g_bg_umax[i].pct);
    else snprintf(want, sizeof want, "%ld", (g_bg_umax[i].pct * 1024L + 50) / 100);
    /* 只降不升：厂商已经把上限压得比目标更低就保持原样。 */
    char cur[64] = {0};
    if (!read_file(p, cur, sizeof cur)) {
      trim(cur);
      if (strcmp(cur, "max")) {
        char *ce, *we;
        double d = strtod(cur, &ce);
        double target = strtod(want, &we);
        if (ce != cur && we != want && d < target) continue;
      }
    }
    if (bg_uclamp_write(p, want) > 0) n++;
  }
  char mask[64];
  if (bg_cpus_mask(mask, sizeof mask)) {
    const char *p = "/dev/cpuset/background/cpus";
    char cur[64] = {0};
    int same = !read_file(p, cur, sizeof cur);
    if (same) {
      trim(cur);
      same = !strcmp(cur, mask);
    }
    if (!same && !str_write_journaled(BGCG_JOURNAL, p, mask)) n++;
  }
  if (n) log("后台分组已收口（%d 个节点）", n);
}

/* ── cpuset 前后台分区（随动态封顶的中间/地板档）──────────────────
 * 只写 <group>/cpus 掩码，不搬任务、不碰 core_ctl/migt/metis。
 * 数据来自 adapt/<soc>.conf 的 cpuset_<group>_lv1/lv2 行；没有数据的
 * 芯片完全不动。原掩码单独记在 cpuset.saved（字符串账本），
 * 关压制/交权/插电暂停/进程退出/卸载都按原样写回。 */
#define CPUSET_JOURNAL RUN_DIR "/cpuset.saved"
#define CPUSET_GROUPS  4
static const char *g_cpuset_dirs[CPUSET_GROUPS] = {
    "top-app", "foreground", "background", "system-background",
};
static char g_cpuset_mask[3][CPUSET_GROUPS][64];
static unsigned g_cpuset_seen[3];

static int cpuset_group_idx(const char *s) {
  if (!strcmp(s, "top")) return 0;
  if (!strcmp(s, "fg")) return 1;
  if (!strcmp(s, "bg")) return 2;
  if (!strcmp(s, "sysbg")) return 3;
  return -1;
}

/* 只接受 0-7 / 0-1,5-6 这类 CPU 列表；数据文件写错就整行忽略。 */
static int cpuset_mask_valid(const char *s) {
  if (!s || !*s) return 0;
  const char *p = s;
  while (*p) {
    char *end;
    long a = strtol(p, &end, 10);
    if (end == p || a < 0 || a > 1023) return 0;
    p = end;
    if (*p == '-') {
      p++;
      long b = strtol(p, &end, 10);
      if (end == p || b < a || b > 1023) return 0;
      p = end;
    }
    if (*p == ',') {
      p++;
      if (!*p) return 0;
      continue;
    }
    if (*p) return 0;
  }
  return 1;
}

/* cpuset_<top|fg|bg|sysbg>_lv1/lv2=<mask> */
static int cpuset_parse_line(const char *line, int *level, int *group,
                             char *mask, size_t n) {
  if (!line || strncmp(line, "cpuset_", 7)) return 0;
  const char *p = line + 7;
  const char *sep = strstr(p, "_lv");
  if (!sep || sep == p || (sep[3] != '0' && sep[3] != '1' && sep[3] != '2') ||
      sep[4] != '=')
    return 0;
  char g[16];
  size_t gl = (size_t)(sep - p);
  if (gl >= sizeof g) return 0;
  memcpy(g, p, gl);
  g[gl] = 0;
  int gi = cpuset_group_idx(g);
  if (gi < 0) return 0;
  const char *v = sep + 5;
  if (!cpuset_mask_valid(v)) return 0;
  snprintf(mask, n, "%s", v);
  *level = sep[3] - '0';
  *group = gi;
  return 1;
}

static int cpuset_write_journaled(const char *path, const char *mask) {
  if (!cpuset_mask_valid(mask)) return -1;
  return str_write_journaled(CPUSET_JOURNAL, path, mask);
}

static int cpuset_apply_level(int level) {
  static long log_at = -600;
  if (level < 0 || level > 2) return 0;
  int n = 0;
  for (int g = 0; g < CPUSET_GROUPS; g++) {
    /* background 由常驻项 BG_LIGHT 单独管（只收窄到最低簇），
       不再随动态封顶档位切，避免两套逻辑互相改写。 */
    if (g == 2) continue;
    if (!(g_cpuset_seen[level] & (1u << g))) continue;
    char path[160];
    snprintf(path, sizeof path, "/dev/cpuset/%s/cpus", g_cpuset_dirs[g]);
    if (access(path, F_OK)) continue;
    if (!cpuset_write_journaled(path, g_cpuset_mask[level][g])) n++;
  }
  if (n) {
    long now = mono_sec();
    if (now - log_at >= 600) {
      log_at = now;
      log("动态封顶：cpuset 分区已应用（%d 个节点）", n);
    }
  }
  return n;
}

static void cpuset_restore_all(void) {
  str_restore_all(CPUSET_JOURNAL, "cpuset");
}

/* ------------------------------------------------------------------ */
/* 调速器                                                             */
/* ------------------------------------------------------------------ */

static struct policy g_pol[MAX_POLICY];
static int g_npol;

static int prime_cluster_busy(const int *sum, const int *cnt) {
  if (g_npol <= 0) return -1;
  long best_hw = -1;
  int best_pol = -1;
  for (int i = 0; i < g_npol; i++) {
    if (g_pol[i].hw_max > best_hw) {
      best_hw = g_pol[i].hw_max;
      best_pol = g_pol[i].pol_no;
    }
  }
  if (best_pol < 0 || best_pol >= MAX_CORES || cnt[best_pol] <= 0) return -1;
  return sum[best_pol] / cnt[best_pol];
}

/* 智能模式快降判据：每个簇的当前频率都低于自己封顶的一半。
 * 只在目标为空闲时调用，最多读 2~4 个节点；离线簇按"不满足"处理。 */
static int clusters_below_half(void) {
  if (g_npol <= 0) return 0;
  for (int i = 0; i < g_npol; i++) {
    if (g_pol[i].cap <= 0) return 0;
    char path[256];
    snprintf(path, sizeof path, "%s/scaling_cur_freq", g_pol[i].dir);
    if (!freq_below_half(read_num(path), g_pol[i].cap)) return 0;
  }
  return 1;
}
/* 未去重的原始 policy 列表：hispeed 数据按 cluster 序号写，
 * SM8650 这种有两个同频簇的机型不会因为去重丢掉一条。 */
static struct policy g_polraw[MAX_POLICY];
static int g_nraw;

/* ── CPU 封顶第二道锁（MTK PPM / 高通 msm_performance）─────────────
 *
 * 主路径仍然是 scaling_max_freq；后端只在 sysfs 写成功后再加一层厂商
 * 硬限。这样：
 *   - 巡检、回读、RESTORE 判断全部沿用现有逻辑；
 *   - 后端写失败只降级回 sysfs，不会让整个封顶失效；
 *   - 动态封顶/智能/温控/电量偏移不需要各写一套。
 *
 * 恢复原则：只撤自己写的值。厂商已经改过的值不动。
 */
static int g_ppm_ok;        /* /proc/ppm 存在、enabled、节点可读 */
static int g_ppm_enabled;   /* /proc/ppm/enabled 里读到 enabled */
static int g_ppm_lines;     /* PPM 硬限节点里读到的 cluster 行数 */
static int g_msm_ok;        /* msm_performance 节点可读可写 */
static char g_msm_max_path[128];

static long g_ppm_orig[MAX_POLICY];
static long g_ppm_last[MAX_POLICY];
static unsigned g_ppm_has_orig, g_ppm_has_last;  /* bit idx */
static char g_msm_orig[1024], g_msm_last[1024];
static int g_msm_has_orig, g_msm_has_last;

/* 0 和 -1 在 PPM/msm 里都表示“没有限制”，比较时当成无穷大。 */
static long be_eff(long v) { return v > 0 ? v : (1L << 60); }

static const char *cap_backend_name(int be) {
  switch (be) {
    case CAP_BE_PPM: return "ppm";
    case CAP_BE_MSM: return "msm";
    default: return "sysfs";
  }
}

/* 从 PPM 硬限节点里找某个 cluster 的当前值。返回 1=找到，0=没有该行，
 * -1=节点读不到。 */
static int ppm_read_value(int idx, long *out) {
  char b[2048];
  if (read_file(PPM_MAX_NODE, b, sizeof b)) return -1;
  char *save = NULL;
  for (char *ln = strtok_r(b, "\n", &save); ln; ln = strtok_r(NULL, "\n", &save)) {
    int id = -1;
    long v = 0;
    if (sscanf(ln, "%d %ld", &id, &v) == 2 && id == idx) {
      *out = v;
      return 1;
    }
  }
  return 0;
}

static int ppm_count_lines(void) {
  char b[2048];
  if (read_file(PPM_MAX_NODE, b, sizeof b)) return 0;
  int n = 0;
  char *save = NULL;
  for (char *ln = strtok_r(b, "\n", &save); ln; ln = strtok_r(NULL, "\n", &save)) {
    int id = -1;
    long v = 0;
    if (sscanf(ln, "%d %ld", &id, &v) == 2) n++;
  }
  return n;
}

static int ppm_write_value(int idx, long val) {
  char b[64];
  snprintf(b, sizeof b, "%d %ld\n", idx, val);
  return write_text(PPM_MAX_NODE, b);
}

/* ppm.saved：每个 cluster 的原值。只在第一次写某个 cluster 时落盘，
 * 不在 1 秒快拍里反复写 F2FS。 */
static void ppm_journal_save(void) {
  char b[1024];
  b[0] = 0;
  size_t n = 0;
  for (int i = 0; i < MAX_POLICY; i++) {
    if (!(g_ppm_has_orig & (1u << i))) continue;
    if (n >= sizeof b) break;
    int w = snprintf(b + n, sizeof b - n, "%d %ld\n", i, g_ppm_orig[i]);
    if (w < 0) break;
    n += (size_t)w;
    if (n >= sizeof b) break;
  }
  char tmp[sizeof PPM_JOURNAL + 8];
  snprintf(tmp, sizeof tmp, "%s.tmp", PPM_JOURNAL);
  if (write_text_file(tmp, b) == 0) rename(tmp, PPM_JOURNAL);
}

static void ppm_journal_load(void) {
  memset(g_ppm_orig, 0, sizeof g_ppm_orig);
  g_ppm_has_orig = 0;
  FILE *f = fopen(PPM_JOURNAL, "r");
  if (!f) return;
  int idx;
  long v;
  while (fscanf(f, "%d %ld", &idx, &v) == 2)
    if (idx >= 0 && idx < MAX_POLICY) {
      g_ppm_orig[idx] = v;
      g_ppm_has_orig |= 1u << idx;
    }
  fclose(f);
}

/* ppm.last 放在 tmpfs：每次写 PPM 都更新，崩溃后还能判断“这个值是不是
 * 我们写的”；重启后 tmpfs 清空，只剩 ppm.saved 的原值用于兜底。 */
static void ppm_last_save(void) {
  char b[1024];
  b[0] = 0;
  size_t n = 0;
  for (int i = 0; i < MAX_POLICY; i++) {
    if (!(g_ppm_has_last & (1u << i))) continue;
    if (n >= sizeof b) break;
    int w = snprintf(b + n, sizeof b - n, "%d %ld\n", i, g_ppm_last[i]);
    if (w < 0) break;
    n += (size_t)w;
    if (n >= sizeof b) break;
  }
  char tmp[sizeof PPM_LAST + 8];
  snprintf(tmp, sizeof tmp, "%s.tmp", PPM_LAST);
  if (write_text_file(tmp, b) == 0) rename(tmp, PPM_LAST);
}

static void ppm_last_load(void) {
  memset(g_ppm_last, 0, sizeof g_ppm_last);
  g_ppm_has_last = 0;
  FILE *f = fopen(PPM_LAST, "r");
  if (!f) return;
  int idx;
  long v;
  while (fscanf(f, "%d %ld", &idx, &v) == 2)
    if (idx >= 0 && idx < MAX_POLICY) {
      g_ppm_last[idx] = v;
      g_ppm_has_last |= 1u << idx;
    }
  fclose(f);
}

static void ppm_note_orig(int idx, long orig) {
  if (g_ppm_has_orig & (1u << idx)) return;
  g_ppm_orig[idx] = orig;
  g_ppm_has_orig |= 1u << idx;
  ppm_journal_save();
}

static void ppm_note_last(int idx, long val) {
  g_ppm_last[idx] = val;
  g_ppm_has_last |= 1u << idx;
  ppm_last_save();
}

/* 恢复 PPM：clean=1 时连原值账本一起删（停用/卸载）；
 * clean=0 是游戏/熄屏交还，保留原值账本，回常态继续用。 */
static int ppm_restore_all(int clean) {
  int failed = 0, restored = 0;
  for (int i = 0; i < MAX_POLICY; i++) {
    if (!(g_ppm_has_orig & (1u << i))) continue;
    long cur = 0;
    int rr = ppm_read_value(i, &cur);
    if (rr < 0) {
      failed = 1;
      continue;
    }
    int ours = 0;
    if (g_ppm_has_last & (1u << i)) {
      ours = (rr == 1 && cur == g_ppm_last[i]);
    } else {
      /* 重启后 tmpfs 的 last 没了：我们只会把上限压低，所以“当前比原值低”
       * 基本可以认定是模块留下的帽。厂商把值抬得更高时不动。 */
      ours = (rr == 1 && be_eff(cur) < be_eff(g_ppm_orig[i]));
    }
    if (!ours) {
      if (g_ppm_has_last & (1u << i)) {
        log("PPM %d: 保留厂商值 %ld（模块最后写入 %ld）",
            i, cur, g_ppm_last[i]);
        g_ppm_has_last &= ~(1u << i);
      }
      continue;
    }
    if (ppm_write_value(i, g_ppm_orig[i]) == 0) {
      long got = 0;
      if (ppm_read_value(i, &got) == 1 && be_eff(got) == be_eff(g_ppm_orig[i])) {
        restored++;
        g_ppm_has_last &= ~(1u << i);
        log("PPM %d: 已恢复原值 %ld", i, g_ppm_orig[i]);
      } else {
        failed = 1;
      }
    } else {
      failed = 1;
    }
  }
  if (restored) ppm_last_save();
  if (clean) {
    if (failed) {
      log("WARN PPM 恢复未完成，保留 ppm.saved 下次重试");
    } else {
      unlink(PPM_JOURNAL);
      unlink(PPM_LAST);
      g_ppm_has_orig = 0;
      g_ppm_has_last = 0;
    }
  }
  return failed ? -1 : 0;
}

static void ppm_apply(struct policy *p, long want) {
  if (!p || p->be != CAP_BE_PPM || p->ppm_idx < 0 || p->be_fail >= 3) return;
  long cur = 0;
  int rr = ppm_read_value(p->ppm_idx, &cur);
  if (rr < 0) {
    if (p->be_fail++ == 0)
      log("PPM %d: 读取失败，本簇回退 sysfs", p->ppm_idx);
    return;
  }
  if (rr == 0) {
    /* 节点里没有这一行：先按“无限制”记原值，写入后再看能不能读到。 */
    cur = -1;
  }
  if (p->be_last <= 0) ppm_note_orig(p->ppm_idx, cur);
  int ours = 0;
  if (cur == want) {
    ppm_note_last(p->ppm_idx, cur);
    p->be_last = cur;
    return;
  }
  if (be_eff(cur) > be_eff(want)) {
    ours = 1;                       /* 当前比目标高：压回去 */
  } else if (p->be_last > 0 && cur == p->be_last && want > p->be_last) {
    ours = 1;                       /* 是自己的帽，允许放宽 */
  }
  if (!ours) return;                /* 厂商压得更低：保留 */
  if (ppm_write_value(p->ppm_idx, want)) {
    if (p->be_fail++ == 0)
      log("PPM %d: 写入 %ld 失败，本簇回退 sysfs", p->ppm_idx, want);
    return;
  }
  long got = 0;
  int gr = ppm_read_value(p->ppm_idx, &got);
  if (gr != 1 || be_eff(got) > be_eff(want)) {
    if (p->be_fail++ == 0)
      log("PPM %d: 写入 %ld 未生效（回读 %ld）", p->ppm_idx, want, got);
    return;
  }
  p->be_fail = 0;
  p->be_last = got;
  ppm_note_last(p->ppm_idx, got);
}

/* ── 高通 msm_performance ────────────────────────────────────────
 * 节点是一整串 "cpu:freq cpu:freq"。写一个簇时先把现有串解析出来，
 * 只改本簇 CPU，再整体写回，避免把其他簇的限制抹掉。
 */
static void msm_journal_save(void) {
  char tmp[sizeof MSM_JOURNAL + 8];
  snprintf(tmp, sizeof tmp, "%s.tmp", MSM_JOURNAL);
  if (write_text_file(tmp, g_msm_orig) == 0) rename(tmp, MSM_JOURNAL);
}

static void msm_last_save(void) {
  char tmp[sizeof MSM_LAST + 8];
  snprintf(tmp, sizeof tmp, "%s.tmp", MSM_LAST);
  if (write_text_file(tmp, g_msm_last) == 0) rename(tmp, MSM_LAST);
}

static void msm_journal_load(void) {
  g_msm_has_orig = !access(MSM_JOURNAL, F_OK);
  if (g_msm_has_orig) {
    if (read_file(MSM_JOURNAL, g_msm_orig, sizeof g_msm_orig))
      g_msm_orig[0] = 0;
  }
  g_msm_has_last = !access(MSM_LAST, F_OK);
  if (g_msm_has_last) {
    if (read_file(MSM_LAST, g_msm_last, sizeof g_msm_last))
      g_msm_last[0] = 0;
  }
}

static int msm_read_current(char *buf, size_t cap) {
  if (read_file(g_msm_max_path, buf, cap)) {
    buf[0] = 0;
    return access(g_msm_max_path, F_OK) == 0 ? 0 : -1;
  }
  return 0;
}

/* msm 的写语义是“列出的 CPU 改值，没列出的保持原样”。
 * 所以还原不能只写原串：原串里没有的 CPU 会继续吃我们上次写的帽。
 * 正确做法是给所有存在的 CPU 都写一条：原串有值用原值，没有就写 0
 * （实测 0 = 解除该 CPU 的限制，-1 会被内核以 EINVAL 拒绝）。 */
static int msm_build_restore(char *out, size_t cap) {
  long ov[MAX_CORES];
  int oh[MAX_CORES] = {0};
  char *save = NULL;
  char tmp[1024];
  snprintf(tmp, sizeof tmp, "%s", g_msm_orig);
  for (char *tok = strtok_r(tmp, " \t\n", &save); tok;
       tok = strtok_r(NULL, " \t\n", &save)) {
    int c = -1;
    long f = 0;
    if (sscanf(tok, "%d:%ld", &c, &f) == 2 && c >= 0 && c < MAX_CORES) {
      ov[c] = f;
      oh[c] = 1;
    }
  }
  size_t n = 0;
  out[0] = 0;
  for (int c = 0; c < MAX_CORES; c++) {
    char p[64];
    snprintf(p, sizeof p, CPUBASE "/cpu%d", c);
    if (access(p, F_OK)) continue;
    if (n >= cap) break;
    int w = snprintf(out + n, cap - n, "%s%d:%ld", n ? " " : "", c,
                     oh[c] ? ov[c] : 0L);
    if (w < 0) break;
    n += (size_t)w;
    if (n >= cap) break;
  }
  return n > 0;
}

/* 只撤自己写的；clean=1 时删账本。 */
static int msm_restore_all(int clean) {
  int failed = 0;
  if (g_msm_has_orig) {
    char cur[1024];
    if (msm_read_current(cur, sizeof cur) == 0) {
      int ours = g_msm_has_last && !strcmp(cur, g_msm_last);
      if (ours) {
        char payload[1024];
        if (!msm_build_restore(payload, sizeof payload) ||
            write_text(g_msm_max_path, payload)) {
          failed = 1;
        } else {
          char got[1024];
          if (msm_read_current(got, sizeof got) || strcmp(got, payload)) {
            failed = 1;
          } else {
            g_msm_has_last = 0;
            log("msm: 已恢复原值（未列出的 CPU 写 0 解除）");
          }
        }
      } else if (g_msm_has_last) {
        log("msm: 保留厂商值");
        g_msm_has_last = 0;
      }
    } else {
      failed = 1;
    }
  }
  if (clean) {
    if (failed) {
      log("WARN msm 恢复未完成，保留 msm.saved 下次重试");
    } else {
      unlink(MSM_JOURNAL);
      unlink(MSM_LAST);
      g_msm_has_orig = 0;
      g_msm_has_last = 0;
      g_msm_orig[0] = 0;
      g_msm_last[0] = 0;
    }
  } else if (!failed) {
    g_msm_has_last = 0;
    msm_last_save();
  }
  return failed ? -1 : 0;
}

/* 本 policy 管的 CPU 列表（用未去重的 raw policy 补全同频簇）。 */
static int msm_cluster_cpus(const struct policy *p, int *out, int max) {
  int n = 0;
  for (int r = 0; r < g_nraw; r++) {
    if (g_polraw[r].hw_max != p->hw_max) continue;
    for (int c = 0; c < MAX_CORES && n < max; c++)
      if (core_policy_of(c) == g_polraw[r].pol_no) out[n++] = c;
  }
  if (!n) {
    for (int c = 0; c < MAX_CORES && n < max; c++)
      if (core_policy_of(c) == p->pol_no) out[n++] = c;
  }
  return n;
}

static void msm_apply(struct policy *p, long want) {
  if (!p || p->be != CAP_BE_MSM || !g_msm_ok || p->be_fail >= 3) return;
  int cpus[MAX_CORES];
  int nc = msm_cluster_cpus(p, cpus, MAX_CORES);
  if (!nc) return;

  char cur[1024];
  if (msm_read_current(cur, sizeof cur)) {
    p->be_fail++;
    return;
  }
  long mf[MAX_CORES];
  int mh[MAX_CORES] = {0};
  int parsed = 0;
  char *save = NULL;
  for (char *tok = strtok_r(cur, " \t\n", &save); tok;
       tok = strtok_r(NULL, " \t\n", &save)) {
    int c = -1;
    long f = 0;
    if (sscanf(tok, "%d:%ld", &c, &f) == 2 && c >= 0 && c < MAX_CORES) {
      mf[c] = f;
      mh[c] = 1;
      parsed++;
    }
  }
  if (cur[0] && !parsed) {
    if (p->be_fail++ == 0)
      log("msm: 现有内容格式不识别，停用本簇后端");
    return;
  }
  for (int i = 0; i < nc; i++) {
    mf[cpus[i]] = want;
    mh[cpus[i]] = 1;
  }
  char payload[1024];
  payload[0] = 0;
  size_t n = 0;
  for (int c = 0; c < MAX_CORES; c++) {
    if (!mh[c]) continue;
    if (n >= sizeof payload) break;
    int w = snprintf(payload + n, sizeof payload - n, "%s%d:%ld",
                     n ? " " : "", c, mf[c]);
    if (w < 0) break;
    n += (size_t)w;
    if (n >= sizeof payload) break;
  }
  if (!n || !strcmp(payload, cur)) return;
  if (!g_msm_has_orig) {
    snprintf(g_msm_orig, sizeof g_msm_orig, "%s", cur);
    g_msm_has_orig = 1;
    msm_journal_save();
  }
  if (write_text(g_msm_max_path, payload)) {
    if (p->be_fail++ == 0) log("msm: 写入失败，本簇回退 sysfs");
    return;
  }
  char got[1024];
  if (msm_read_current(got, sizeof got) || strcmp(got, payload)) {
    if (p->be_fail++ == 0) log("msm: 写入未生效（回读 %s）", got);
    return;
  }
  p->be_fail = 0;
  p->be_last = want;
  snprintf(g_msm_last, sizeof g_msm_last, "%s", payload);
  g_msm_has_last = 1;
  msm_last_save();
}

static void be_apply_max(struct policy *p, long want) {
  if (!p || want <= 0) return;
  if (p->be == CAP_BE_PPM) ppm_apply(p, want);
  else if (p->be == CAP_BE_MSM) msm_apply(p, want);
}

/* 交权（游戏/熄屏）时把第二道锁放掉。只撤自己写的，厂商值不动。 */
static void be_handback(void) {
  if (g_ppm_ok) ppm_restore_all(0);
  if (g_msm_ok) msm_restore_all(0);
}

/* 停用/卸载/崩溃重启：连账本一起清。 */
static void be_restore_cleanup(void) {
  if (g_ppm_ok) ppm_restore_all(1);
  if (g_msm_ok) msm_restore_all(1);
}

/* 探测节点；不写任何东西。 */
static void cap_backend_detect(void) {
  g_ppm_ok = 0;
  g_ppm_enabled = 0;
  g_ppm_lines = 0;
  g_msm_ok = 0;
  g_msm_max_path[0] = 0;

  if (!access(PPM_DIR, F_OK) && !access(PPM_MAX_NODE, F_OK)) {
    char b[128];
    if (!read_file(PPM_ENABLED, b, sizeof b) && strstr(b, "enabled"))
      g_ppm_enabled = 1;
    if (g_ppm_enabled) {
      g_ppm_lines = ppm_count_lines();
      g_ppm_ok = 1;
    }
  }
  const char *mx = NULL;
  if (!access(MSM_MAX_NODE, R_OK | W_OK)) {
    mx = MSM_MAX_NODE;
  } else if (!access(MSM_MAX_ALT, R_OK | W_OK)) {
    mx = MSM_MAX_ALT;
  }
  if (mx) {
    snprintf(g_msm_max_path, sizeof g_msm_max_path, "%s", mx);
    g_msm_ok = 1;
  }
}

/* 启动时选后端并清掉上次崩溃留下的 PPM/msm 帽。 */
static void cap_backend_init(void) {
  cap_backend_detect();
  char soc[64];
  read_soc_name(soc, sizeof soc);
  int is_mtk = !strncasecmp(soc, "mt", 2);
  for (int i = 0; i < g_npol; i++) {
    g_pol[i].be = CAP_BE_SYSFS;
    g_pol[i].ppm_idx = -1;
    g_pol[i].be_last = 0;
    g_pol[i].be_fail = 0;
  }
  int want = cfg.cap_backend;
  if (want == CAP_BE_AUTO) {
    /* auto 只自动启用 MTK PPM。高通 msm_performance 的写语义是
       “列出的 CPU 改值”，实测不同内核/厂商对清除的处理不一致，
       恢复风险比收益大；要用必须显式 CAP_BACKEND=msm。 */
    if (g_ppm_ok) want = CAP_BE_PPM;
    else {
      want = CAP_BE_SYSFS;
      if (is_mtk) {
        if (!access(PPM_DIR, F_OK)) {
          if (!g_ppm_enabled)
            log("PPM 未启用：/proc/ppm/enabled 不是 enabled（或读不到），只走 sysfs");
          else if (access(PPM_MAX_NODE, F_OK))
            log("PPM 未启用：hard_userlimit_max_cpu_freq 节点不存在，只走 sysfs");
        } else {
          log("PPM 未启用：/proc/ppm 目录不存在，只走 sysfs");
        }
      }
    }
  }
  if (want == CAP_BE_PPM && !g_ppm_ok) {
    log("PPM 不可用（目录/开关/节点不满足），回退 sysfs");
    want = CAP_BE_SYSFS;
  }
  if (want == CAP_BE_MSM && !g_msm_ok) {
    log("msm_performance 节点不可用，回退 sysfs");
    want = CAP_BE_SYSFS;
  }
  /* auto 下簇数对不上就不冒险：PPM cluster 号是顺序假设，错一个会压错簇。
     节点为空（还没写过）时按顺序映射，这是 MTK PPM 的常规形态。 */
  if (want == CAP_BE_PPM && cfg.cap_backend == CAP_BE_AUTO &&
      g_ppm_lines > 0 && g_ppm_lines != g_npol) {
    log("PPM 簇数 %d 与 policy 数 %d 不一致，auto 回退 sysfs",
        g_ppm_lines, g_npol);
    want = CAP_BE_SYSFS;
  }
  /* 先把上次崩溃留下的后端帽清掉，不管这次选哪个后端。
     否则用户从 ppm 切回 sysfs 后，残留的 PPM 帽会继续压着。 */
  int ppm_stale_failed = 0, msm_stale_failed = 0;
  if (g_ppm_ok) {
    ppm_journal_load();
    ppm_last_load();
    if (g_ppm_has_orig && g_ppm_has_last) {
      if (ppm_restore_all(1)) ppm_stale_failed = 1;
    } else if (g_ppm_has_orig) {
      /* 只有原值账本、没有 tmpfs 的 last：基本是重启过，PPM 已复位。
         不按“当前比原值低”去猜，避免把厂商重启后的新值抬回旧值。 */
      unlink(PPM_JOURNAL);
      unlink(PPM_LAST);
      g_ppm_has_orig = 0;
    }
  }
  if (g_msm_ok) {
    msm_journal_load();
    if (g_msm_has_orig && g_msm_has_last) {
      if (msm_restore_all(1)) msm_stale_failed = 1;
    } else if (g_msm_has_orig) {
      unlink(MSM_JOURNAL);
      unlink(MSM_LAST);
      g_msm_has_orig = 0;
      g_msm_has_last = 0;
    }
  }
  if (want == CAP_BE_PPM && ppm_stale_failed) {
    log("PPM 旧帽未还原，回退 sysfs（账本保留，下次再试）");
    want = CAP_BE_SYSFS;
  }
  if (want == CAP_BE_MSM && msm_stale_failed) {
    log("msm 旧帽未还原，回退 sysfs（账本保留，下次再试）");
    want = CAP_BE_SYSFS;
  }
  if (want == CAP_BE_PPM) {
    for (int i = 0; i < g_npol; i++) {
      g_pol[i].be = CAP_BE_PPM;
      g_pol[i].ppm_idx = i;
    }
  } else if (want == CAP_BE_MSM) {
    for (int i = 0; i < g_npol; i++) g_pol[i].be = CAP_BE_MSM;
  }
  if (want == CAP_BE_PPM) {
    char map[256];
    map[0] = 0;
    size_t n = 0;
    for (int i = 0; i < g_npol; i++) {
      if (n >= sizeof map) break;
      int w = snprintf(map + n, sizeof map - n, "%s%s:%d",
                       n ? " " : "", g_pol[i].name, g_pol[i].ppm_idx);
      if (w < 0) break;
      n += (size_t)w;
      if (n >= sizeof map) break;
    }
    log("CPU 封顶后端：MTK PPM（%d 簇，%s）", g_npol, map);
  } else if (want == CAP_BE_MSM) {
    log("CPU 封顶后端：高通 msm_performance（%s）", g_msm_max_path);
  } else {
    log("CPU 封顶后端：sysfs（未启用 PPM/msm 第二道锁）");
  }
}

/* probe 用：只报告，不改 g_pol，也不恢复任何东西。 */
static void cap_backend_report(const struct policy *p, int n) {
  cap_backend_detect();
  int want = cfg.cap_backend;
  if (want == CAP_BE_AUTO) {
    if (g_ppm_ok && (g_ppm_lines == 0 || g_ppm_lines == n)) want = CAP_BE_PPM;
    else want = CAP_BE_SYSFS;
  }
  printf("capbe_cfg=%s\n", cfg.cap_backend == CAP_BE_AUTO ? "auto"
                            : cap_backend_name(cfg.cap_backend));
  printf("capbe=%s\n", cap_backend_name(want));
  printf("ppm_dir=%d\nppm_enabled=%d\nppm_node=%d\nppm_lines=%d\n",
         !access(PPM_DIR, F_OK), g_ppm_enabled, !access(PPM_MAX_NODE, F_OK),
         g_ppm_lines);
  {
    char raw[1024];
    if (read_file(PPM_MAX_NODE, raw, sizeof raw)) raw[0] = 0;
    for (char *c = raw; *c; c++) if (*c == '\n' || *c == '\r') *c = ' ';
    printf("ppm_raw_max=%s\n", raw);
  }
  printf("msm_ok=%d\nmsm_node=%s\n", g_msm_ok, g_msm_ok ? g_msm_max_path : "-");
  if (g_msm_ok) {
    char raw[1024];
    if (read_file(g_msm_max_path, raw, sizeof raw)) raw[0] = 0;
    for (char *c = raw; *c; c++) if (*c == '\n' || *c == '\r') *c = ' ';
    printf("msm_raw_max=%s\n", raw);
  }
  printf("ppm_map=");
  for (int i = 0; i < n; i++)
    printf("%s%s:%d", i ? " " : "", p[i].name, (want == CAP_BE_PPM) ? i : -1);
  printf("\n");
}

/* 厂商调速器一律不碰：hmbird / scx 这类自有调度会把写权限从调度器
 * 手里夺走，和"游戏态把权限交还系统"冲突。 */
static int is_vendor_gov(const char *g) {
  return !strncmp(g, "hmbird", 6) || !strncmp(g, "scx", 3);
}

/* ── 升频限速（调度器通用调参）────────────────────────────────────
 * 把每个 policy 调速器的 up/down_rate_limit_us 统一到 1000µs：升频
 * 每 ms 至多一次，削平触摸/渲染突发造成的频率尖峰；降频同样 1ms，
 * 负载掉下去立刻回落。walt / interactive / schedutil（含 MTK
 * sugov_ext）都有这对节点，路径按各 policy 实际调速器名拼
 * （<policy>/<gov>/<param>，个别内核放在 policy 根下，两处都试）。
 * 厂商自有调速器（hmbird/scx）不碰。值记进账本，交权/关闭/卸载还原。 */
static int gov_param_path(int i, const char *param, char *out, size_t cap) {
  char gov[32] = {0};
  char gp[256];
  snprintf(gp, sizeof gp, "%s/scaling_governor", g_pol[i].dir);
  if (read_file(gp, gov, sizeof gov)) return 0;
  trim(gov);
  if (!gov[0] || is_vendor_gov(gov)) return 0;
  snprintf(out, cap, "%s/%s/%s", g_pol[i].dir, gov, param);
  if (!access(out, F_OK)) return 1;
  snprintf(out, cap, "%s/%s", g_pol[i].dir, param);
  return !access(out, F_OK);
}

/* 档位 → 限速参数下标：0=超大核 1=大核（MID2/MID 共用） 2=小核 */
static int gov_rate_idx(int tier) {
  if ((tier & 3) == 0) return 0;
  if ((tier & 3) == 3) return 2;
  return 1;
}

/* 配置里的 GOV_* 是“手动基准”：还是旧默认或均衡默认时，跟随压制风格
 * 自动换表；用户改过的簇按用户值。省电升得更慢、降得更快；
 * 均衡保留跟手节奏。 */
static void gov_rate_for(int ri, int *up, int *down) {
  static const int old_up[3] = {3000, 2000, 1000};
  static const int old_dn[3] = {1000, 1500, 2000};
  static const int bal_up[3] = {3000, 2000, 1500};
  static const int bal_dn[3] = {800, 800, 500};
  static const int sav_up[3] = {5000, 3000, 2000};
  static const int sav_dn[3] = {500, 500, 500};
  int u = cfg.gov_up_us[ri], d = cfg.gov_down_us[ri];
  int auto_u = (u == old_up[ri] || u == bal_up[ri]);
  int auto_d = (d == old_dn[ri] || d == bal_dn[ri]);
  *up = auto_u ? (cfg.sup_style ? sav_up[ri] : bal_up[ri]) : u;
  *down = auto_d ? (cfg.sup_style ? sav_dn[ri] : bal_dn[ri]) : d;
}

static void suppress_smooth_apply(void) {
  int n = 0;
  for (int i = 0; i < g_npol; i++) {
    char path[320];
    int ri = gov_rate_idx(g_pol[i].tier);
    int up, down;
    gov_rate_for(ri, &up, &down);
    static const char *const params[] = { "up_rate_limit_us", "down_rate_limit_us" };
    for (size_t k = 0; k < sizeof params / sizeof *params; k++) {
      if (!gov_param_path(i, params[k], path, sizeof path)) continue;
      long want = k == 0 ? up : down;
      if (read_num(path) == want) continue;   /* 已是目标值：不重复写 */
      if (!write_journaled(NODES_JOURNAL, path, want)) n++;
    }
  }
  if (n) {
    int u0, d0, u1, d1, u2, d2;
    gov_rate_for(0, &u0, &d0);
    gov_rate_for(1, &u1, &d1);
    gov_rate_for(2, &u2, &d2);
    log("调速器限速已应用（%d 个节点；超/大/小 %d-%d/%d-%d/%d-%dµs，%s）", n,
        u0, d0, u1, d1, u2, d2, cfg.sup_style ? "省电" : "均衡");
  }
}

static void suppress_smooth_restore(void) {
  for (int i = 0; i < g_npol; i++) {
    char path[320];
    static const char *const params[] = { "up_rate_limit_us", "down_rate_limit_us" };
    for (size_t k = 0; k < sizeof params / sizeof *params; k++) {
      if (!gov_param_path(i, params[k], path, sizeof path)) continue;
      boost_restore_path(path);
    }
  }
}

/* ── 逐芯片调速器工作点参数（gov_[lv1_|lv2_]<tier>_<节点名>=数字）──
 * 数据在 adapt/<soc>.conf：**有 gov_ 行的芯片才调节**，没有就完全不
 * 碰这一层（参数错了是负优化，宁缺毋滥）。不带 lv 前缀 = 0 档兼容
 * 旧数据；lv1/lv2 分别对应动态封顶的中间/地板档。参数名 = 调速器
 * tunables 的节点名（walt: hispeed_freq / hispeed_load / …），值
 * 必须是纯数字；target_loads 这类带空格的表暂不支持（journal 是
 * 数值型）。应用：<policy>/<调速器>/<节点>（个别内核放 policy 根下
 * 也兜底），厂商自有调速器（hmbird/scx）不碰。hispeed_freq 高于
 * 当前档封顶时整簇跳过。值记进账本，换档/交权/关闭还原。 */
#define GOV_TIER_N     4
#define GOV_LEVELS     3
#define GOV_KV_MAX     12
#define GOV_PARAM_MAX  48
struct gov_kv { char param[GOV_PARAM_MAX]; long val; };
static struct gov_kv g_govkv[GOV_LEVELS][GOV_TIER_N][GOV_KV_MAX];
static int g_govkn[GOV_LEVELS][GOV_TIER_N];
/* 按 cluster 序号（policy 号升序）的写法：gov_lv1_cl0_hispeed_freq=…
 * SM8650 这种两个簇同频、会被 tier 去重吃掉的机型靠这一层。 */
static struct gov_kv g_govcl[GOV_LEVELS][MAX_POLICY][GOV_KV_MAX];
static int g_govcln[GOV_LEVELS][MAX_POLICY];
static int g_gov_have;
static char g_gov_applied[128][128];
static int  g_gov_applied_n;

/* 纯函数：解析一行 gov_[lv1_|lv2_]<tier>_<param>=<数字>。
 * 不带 lv 前缀 = 0 档（旧数据兼容）。
 * 返回 1 成功；0 = 不是 gov 行 / tier 不认识 / 参数名非法 / 值非纯数字。 */
static int gov_parse_line(const char *line, int *level, int *tier, char *param,
                          size_t pn, long *val) {
  static const char *const tiers[GOV_TIER_N] = { "big", "mid2", "mid", "little" };
  if (!line || strncmp(line, "gov_", 4)) return 0;
  const char *rest = line + 4;
  int lv = 0;
  if (!strncmp(rest, "lv0_", 4)) { lv = 0; rest += 4; }
  else if (!strncmp(rest, "lv1_", 4)) { lv = 1; rest += 4; }
  else if (!strncmp(rest, "lv2_", 4)) { lv = 2; rest += 4; }
  for (int t = 0; t < GOV_TIER_N; t++) {
    size_t tl = strlen(tiers[t]);
    if (strncmp(rest, tiers[t], tl) || rest[tl] != '_') continue;
    const char *p = rest + tl + 1;
    const char *eq = strchr(p, '=');
    if (!eq || eq == p) return 0;
    size_t pl = (size_t)(eq - p);
    if (pl >= pn) return 0;
    for (size_t c = 0; c < pl; c++)
      if (!isalnum((unsigned char)p[c]) && p[c] != '_') return 0;
    const char *v = eq + 1;
    while (*v == ' ' || *v == '\t') v++;
    if (!isdigit((unsigned char)*v)) return 0;
    char num[24]; size_t ni = 0;
    while (isdigit((unsigned char)v[ni]) && ni < sizeof num - 1) ni++;
    /* 值必须是纯数字：85:1344000 这类 target_loads 表不能被截成 85 写进节点。 */
    while (v[ni] == ' ' || v[ni] == '\t' || v[ni] == '\r' || v[ni] == '\n') ni++;
    if (v[ni] != 0) return 0;
    char tmp[24];
    memcpy(tmp, v, ni); tmp[ni] = 0;
    memcpy(param, p, pl); param[pl] = 0;
    *val = strtol(tmp, NULL, 10);
    *level = lv;
    *tier = t;
    return 1;
  }
  return 0;
}

/* 纯函数：gov_[lv0_|lv1_|lv2_]cl<N>_<param>=<数字>。
 * cluster 序号按 policy 号升序（和 detect_policies_raw 的顺序一致）。 */
static int gov_cl_parse_line(const char *line, int *level, int *cl, char *param,
                             size_t pn, long *val) {
  if (!line || strncmp(line, "gov_", 4)) return 0;
  const char *rest = line + 4;
  int lv = 0;
  if (!strncmp(rest, "lv0_", 4)) { lv = 0; rest += 4; }
  else if (!strncmp(rest, "lv1_", 4)) { lv = 1; rest += 4; }
  else if (!strncmp(rest, "lv2_", 4)) { lv = 2; rest += 4; }
  if (strncmp(rest, "cl", 2)) return 0;
  char *end;
  long idx = strtol(rest + 2, &end, 10);
  if (end == rest + 2 || idx < 0 || idx >= MAX_POLICY || *end != '_') return 0;
  const char *p = end + 1;
  const char *eq = strchr(p, '=');
  if (!eq || eq == p) return 0;
  size_t pl = (size_t)(eq - p);
  if (pl >= pn) return 0;
  for (size_t c = 0; c < pl; c++)
    if (!isalnum((unsigned char)p[c]) && p[c] != '_') return 0;
  const char *v = eq + 1;
  while (*v == ' ' || *v == '\t') v++;
  if (!isdigit((unsigned char)*v)) return 0;
  char num[24]; size_t ni = 0;
  while (isdigit((unsigned char)v[ni]) && ni < sizeof num - 1) ni++;
  while (v[ni] == ' ' || v[ni] == '\t' || v[ni] == '\r' || v[ni] == '\n') ni++;
  if (v[ni] != 0) return 0;
  memcpy(num, v, ni); num[ni] = 0;
  memcpy(param, p, pl); param[pl] = 0;
  *val = strtol(num, NULL, 10);
  *level = lv;
  *cl = (int)idx;
  return 1;
}

/* 从 adapt.conf 读 gov_/cpuset_ 行。装机脚本按 #match 选中的那份会落到
 * $DATA/adapt.conf；没有时退回按 SoC 文件名找模块内 adapt/<soc>.conf。 */
static void suppress_gov_load(void) {
  char soc[64], path[256];
  read_soc_name(soc, sizeof soc);
  for (char *c = soc; *c; c++) *c = (char)tolower((unsigned char)*c);
  snprintf(path, sizeof path, SF_DATADIR "/adapt.conf");
  FILE *f = fopen(path, "r");
  if (!f) {
    snprintf(path, sizeof path, SF_MODDIR "/adapt/%s.conf", soc);
    f = fopen(path, "r");
    if (!f && strlen(soc) > 1 && soc[strlen(soc) - 1] == 'p') {
      /* SM8750P / SM8850P 这类地区后缀：没有独立文件就吃基础型号的数据。 */
      soc[strlen(soc) - 1] = 0;
      snprintf(path, sizeof path, SF_MODDIR "/adapt/%s.conf", soc);
      f = fopen(path, "r");
    }
  }
  if (!f) {
    log("调速器工作点：%s 无适配数据，不调节", soc);
    return;
  }
  char line[512];
  int cpuset_groups = 0;
  while (fgets(line, sizeof line, f)) {
    char *h = strchr(line, '#');
    if (h) *h = 0;
    trim(line);   /* CRLF 文件：cpuset 掩码会把行尾 \r 当成非法字符 */
    int lv, group; char mask[64];
    if (cpuset_parse_line(line, &lv, &group, mask, sizeof mask)) {
      snprintf(g_cpuset_mask[lv][group], sizeof g_cpuset_mask[lv][group],
               "%s", mask);
      g_cpuset_seen[lv] |= 1u << group;
      cpuset_groups++;
      continue;
    }
    int cl; char cparam[GOV_PARAM_MAX]; long cval;
    if (gov_cl_parse_line(line, &lv, &cl, cparam, sizeof cparam, &cval)) {
      int dup = 0;
      for (int k = 0; k < g_govcln[lv][cl]; k++)
        if (!strcmp(g_govcl[lv][cl][k].param, cparam)) dup = 1;
      if (dup || g_govcln[lv][cl] >= GOV_KV_MAX) continue;
      snprintf(g_govcl[lv][cl][g_govcln[lv][cl]].param, GOV_PARAM_MAX, "%s",
               cparam);
      g_govcl[lv][cl][g_govcln[lv][cl]].val = cval;
      g_govcln[lv][cl]++;
      g_gov_have = 1;
      continue;
    }
    int tier; char param[GOV_PARAM_MAX]; long val;
    if (!gov_parse_line(line, &lv, &tier, param, sizeof param, &val)) continue;
    int dup = 0;
    for (int k = 0; k < g_govkn[lv][tier]; k++)
      if (!strcmp(g_govkv[lv][tier][k].param, param)) dup = 1;
    if (dup || g_govkn[lv][tier] >= GOV_KV_MAX) continue;
    snprintf(g_govkv[lv][tier][g_govkn[lv][tier]].param, GOV_PARAM_MAX, "%s", param);
    g_govkv[lv][tier][g_govkn[lv][tier]].val = val;
    g_govkn[lv][tier]++;
    g_gov_have = 1;
  }
  fclose(f);
  if (g_gov_have) {
    int total = 0;
    for (int lv = 0; lv < GOV_LEVELS; lv++) {
      for (int t = 0; t < GOV_TIER_N; t++) total += g_govkn[lv][t];
      for (int c = 0; c < MAX_POLICY; c++) total += g_govcln[lv][c];
    }
    log("调速器工作点：%s 适配含 %d 组参数（随动态封顶档位生效）", soc, total);
  }
  if (cpuset_groups)
    log("cpuset 分区：%s 适配含 %d 个掩码（随动态封顶档位生效）",
        soc, cpuset_groups);
}

static long sup_cap_for(const struct policy *p);

/* hispeed_ratio = 千分比：把对位 JSON 的 hispeed/该模式上限，
 * 落到我们当前档的封顶上。绝对值在高封顶机型上会高于我们的档位
 * 封顶而被整簇跳过，比例写法不会。ratio=0 表示写 0（关闭）。 */
static long hispeed_from_ratio(long cap, long ratio) {
  if (ratio <= 0) return 0;
  if (cap <= 0) return -1;
  return cap * ratio / 1000;
}

static void suppress_gov_apply(void) {
  if (!cfg.suppress || !g_gov_have) return;
  int lv = sup_profile_level();
  if (lv < 0) lv = 0;
  if (lv >= GOV_LEVELS) lv = GOV_LEVELS - 1;
  /* 省电静态低功耗档：hispeed 交给缩放封顶，保持 0，
     否则调速器一见负载就把频率抬回硬件上限。 */
  int static_floor = cfg.sup_style && g_sup_level == SUP_FLOOR_LV;
  int n = 0;
  for (int i = 0; i < g_npol; i++) {
    int tier = g_pol[i].tier;
    if (tier < 0 || tier >= GOV_TIER_N) continue;
    char gov[32] = {0};
    char gp[256];
    snprintf(gp, sizeof gp, "%s/scaling_governor", g_pol[i].dir);
    if (read_file(gp, gov, sizeof gov)) continue;
    trim(gov);
    if (!gov[0] || is_vendor_gov(gov)) continue;
    /* hispeed 高于本档封顶等于没写：跳过整簇，避免把无效工作点
       当成"已生效"记进账本。 */
    long cur_cap = sup_cap_for(&g_pol[i]);
    int skip_tier = 0;
    if (!static_floor) {
      for (int k = 0; k < g_govkn[lv][tier]; k++) {
        if (!strcmp(g_govkv[lv][tier][k].param, "hispeed_freq") &&
            cur_cap > 0 && g_govkv[lv][tier][k].val >= cur_cap) {
          skip_tier = 1;
          break;
        }
      }
    }
    if (skip_tier) continue;
    for (int k = 0; k < g_govkn[lv][tier]; k++) {
      char path[320];
      const char *param = g_govkv[lv][tier][k].param;
      long val = g_govkv[lv][tier][k].val;
      if (static_floor && !strcmp(param, "hispeed_freq")) val = 0;
      snprintf(path, sizeof path, "%s/%s/%s", g_pol[i].dir, gov, param);
      if (access(path, F_OK))
        snprintf(path, sizeof path, "%s/%s", g_pol[i].dir, param);
      if (access(path, F_OK)) continue;       /* 该内核没有此节点：跳过 */
      if (read_num(path) == val) continue;    /* 已是目标值 */
      if (!write_journaled(NODES_JOURNAL, path, val)) {
        n++;
        if (g_gov_applied_n < 128) {
          snprintf(g_gov_applied[g_gov_applied_n], 128, "%s", path);
          g_gov_applied_n++;
        }
      }
    }
  }
  /* cluster 写法：直接对原始 policy 列表下单，同频簇也不会丢。 */
  for (int i = 0; i < g_nraw; i++) {
    if (!g_govcln[lv][i]) continue;
    struct policy *rp = &g_polraw[i];
    char gov[32] = {0};
    char gp[256];
    snprintf(gp, sizeof gp, "%s/scaling_governor", rp->dir);
    if (read_file(gp, gov, sizeof gov)) continue;
    trim(gov);
    if (!gov[0] || is_vendor_gov(gov)) continue;
    struct policy *rep = NULL;
    long cur_cap = 0;
    for (int j = 0; j < g_npol; j++)
      if (g_pol[j].hw_max == rp->hw_max) {
        rep = &g_pol[j];
        cur_cap = sup_cap_for(rep);
        break;
      }
    char sp[320];
    long cur_max = 0, cur_min = 0;
    snprintf(sp, sizeof sp, "%s/scaling_max_freq", rp->dir);
    cur_max = read_num(sp);
    snprintf(sp, sizeof sp, "%s/scaling_min_freq", rp->dir);
    cur_min = read_num(sp);
    int skip = 0;
    if (!static_floor) {
      for (int k = 0; k < g_govcln[lv][i]; k++) {
        const char *param = g_govcl[lv][i][k].param;
        long val = g_govcl[lv][i][k].val;
        if (!strcmp(param, "hispeed_freq") &&
            ((cur_cap > 0 && val >= cur_cap) ||
             (cur_min > 0 && val < cur_min))) {
          skip = 1;
          break;
        }
      }
    }
    if (skip) continue;
    for (int k = 0; k < g_govcln[lv][i]; k++) {
      char path[320];
      const char *param = g_govcl[lv][i][k].param;
      long val = g_govcl[lv][i][k].val;
      const char *node = param;
      if (static_floor &&
          (!strcmp(param, "hispeed_freq") || !strcmp(param, "hispeed_ratio"))) {
        node = "hispeed_freq";
        val = 0;
      } else if (!strcmp(param, "hispeed_ratio")) {
        node = "hispeed_freq";
        long base = cur_max > 0 ? cur_max : cur_cap;
        long r = hispeed_from_ratio(base, val);
        if (r < 0) continue;
        if (val > 0) {
          if (!rep) continue;
          r = snap_freq(rep, r);
          if (r <= rep->hw_min) continue;  /* 落到硬件最低以下：跳过 */
          if (cur_min > 0 && r < cur_min) continue; /* 低于当前下限：跳过 */
        }
        val = r;
      }
      snprintf(path, sizeof path, "%s/%s/%s", rp->dir, gov, node);
      if (access(path, F_OK)) snprintf(path, sizeof path, "%s/%s", rp->dir, node);
      if (access(path, F_OK)) continue;
      if (read_num(path) == val) continue;
      if (!write_journaled(NODES_JOURNAL, path, val)) {
        n++;
        if (g_gov_applied_n < 128) {
          snprintf(g_gov_applied[g_gov_applied_n], 128, "%s", path);
          g_gov_applied_n++;
        }
      }
    }
  }
  if (n) log("调速器工作点已应用（%d 个节点）", n);
}

static void suppress_gov_restore(void) {
  for (int i = 0; i < g_gov_applied_n; i++) boost_restore_path(g_gov_applied[i]);
  g_gov_applied_n = 0;
}

/* 档位附加层：uclamp.max + cpuset + 分级 hispeed 一起随 g_sup_level 换。
 * 换档先还原上一档再写新档；0 档（最优解）不额外限制。 */
static int g_sup_extra_level = -1;

static void suppress_extra_restore(void) {
  suppress_uclamp_max_restore();
  cpuset_restore_all();
  suppress_gov_restore();
  g_sup_extra_level = -1;
}

static void suppress_extra_apply(void) {
  if (!cfg.suppress) {
    if (g_sup_extra_level >= 0) suppress_extra_restore();
    return;
  }
  int prof = sup_profile_level();
  if (g_sup_extra_level != prof) {
    suppress_uclamp_max_restore();
    cpuset_restore_all();
    suppress_gov_restore();
    g_sup_extra_level = prof;
  }
  suppress_uclamp_max_apply();
  cpuset_apply_level(prof);
  suppress_gov_apply();
}

/* 荣耀/华为/三星的 cpufreq 只认自家调度策略：把 scaling_governor 切成
 * conservative / schedutil 这类通用实现，部分内核会直接 panic 并重启。
 * 这三个品牌一律不改写调速器（游戏态交还、退出还原都不需要做），
 * 日志里说明一次，避免用户以为"选了没生效"。
 * 结果缓存：apply_governor 每个巡检周期都会走到。 */
static int governor_locked(void) {
  static int cached = -1;
  if (cached < 0) {
    char b[64] = "", m[64] = "";
    __system_property_get("ro.product.brand", b);
    __system_property_get("ro.product.manufacturer", m);
    cached = !strncasecmp(b, "honor", 5) || !strncasecmp(m, "honor", 5) ||
             !strncasecmp(b, "huawei", 6) || !strncasecmp(m, "huawei", 6) ||
             !strncasecmp(b, "samsung", 7) || !strncasecmp(m, "samsung", 7);
  }
  return cached;
}

/* 在空白分隔的列表里整词查找。
 * 不能用 strstr(" gov ")：read_file 会把尾随空白剥掉，列表首项没有前导空格、
 * 末项没有尾随空格，包着空白的 needle 对这两项永远失配 —— 用户把
 * conservative 设成首选（很多内核排第一）时，等于调速器功能静默失效。 */
static int token_has(const char *list, const char *word) {
  size_t n = strlen(word);
  if (!n) return 0;
  const char *p = list;
  while (*p) {
    while (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r') p++;
    const char *s = p;
    while (*p && *p != ' ' && *p != '\t' && *p != '\n' && *p != '\r') p++;
    if ((size_t)(p - s) == n && !strncmp(s, word, n)) return 1;
  }
  return 0;
}

static void apply_governor(const struct policy *p) {
  if (!cfg.governor[0]) return;
  if (p->offline) return;   /* 簇离线：节点读不到，别做无效写入 */
  if (governor_locked()) {
    static int warned = 0;
    if (!warned) {
      log("  荣耀/华为/三星内核不切换调速器，CPU_GOVERNOR 已忽略");
      warned = 1;
    }
    return;
  }
  char path[224], cur[64], avail[512];
  snprintf(path, sizeof path, "%s/scaling_governor", p->dir);
  if (read_file(path, cur, sizeof cur)) return;
  if (!strcmp(cur, cfg.governor) || is_vendor_gov(cur)) return;
  snprintf(path, sizeof path, "%s/scaling_available_governors", p->dir);
  if (read_file(path, avail, sizeof avail)) return;
  if (!token_has(avail, cfg.governor)) {
    log("WARN %s 不支持调速器 %s（可用: %s）", p->name, cfg.governor, avail);
    return;
  }
  /* 调速器是字符串，单独记一份账，恢复时按名字写回 */
  snprintf(path, sizeof path, "%s/scaling_governor", p->dir);
  if (!journal_has(GOV_JOURNAL, path)) {
    journal_add(GOV_JOURNAL, path, 0, read_mode(path));
    FILE *f = fopen(GOV_JOURNAL, "a");
    if (f) {
      fprintf(f, "%s %s\n", path, cur);
      fclose(f);
    }
  }
  chmod(path, 0644);
  if (write_str(path, cfg.governor))
    log("WARN %s 调速器写入失败 -> %s", p->name, cfg.governor);
  else
    log("  %s 调速器 -> %s", p->name, cfg.governor);
}

static void snapshot_governors(void) {
  unlink(GOV_JOURNAL);
  for (int i = 0; i < g_npol; i++) {
    char path[224], cur[64];
    snprintf(path, sizeof path, "%s/scaling_governor", g_pol[i].dir);
    if (read_file(path, cur, sizeof cur)) continue;
    journal_add(GOV_JOURNAL, path, 0, read_mode(path));
    FILE *f = fopen(GOV_JOURNAL, "a");
    if (f) {
      fprintf(f, "%s %s\n", path, cur);
      fclose(f);
    }
  }
}

/* keep=1：只把名字写回出厂值，账本留着（交权用，回常态还要按用户选择再写一次）；
   keep=0：连同权限一起还原并删账本（切"不干预"、停用、卸载）。 */
static int restore_governors_core(int keep) {
  if (access(GOV_JOURNAL, F_OK)) return 0;
  FILE *f = fopen(GOV_JOURNAL, "r");
  if (!f) return 0;
  char line[512], node[512], gov[64];
  int mode, failed = 0, count = 0;
  while (fgets(line, sizeof line, f)) {
    /* govs.saved 里同一个节点有两行：
     *   "<path> 0 <mode>"     <- journal_add 记的权限（第三段是八进制）
     *   "<path> <governor>"   <- 记的调速器名字（只有两段）
     * 两行都要认，只按 sscanf==3 取会拿到权限那一行，
     * 把字面量 "0" 写进 scaling_governor，而名字那行被挡掉，
     * 恢复完的调速器是个 "0"，内核多半拒收。
     *
     *   三段 -> 只取权限，不写值（和 perms_restore 一个道理，
     *          max_pwrlevel 这种 0 是合法索引值）
     *   两段 -> 第二段就是名字，写回去
     */
    if (sscanf(line, "%511s %63s %o", node, gov, &mode) == 3) {
      /* 权限那一行：名字位置是占位的 0，不许写 */
      if (access(node, F_OK)) continue;
      if (chmod(node, (mode_t)mode)) failed = 1;
      else count++;
      continue;
    }
    if (sscanf(line, "%511s %63s", node, gov) != 2) continue;
    if (!gov[0] || strspn(gov, "01234567") == strlen(gov)) continue; /* 纯八进制数不是名字 */
    if (access(node, F_OK)) continue;
    /* 权限先记下来，写完再还回去。
     * 写之前读一次当前权限：这时权限行已经恢复成出厂值了。
     * 硬编码 0644 会盖掉它——出厂 scaling_governor 是 0664 的机型上
     * （system 组要写，perfd 换调速器靠它），模块一停、一卸载，
     * 厂商调度就再也写不动调速器了，而且一句日志都不会有。
     */
    int before = read_mode(node);
    chmod(node, 0644);
    if (write_str(node, gov)) failed = 1;
    else count++;
    if (chmod(node, before)) failed = 1;
  }
  fclose(f);
  if (failed) {
    log("WARN 调速器恢复未完成，保留快照下次重试");
    return -1;
  }
  if (!keep) {
    unlink(GOV_JOURNAL);
    log("已恢复 %d 个调速器", count);
  }
  return count;
}

static void restore_governors(void) { (void)restore_governors_core(0); }

/* ------------------------------------------------------------------ */
/* 游戏判定                                                           */
/* ------------------------------------------------------------------ */

static char g_pkgs[MAX_PKG][PKG_LEN];
static int g_npkg;
static uint64_t g_pkg_stamp;

/* 按纳秒级指纹判重，避免每轮都重读整个名单 */
static void load_game_pkgs(void) {
  uint64_t stamp = file_stamp(GAME_LIST);
  if (!stamp || stamp == g_pkg_stamp) return;
  FILE *f = fopen(GAME_LIST, "r");
  if (!f) return;
  g_npkg = 0;
  char line[PKG_LEN];
  while (fgets(line, sizeof line, f) && g_npkg < MAX_PKG) {
    trim(line);
    if (!line[0] || *line == '#' || !strchr(line, '.')) continue;
    int dup = 0;
    for (int i = 0; i < g_npkg; i++)
      if (!strcmp(g_pkgs[i], line)) dup = 1;
    if (dup) continue;
    snprintf(g_pkgs[g_npkg], PKG_LEN, "%s", line);
    g_npkg++;
  }
  fclose(f);
  g_pkg_stamp = stamp;
  log("游戏名单已加载: %d 个包名", g_npkg);
}

/*
 * 抓一行里的前台包名。
 *
 * 真实 dumpsys 的这几种行，窗口 token 后面只有一个用户号：
 *   mCurrentFocus=Window{a1b2c3 u0 com.foo.bar/com.foo.bar.Main}
 *   mFocusedApp=AppWindowToken{u0 com.foo.bar/com.foo.bar.Main}
 *   mTopFullscreenOpaqueWindowState=Window{9f2b1a u0 com.foo.bar/...}
 * 按此格式一次匹配：越过 " u" 两位再读用户号，其后即为包名。
 */
/*
 * 没有 " u0" 的 ROM（部分 realme / ColorOS）也抓一次：
 * 例如 mCurrentFocus=Window{abc com.foo.bar/com.foo.bar.Main}
 * 从每个 '/' 往前走，取包名字符串；必须含点，避免把纯 Activity 名当真。
 */
static int grab_pkg_relaxed(const char *line, char *out) {
  const char *p = line;
  while ((p = strchr(p, '/'))) {
    const char *s = p;
    while (s > line) {
      char c = s[-1];
      if (!(isalnum((unsigned char)c) || c == '.' || c == '_' || c == ':')) break;
      s--;
    }
    size_t l = (size_t)(p - s);
    if (l) {
      for (size_t i = 0; i < l; i++)
        if (s[i] == ':') { l = i; break; }   /* 分身/多开：剥掉 :process */
      int dot = 0, ok = 1;
      for (size_t i = 0; i < l; i++) {
        char c = s[i];
        if (c == '.') dot = 1;
        if (!(isalnum((unsigned char)c) || c == '.' || c == '_')) { ok = 0; break; }
      }
      if (ok && dot && l >= 4 && l < PKG_LEN) {
        memcpy(out, s, l);
        out[l] = 0;
        return 0;
      }
    }
    p++;
  }
  return -1;
}

static int grab_pkg(const char *line, char *out) {
  const char *p = strstr(line, " u");
  if (!p) return grab_pkg_relaxed(line, out);
  p += 2; /* 越过 " u"，落在用户号上 */
  if (!isdigit((unsigned char)*p)) return grab_pkg_relaxed(line, out);
  while (isdigit((unsigned char)*p)) p++;
  /* 有些 ROM 的窗口行是 u0a123（用户号 + app id），不是 u0。
     不认这一段会让 mCurrentFocus 永远解析失败，游戏态也就永远不触发。 */
  if (*p == 'a') {
    p++;
    if (!isdigit((unsigned char)*p)) return grab_pkg_relaxed(line, out);
    while (isdigit((unsigned char)*p)) p++;
  }
  if (*p != ' ') return grab_pkg_relaxed(line, out);
  p++;
  /*
   * p 现在指向包名首字符。包名一路到斜杠或冒号：
   * 分身/多开/工作资料常报 com.foo.bar:remote，冒号后面是进程名，
   * 游戏名单和分应用档位存的都是基础包名，要把这段剥掉再匹配。
   */
  size_t l = 0;
  while (p[l] && p[l] != '/' && p[l] != ':') l++;
  if (!p[l] || l >= PKG_LEN) return grab_pkg_relaxed(line, out);
  /* 只接受包名允许的字符，杜绝把 Activity 路径或异常内容当成包名 */
  for (size_t i = 0; i < l; i++) {
    char c = p[i];
    if (!(isalnum((unsigned char)c) || c == '.' || c == '_'))
      return grab_pkg_relaxed(line, out);
  }
  memcpy(out, p, l);
  out[l] = 0;
  return 0;
}

/* 游戏助手/浮窗：ColorOS/realme 的风驰、游戏空间、游戏助手会把焦点抢到
 * 自己的包上，真正的游戏在它下面。遇到这些包时改看 mFocusedApp / 全屏窗口。 */
static int is_game_overlay(const char *p) {
  return p && (strstr(p, "gamespace") || strstr(p, "gameassist") ||
               strstr(p, "gameopt") || strstr(p, "gamecenter") ||
               strstr(p, "oplus.games") || strstr(p, "coloros.games"));
}

static int is_game(const char *pkg);

/*
 * 从 dumpsys 输出流里取前台包名。
 * 独立成函数，便于对同一段解析逻辑喂入 dumpsys 文本复用。
 */
static int fg_from_stream(FILE *f, char *out) {
  char line[2048];
  char focus[PKG_LEN] = {0}, app[PKG_LEN] = {0};
  char resumed[PKG_LEN] = {0}, top[PKG_LEN] = {0};
  char game[PKG_LEN] = {0};
  while (fgets(line, sizeof line, f)) {
    int kind = 0;
    if (strstr(line, "mCurrentFocus")) kind = 1;
    else if (strstr(line, "mFocusedApp")) kind = 2;
    else if (strstr(line, "mResumedActivity") ||
             strstr(line, "topResumedActivity")) kind = 3;
    else if (strstr(line, "mTopFullscreenOpaqueWindowState")) kind = 4;
    if (!kind) continue;
    char tmp[PKG_LEN] = {0};
    if (grab_pkg(line, tmp)) continue;
    /* 每一条窗口行都参与“游戏候选”判断：录屏/虚拟显示会把游戏放到
       第二个 display，主 display 的前台可能只是浮窗；只看第一条会漏。 */
    if (!game[0] && is_game(tmp) && !is_game_overlay(tmp))
      snprintf(game, sizeof game, "%s", tmp);
    if (kind == 1 && !focus[0]) snprintf(focus, sizeof focus, "%s", tmp);
    else if (kind == 2 && !app[0]) snprintf(app, sizeof app, "%s", tmp);
    else if (kind == 3 && !resumed[0]) snprintf(resumed, sizeof resumed, "%s", tmp);
    else if (kind == 4 && !top[0]) snprintf(top, sizeof top, "%s", tmp);
  }

  const char *pick = focus[0] ? focus
                   : (app[0] ? app
                   : (resumed[0] ? resumed : top));
  /* 小窗/浮窗抢焦点，但全屏窗口仍是游戏：游戏没退，不要按小窗包名
     判成离开游戏。普通应用切到前台时 top 会变成应用自己，不会命中。 */
  if (pick && game[0] && top[0] && is_game(top) && !is_game(pick))
    pick = top;
  /* 工具类浮窗在上面挡着时，优先用它下面真正的游戏，其次才是全屏窗口 */
  if (pick && (!strcmp(pick, "com.omarea.vtools") ||
               !strcmp(pick, "bin.mt.plus") ||
               !strcmp(pick, "bin.mt.plus.canary"))) {
    if (game[0]) pick = game;
    else if (top[0]) pick = top;
  }
  /* 厂商游戏助手/风驰浮窗抢焦点时，改看它下面的游戏进程 */
  if (pick && is_game_overlay(pick)) {
    if (game[0]) pick = game;
    else if (app[0] && !is_game_overlay(app)) pick = app;
    else if (top[0] && !is_game_overlay(top)) pick = top;
    else if (resumed[0] && !is_game_overlay(resumed)) pick = resumed;
  }
  if (!pick || !pick[0]) return -1;
  snprintf(out, PKG_LEN, "%s", pick);
  return 0;
}

/* 取前台包名。dumpsys 会卡，套 timeout，否则 pclose 一直等。 */
static int foreground_pkg(char *out) {
  FILE *f = popen("timeout 2 dumpsys window 2>/dev/null", "r");
  if (!f) return -1;
  int rc = fg_from_stream(f, out);
  pclose(f);
  return rc;
}

/* ── 前台探测节流 ──────────────────────────────────────────────
 * dumpsys window 是本守护最贵的一步（本机实测 ~49 ms/次，5 秒一拍
 * 就是 17280 次/天，约 14 核·分钟/天，还要把大核叫醒一万七千次）。
 * 但它只在前台**换人**时才需要重跑：先在 /dev/cpuset/top-app/cgroup.procs
 * 上读一次 PID 集合（一次 open，几微秒），集合没变就沿用上一拍的包名。
 *
 * 为什么不用"固定 TTL 缓存"：那是给一个循环里
 * 多个调用点共用一次探测设计的；这里每拍只探一次，TTL 短于巡检周期时
 * 等于没缓存。集合变化才是真正的"可能换前台"信号，而且延迟仍是一拍，
 * 游戏解锁不受影响。
 *
 * 输入法、tts、system_server、surfaceflinger 常驻 top-app，换应用时
 * 它们的 PID 不变，变的是应用进程 → 判据按"集合是否相同"，并先排序，
 * 内核给的顺序不保证稳定。 */
#define FG_PIDS_MAX 64
#define FG_FORCE_S  60   /* 集合一直不变也每 60 秒强探一次（防同进程内切焦点） */
#define FG_FAIL_S   10   /* 探失败后 10 秒内不重复砸 dumpsys */

/* 可观测性：每拍一次 tick，只有真的跑了 dumpsys 才 +1。
 * 页面上不显示，但 run/status 里能直接算出"这一版把探测降了多少"，
 * 不用 strace 也能验收。 */
static long g_tick_n;
static long g_fg_probe_n;
static long g_fg_pids[FG_PIDS_MAX];
static int  g_fg_npid;
static char g_fg_cache[PKG_LEN];
static int  g_fg_cache_ok;
static long g_fg_probed_at;

/* 纯函数：空格/换行分隔的 PID 列表 → 升序数组。返回个数。单测直接喂字符串。 */
static int parse_pid_list(char *b, long *out, int max) {
  int c = 0;
  for (char *p = b; *p && c < max; ) {
    while (*p == '\n' || *p == '\r' || *p == ' ' || *p == '\t') p++;
    if (!*p) break;
    char *end = NULL;
    long v = strtol(p, &end, 10);
    if (end == p) break;
    if (v > 0) out[c++] = v;
    p = end;
  }
  for (int i = 1; i < c; i++) {
    long k = out[i];
    int j = i - 1;
    while (j >= 0 && out[j] > k) { out[j + 1] = out[j]; j--; }
    out[j + 1] = k;
  }
  return c;
}

/* 读 top-app 的 PID 集合。返回个数；-1 = 读不到（调用处回落到每拍探测）。 */
static int topapp_pids(long *out, int max) {
  int fd = open("/dev/cpuset/top-app/cgroup.procs", O_RDONLY);
  if (fd < 0) return -1;
  static char b[2048];
  ssize_t n = read(fd, b, sizeof b - 1);
  close(fd);
  if (n <= 0) return -1;
  b[n] = 0;
  return parse_pid_list(b, out, max);
}

static int same_pids(const long *a, int na, const long *b, int nb) {
  if (na != nb) return 0;
  for (int i = 0; i < na; i++)
    if (a[i] != b[i]) return 0;
  return 1;
}

/* 带节流的前台探测。语义与 foreground_pkg 相同：0 = 拿到包名，-1 = 没拿到。
   force=1 时不看 top-app PID 缓存，直接 dumpsys；游戏态下小窗抢焦点
   但 top-app 集合没变时，缓存会把小窗包名一直喂回来。 */
static int foreground_pkg_throttled_ex(char *out, int force) {
  long pids[FG_PIDS_MAX];
  int np = topapp_pids(pids, FG_PIDS_MAX);
  long now = mono_sec();
  int changed = 1;
  if (np >= 0) {
    changed = !same_pids(pids, np, g_fg_pids, g_fg_npid);
    for (int i = 0; i < np; i++) g_fg_pids[i] = pids[i];
    g_fg_npid = np;
  }
  long ttl = g_fg_cache_ok ? FG_FORCE_S : FG_FAIL_S;
  if (!force && !changed && g_fg_probed_at > 0 && now - g_fg_probed_at < ttl) {
    if (!g_fg_cache_ok) return -1;      /* 上一拍也没探到：别每拍都砸一次 */
    snprintf(out, PKG_LEN, "%s", g_fg_cache);
    return 0;
  }
  int rc = foreground_pkg(out);
  g_fg_probe_n++;
  g_fg_probed_at = now ? now : 1;
  if (rc == 0) {
    snprintf(g_fg_cache, sizeof g_fg_cache, "%s", out);
    g_fg_cache_ok = 1;
  } else {
    g_fg_cache[0] = 0;
    g_fg_cache_ok = 0;
  }
  return rc;
}

static int foreground_pkg_throttled(char *out) {
  return foreground_pkg_throttled_ex(out, 0);
}

/* 包名比较：忽略进程后缀（:xxx）。部分游戏的前台窗口报的是
 * com.foo.game:remote，而名单里只能填 com.foo.game。 */
static int pkg_base_eq(const char *a, const char *b) {
  size_t la = strcspn(a, ":");
  size_t lb = strcspn(b, ":");
  return la == lb && !strncmp(a, b, la);
}

static int is_game(const char *pkg) {
  for (int i = 0; i < g_npkg; i++)
    if (pkg_base_eq(g_pkgs[i], pkg)) return 1;
  return 0;
}

/* ------------------------------------------------------------------ */
/* 分应用档位（app_modes.conf）                                        */
/* ------------------------------------------------------------------ */

/* 一行一条，值是以下三种之一：
 *   full        两者都交还系统（和游戏解锁同一条路，pct=MODE_FULL）
 *   80          只管 CPU；GPU 跟随全局，和加冒号之前的老写法完全一样
 *   80:40        CPU 和 GPU 各自封顶；任一边留空表示那一边跟随全局（80: / :40）
 *   keep        熄屏时不交还，继续按全局百分比巡检（挂机/编译场景）
 * 优先级：游戏名单 > 满血窗口（开机）> 应用专属 > 全局。
 * 熄屏策略见 SCREEN_POLICY；keep 只影响熄屏，不影响亮屏时的全局分档。 */
#define MODE_FULL (-1)
#define MODE_KEEP (-2)
#define MODE_SOFF (-3)   /* 熄屏时交还，亮屏仍按全局 */
struct app_mode {
  char pkg[PKG_LEN];
  int pct;    /* MODE_FULL / MODE_KEEP / MODE_SOFF / 0（CPU 跟随全局）或 1..100 */
  int big;    /* 0 = 跟随 pct/全局；否则 BIG 簇 1..100 */
  int little; /* 0 = 跟随 pct/全局；否则 LITTLE 簇 1..100 */
  int gpu;    /* 0 = GPU 跟随全局，否则 1..100 */
};
static struct app_mode g_modes[MAX_PKG];
static int g_nmode;
static uint64_t g_mode_stamp;

/* 当前生效的应用档位：包名 + 值。空串 = 没有生效中的专属档位 */
static char g_app[PKG_LEN];
static int g_app_pct;
static int g_app_big;
static int g_app_little;
/* 应用专属 GPU 档位，0 = 跟随全局 GPU_PCT。full 走交还系统那条路，不在这里。 */
static int g_app_gpu;

/* 读一个档位文件。路径做成参数，便于指向临时件而不改用户生效的配置。 */
static int load_app_modes_from(const char *path) {
  uint64_t stamp = file_stamp(path);
  if (!stamp) { g_nmode = 0; g_mode_stamp = 0; return 0; }
  if (stamp == g_mode_stamp) return g_nmode;
  FILE *f = fopen(path, "r");
  if (!f) return g_nmode;
  g_nmode = 0;
  char line[512];
  while (fgets(line, sizeof line, f) && g_nmode < MAX_PKG) {
    trim(line);
    if (!line[0] || *line == '#') continue;
    char *eq = strchr(line, '=');
    if (!eq) continue;
    *eq = 0;
    char *pkg = line, *val = eq + 1;
    trim(pkg);
    trim(val);
    /* 值后面允许跟一段注释：学习写回来的那条长这样
     *   com.foo.bar=75  #learn
     * 截掉注释再判数字，否则整行会被当成坏行丢掉——表现是"页面上明明有一条
     * 档位，核心上却没戴帽"，最难查的就是这种静默失效。 */
    char *hash = strchr(val, '#');
    if (hash) { *hash = 0; trim(val); }
    /* 包名必须含点且字符合法：和 api.sh 的 is_package 同一套判据。
     * 守护这侧宽松了，就等于把"写进去的一条坏行"变成"读起来行为不明"。 */
    if (!pkg[0] || !strchr(pkg, '.') || strlen(pkg) >= PKG_LEN) continue;
    for (char *c = pkg; *c; c++)
      if (!isalnum((unsigned char)*c) && *c != '.' && *c != '_') { pkg[0] = 0; break; }
    if (!pkg[0]) continue;
    int pct = 0, gpuv = 0, bigv = 0, litv = 0;
    char *colon = strchr(val, ':');
    char *gpu_part = NULL;
    if (colon) {
      *colon = 0;
      gpu_part = colon + 1;
      trim(val);
      trim(gpu_part);
    }
    if (!val[0] && (!gpu_part || !gpu_part[0])) continue;
    char *slash = strchr(val, '/');
    if (slash) {
      /* big/little：只给 BIG 和 LITTLE 两档；MID/MID2 跟随全局。
       * 两段都必须给，避免 70/ 这种"看着设了其实没设"的歧义。 */
      *slash = 0;
      char *bp = val, *lp = slash + 1;
      trim(bp); trim(lp);
      if (!bp[0] || !lp[0]) continue;
      if (bp[strspn(bp, "0123456789")] || lp[strspn(lp, "0123456789")]) continue;
      bigv = atoi(bp);
      litv = atoi(lp);
      if (bigv < 1 || bigv > 100 || litv < 1 || litv > 100) continue;
    } else if (!val[0]) {
      /* :40 = 只设 GPU，CPU 四档全部跟随全局 */
    } else if (!strcmp(val, "full") || !strcmp(val, "FULL")) {
      if (gpu_part) continue;   /* full 不带 GPU 段 */
      pct = MODE_FULL;
    } else if (!strcmp(val, "keep") || !strcmp(val, "KEEP")) {
      if (gpu_part) continue;
      pct = MODE_KEEP;      /* 只影响熄屏；亮屏仍按全局分档 */
    } else if (!strcmp(val, "soff") || !strcmp(val, "SOFF")) {
      if (gpu_part) continue;
      pct = MODE_SOFF;      /* 熄屏时交还系统；亮屏仍按全局分档 */
    } else if (val[strspn(val, "0123456789")]) {
      continue;             /* 非纯数字 */
    } else {
      pct = atoi(val);
      if (pct < 1 || pct > 100) continue;
    }
    if (gpu_part && gpu_part[0]) {
      if (gpu_part[strspn(gpu_part, "0123456789")]) continue;
      gpuv = atoi(gpu_part);
      if (gpuv < 1 || gpuv > 100) continue;
    }
    int dup = 0;
    for (int i = 0; i < g_nmode; i++)
      if (!strcmp(g_modes[i].pkg, pkg)) {
        g_modes[i].pct = pct;
        g_modes[i].big = bigv;
        g_modes[i].little = litv;
        g_modes[i].gpu = gpuv;
        dup = 1;
        break;
      }
    if (dup) continue;      /* 同一包重复出现：取后一条，不再加一行 */
    snprintf(g_modes[g_nmode].pkg, PKG_LEN, "%s", pkg);
    g_modes[g_nmode].pct = pct;
    g_modes[g_nmode].big = bigv;
    g_modes[g_nmode].little = litv;
    g_modes[g_nmode].gpu = gpuv;
    g_nmode++;
  }
  fclose(f);
  g_mode_stamp = stamp;
  log("分应用档位已加载: %d 条", g_nmode);
  return g_nmode;
}

static void load_app_modes(void) { load_app_modes_from(MODE_FILE); }

/* 命中返回 1 并给出 CPU 统一值 / BIG / LITTLE / GPU 四段；
 * 0 表示该段跟随全局/上一层。 */
static int mode_lookup(const char *pkg, int *out, int *out_big, int *out_little,
                       int *out_gpu) {
  if (!pkg || !pkg[0]) return 0;
  for (int i = 0; i < g_nmode; i++)
    if (pkg_base_eq(g_modes[i].pkg, pkg)) {
      if (out) *out = g_modes[i].pct;
      if (out_big) *out_big = g_modes[i].big;
      if (out_little) *out_little = g_modes[i].little;
      if (out_gpu) *out_gpu = g_modes[i].gpu;
      return 1;
    }
  return 0;
}

/* 重算每个 policy 的封顶值。app_pct>0 = 四档统一；app_big/app_little>0 =
 * 只覆盖 BIG/LITTLE，中间档跟随全局；全 0 = 回到全局分档。
 * assign_pct 每档都打一行日志，切应用太吵，所以这里只重算不打表。
 * tier 沿用 assign_pct 已经算好的档位归属（同一硬件上限的多个 policy
 * 要一起降，不能各算各的）。 */
static void set_caps_tiers(int app_pct, int app_big, int app_little, const char *why) {
  for (int i = 0; i < g_npol; i++) {
    int t = g_pol[i].tier & 3;
    int pct, explicit = 0, big_min_hit = 0;
    if (t == 0 && app_big > 0) {
      pct = app_big;
      explicit = 1;
    } else if (t == 3 && app_little > 0) {
      pct = app_little;
      explicit = 1;
    } else if (app_pct > 0) {
      pct = app_pct;
      explicit = 1;
    } else {
      pct = cfg.pct[t];
    }
    /* 超大核省电：全局 BIG 没被应用单独指定时压到最低频 */
    if (!explicit && cfg.big_min && t == 0) {
      pct = 1;
      explicit = 1;
      big_min_hit = 1;
    }
    if (pct < 1 || pct > 100) pct = 1;
    /* 专属档位也吃实时偏移（热了照样降），但不吃充电态那块地板；
       超大核最低频连 PSI 借档也不吃，否则 1% 会被抬成 11%。 */
    pct = big_min_hit ? 1 : eff_pct(pct, explicit);
    g_pol[i].pct = pct;
    g_pol[i].cap = cap_floor_apply(&g_pol[i],
                                   snap_freq(&g_pol[i], cap_from_pct(&g_pol[i], pct)));
  }
  if (app_pct > 0 || app_big > 0 || app_little > 0)
    log("  封顶重算（%s 专属档位 %d/%d/%d）", why, app_pct, app_big, app_little);
  else log("  封顶重算（%s）", why);
}

static void set_caps(int app_pct, const char *why) {
  set_caps_tiers(app_pct, 0, 0, why);
}

/* GPU 的生效值。只吃温控与电量阶梯两项收紧偏移，PSI 不参与：
 * GPU_PCT 和应用 GPU 档都是用户明确设的上限，插电不该替他改。
 * 单独拆出来是为了自检能喂任意 delta，不必去改 adapt 的内部状态。 */
static long gpu_target_for(int base_pct, int delta) {
  int pct = (base_pct > 0 ? base_pct : cfg.gpu_pct) + delta;
  if (pct < 1) pct = 1;
  if (pct > 100) pct = 100;
  return gpu_snap(pct);
}

static long gpu_target(void) {
  int base = g_app_gpu > 0 ? g_app_gpu : cfg.gpu_pct;
  struct adapt a;
  adapt_snapshot(&a);
  /* 充电地板同样抬 GPU：只抬 CPU 不抬 GPU，插电打游戏仍会被 GPU 上限
   * 卡在 60 帧。应用专属 GPU 档是用户明确设的，不抬。
   * 温控/电量阶梯的收紧叠在这块地板之上，热了照样降。 */
  /* GPU 只吃"收紧"项：温控 + 电量阶梯。PSI 是 CPU 排队信号，
     拿它给 GPU 抬帽只会增加功耗和发热，不能算"GPU 卡了"。 */
  int d = -(a.th_steps * cfg.ad.th_step) - a.batt_cut;
  /* 应用 GPU 档是用户明确设的，电量阶梯不往下盖它。 */
  if (g_app_gpu > 0) d += a.batt_cut;
  /* 和 CPU 同一口径：有收紧时不抬充电地板 */
  if (g_app_gpu <= 0 && !g_screen_off && a.chg_on && a.chg_pct > base && d >= 0)
    base = a.chg_pct;
  return gpu_target_for(base, d);
}

/* 把 GPU 上限写到当前目标值。force=0 时目标没变就不重复写。 */
static void apply_gpu_cap(int force) {
  if (!g_gpu.ok) return;
  long t = gpu_target();
  if (!force && t == g_gpu.active) return;
  write_gpu(t, 0);
  g_gpu.active = t;
}

/* GPU 稳态巡检：厂商 boost/调频会把上限顶回去，CPU 那条巡检管不到它。
 * 目标值和 apply_normal 用同一个 gpu_target()，温控/应用 GPU 档压下去后
 * 不会被静态 normal 顶回来。分应用档位分支和常态分支都要走这里；
 * 游戏/满血/熄屏是交权态，不能调。 */
static void gpu_patrol(void) {
  if (!g_gpu.ok) return;
  long t = gpu_target();
  long got = read_num(g_gpu.max_node);
  if (g_gpu.ged) got = gpu_ged_freq_of((int)got);
  else if (g_gpu.max_is_mhz && got > 0) got *= 1000000;
  if (got > t) write_gpu(t, 0);
  g_gpu.active = t;
  gpu_min_to_floor();
  /* 厂商 powerhal / 调试口可能把 idle_timer 改回 80：每轮补一次，
     值已经是 48 就只做一次 read，不写节点。 */
  kgsl_idle_trim();
}

/* ── 动态封顶（持续负载驱动的三档天花板）────────────────────────────
 * 亮屏常态把长睡切成 1s 快拍，天花板分三档：用户最优解、风格中间档、
 * 风格地板。持续低载先降到中间档，再连续低载才降到地板；
 * 连续高载超过释放线时，先放一档而不是直接回满，仍高载下一拍才回最优解。
 * 不用 cur_freq 贴顶判饥饿：960 静置档的 cap 本身就是当前频点，会自激振荡；
 * 改用排除 CPU0 的持续负载，地板 60 / 中间 75 才回升，换档后先稳 6 秒。
 * 到地板且低载持续 5 拍，把各簇下限压到硬件最低；活动恢复时还原。
 * 进游戏/满血/熄屏自动暂停，暂停点调 sup_exit()/sup_cancel()
 * 把天花板与下限交还；压制写入会同步 last_cap/last_got，既有 force
 * 路径能无缝接管。系统调度器自己的升频仍由它决定，这里只收紧
 * "允许蹿到的上限"。 */
#define SUP_FALL       20    /* busy<20：计入降档 */
#define SUP_MIN_TICKS  5     /* 到地板且低载，连续这么多拍才压下限 */
#define SUP_RELEASE_FLOOR 60 /* 地板→中间：busy 连续过线才放 */
#define SUP_RELEASE_MID   75 /* 中间→最优解：要求更高，避免两级连跳 */
#define SUP_STATIC_TICKS   3
#define SUP_LEVEL_HOLD_S   6 /* 换档后先稳这么久，再允许继续升/降 */
#define SUP_STATIC_HZ  960000L /* 省电风格静置上限：对齐到真实频点 */
/* 风格参数（SUP_STYLE）：均衡 = 地板 80%、中间 90%；省电 = 地板 960MHz、
 * 中间 85%。低载先到中间，再连续低载到地板；持续高载先回中间，仍高载回满。 */
static int sup_floor(void)      { return cfg.sup_style ? 70 : 80; }
static int sup_mid(void)        { return cfg.sup_style ? 85 : 90; }
static int sup_fall_ticks(void) { return cfg.sup_style ? 2 : 3; }

static int g_sup_fall_n;    /* 连续低载计数 */
static int g_sup_up_n;      /* 连续高载计数：2 拍才放一档，滤掉滑动抖动 */
static int g_sup_min_n;     /* 到底后连续空闲计数 */
static int g_sup_min_on;    /* 下限已压 */
static int g_sup_floor_busy_n; /* 连续高载计数（地板要求更久） */
static long g_sup_level_at; /* 当前档位进入时刻，换档后先稳住 */
static int g_sup_last_busy = -1; /* 最近一次压制负载样本，仅 status 诊断用 */
static int g_sup_chg_pause; /* 插电暂停中（插电不封顶策略） */
static long g_sup_reapply_at; /* 上次补写 boost/uclamp 的时刻 */
/* 内核钳制记忆：写 max 被夹回（目标低于该簇实际下限）时记住回读值，
 * 600s 内不再对更低的目标做无效写入——否则会变成每秒一次的空转刷写。 */
static long g_sup_stuck[MAX_POLICY];
static long g_sup_stuck_at[MAX_POLICY];

static int sup_pct(void) {
  if (g_sup_level == SUP_FLOOR_LV) return sup_floor();
  if (g_sup_level == SUP_MID_LV) return sup_mid();
  return 100;
}

/* 附加层（uclamp.max / cpuset / hispeed）用哪一档：
 * bal 按 0/1/2；sav 把 0 档也压到均衡组，1/2 档用省电组。
 * 这样选“省电风格”时，活跃的 0 档不会还挂着性能组的 85/65/45 和 fg 0-6。 */
static int sup_profile_level(void) {
  if (!cfg.sup_style) return g_sup_level;
  return g_sup_level <= SUP_OPT ? SUP_MID_LV : SUP_FLOOR_LV;
}

/* 省电风格的“静置地板”：不是 cap 的 70%，而是绝对 960MHz 起步，
 * 向上对齐本簇真实频点；不低于硬件最低频，也不越过用户 cap。
 * Find N5 的 CPU_FLOOR_M 仍优先，M 簇不会被它压到 1.78GHz 以下。 */
static long sup_static_floor_for(const struct policy *p) {
  long f = SUP_STATIC_HZ;
  if (p->hw_min > f) f = p->hw_min;
  if (p->cap > 0 && f > p->cap) f = p->cap;
  f = snap_up_freq(p, f);
  if (f <= 0) f = p->cap;
  return cap_floor_apply(p, f);
}

static long sup_cap_for(const struct policy *p) {
  if (g_sup_level <= SUP_OPT) return p->cap;
  if (cfg.sup_style && g_sup_level == SUP_FLOOR_LV)
    return sup_static_floor_for(p);
  /* 按用户设定的百分比继续收；BIG_MIN 已经把 cap 放到硬件最低时，
     下面的乘法会低于下限，这里夹回 hw_min，避免写一个必被内核拒绝的值。
     早期版本在 SM8750/SM8850 上无条件把超大核钉到最低，轻任务也能触发，
     表现为"超大核一直最低频、手动切换才恢复"；现在只按百分比收。 */
  long want = p->cap * sup_pct() / 100;
  if (p->hw_min > 0 && want < p->hw_min) want = p->hw_min;
  return cap_floor_apply(p, snap_freq(p, want));
}

/* 用户设的进阶最低频；0 = 没设，返回 0。目标夹在 hw_min 与当前封顶之间，
 * 避免 min > max 被内核拒绝。 */
static long user_min_for(const struct policy *p) {
  int pct = cfg.min_pct[p->tier & 3];
  if (pct < 1) return 0;
  long want = p->hw_max * pct / 100;
  want = snap_freq(p, want);
  if (p->hw_min > 0 && want < p->hw_min) want = p->hw_min;
  if (p->cap > 0 && want > p->cap) want = p->cap;
  return want;
}

/* 模块自己的下限目标：用户设了就用用户的，否则用硬件最低。 */
static long min_floor_for(const struct policy *p) {
  long u = user_min_for(p);
  return u > 0 ? u : p->hw_min;
}

/* 下限压放（记账）。on=0 时只还原本策略压过的，不动系统后来的改写。 */
static void sup_min_clamp(int on) {
  for (int i = 0; i < g_npol; i++) {
    if (g_pol[i].hw_min <= 0) continue;
    char path[256];
    long target = (cfg.sup_style && g_sup_level == SUP_FLOOR_LV)
                      ? g_pol[i].hw_min
                      : min_floor_for(&g_pol[i]);
    if (target <= 0) continue;
    snprintf(path, sizeof path, "%s/scaling_min_freq", g_pol[i].dir);
    if (on) {
      long cur = read_num(path);
      if (cur <= 0) continue;
      if (cur != target && !write_journaled(NODES_JOURNAL, path, target))
        g_sup_min_on = 1;
      /* 下限已经/刚刚被放松，之前因 min>max 留下的"写不进"退避要立刻作废，
         否则天花板会在旧下限上多卡 10 分钟。 */
      g_sup_stuck[i] = 0;
    } else if (g_sup_min_on) {
      boost_restore_path(path);
    }
  }
  if (!on) g_sup_min_on = 0;
}

/* 退出压制——只清标志与还原下限，不动天花板：
 * 交权路径（游戏/满血）自己会把上限写到硬件最高，这里再写 cap 会
 * 把刚放开的帽又压回去。 */
static void sup_cancel(void) {
  g_sup_level = 0;
  g_sup_fall_n = 0;
  g_sup_up_n = 0;
  g_sup_min_n = 0;
  g_sup_floor_busy_n = 0;
  g_sup_level_at = 0;
  g_sup_reapply_at = 0;
  if (g_sup_min_on) sup_min_clamp(0);
}

/* 退出压制并回到生效封顶：留在常态的暂停点（熄屏、配置关闭）用。 */
static void sup_exit(void) {
  sup_cancel();
  suppress_boost_restore();
  suppress_smooth_restore();
  suppress_gov_restore();
  suppress_uclamp_restore();
  suppress_extra_restore();
  for (int i = 0; i < g_npol; i++) {
    char path[256];
    long want = g_pol[i].cap;
    snprintf(path, sizeof path, "%s/scaling_max_freq", g_pol[i].dir);
    long cur = read_num(path);
    if (cur < 0) continue;          /* 簇离线：节点读不到，跳过 */
    if (want > 0 && cur != want) {
      if (!write_journaled(NODES_JOURNAL, path, want)) {
        long got = read_num(path);
        g_pol[i].last_cap = want;
        g_pol[i].last_got = got > 0 ? got : want;
        be_apply_max(&g_pol[i], want);
      }
    }
  }
}

/* 每个快拍调一次（亮屏常态尾部，1s 粒度）。 */
static void suppress_tick(void) {
  long nows = mono_sec();
  /* 系统在切前台/亮屏时会把 input_boost_ms 恢复成 100，手指一滑就重新抬频。
     boost 每个 1s 快拍都查（已经是 0 就不写），uclamp 每分钟补一次。 */
  suppress_boost_apply();
  if (!g_sup_reapply_at || nows - g_sup_reapply_at >= 60) {
    suppress_uclamp_apply();
    g_sup_reapply_at = nows;
  }
  /* 逐簇贴顶会把"刚好停在 cap"误判成饥饿：静置档的 cap 本身就是
     当前频点，按 cur>=want 判会让三档每几秒来回跳一次。改看持续负载：
     只有 busy 连续高于释放线才放档，静置档要求更久，滤掉渲染帧毛刺；
     20~25 之间保持不动，形成迟滞。 */
  int busy = cpu_busy_pct_ex(1);
  if (busy < 0) busy = SUP_FALL;           /* 无样本：按"不升不压"处理 */
  g_sup_last_busy = busy;
  int hungry = 0;
  int i;
  if (g_sup_level_at == 0) g_sup_level_at = nows;
  int stable = nows - g_sup_level_at >= SUP_LEVEL_HOLD_S;
  int static_floor = cfg.sup_style && g_sup_level == SUP_FLOOR_LV;
  if (g_sup_level >= SUP_MID_LV) {
    int release_busy = static_floor ? SUP_RELEASE_FLOOR : SUP_RELEASE_MID;
    if (stable && busy >= release_busy) {
      if (g_sup_floor_busy_n < 5) g_sup_floor_busy_n++;
    } else {
      g_sup_floor_busy_n = 0;
    }
    hungry = g_sup_floor_busy_n >=
             (static_floor ? SUP_STATIC_TICKS : 2);
  } else {
    g_sup_floor_busy_n = 0;
  }
  if (hungry) {
    /* 连续高载才放一档：单次滑动/切屏的瞬时顶帽不把天花板拉回满频。 */
    if (g_sup_up_n < 2) {
      g_sup_up_n++;
    } else {
      if (g_sup_level == SUP_FLOOR_LV) {
        g_sup_level = SUP_MID_LV;
        g_sup_level_at = nows;
        g_sup_floor_busy_n = 0;
        log("动态封顶：持续高载，先放到 %d%%", sup_pct());
      } else if (g_sup_level == SUP_MID_LV) {
        g_sup_level = SUP_OPT;
        g_sup_level_at = nows;
        g_sup_floor_busy_n = 0;
        log("动态封顶：持续高载，放开到最优解");
      }
      g_sup_up_n = 0;
    }
    g_sup_fall_n = 0;
    g_sup_min_n = 0;
    if (g_sup_min_on) {
      sup_min_clamp(0);
      log("动态封顶：活动恢复，下限还原");
    }
  } else if (busy < SUP_FALL) {
    g_sup_up_n = 0;
    /* 无饥饿且占用低：先连续 N 拍降到中间档，再连续 N 拍降到地板。 */
    if (g_sup_fall_n < sup_fall_ticks()) g_sup_fall_n++;
    else if (g_sup_level == SUP_OPT) {
      g_sup_level = SUP_MID_LV;
      g_sup_level_at = nows;
      g_sup_fall_n = 0;
      log("动态封顶：持续低载，先收到 %d%%", sup_pct());
    } else if (g_sup_level == SUP_MID_LV) {
      g_sup_level = SUP_FLOOR_LV;
      g_sup_level_at = nows;
      g_sup_floor_busy_n = 0;
      g_sup_fall_n = 0;
      if (cfg.sup_style)
        log("动态封顶：持续低载，收到静置档 960MHz");
      else
        log("动态封顶：持续低载，收到地板 %d%%", sup_pct());
    }
    /* 到地板且低载：压下限（抖音这类静置场景的空闲大头）。
       忙碌与否不作为条件——下限只影响"能闲到多低"，调度器自己决定；
       收口交给持续高载路径（连续高载就放开并还原下限）。 */
    if (g_sup_level == SUP_FLOOR_LV) {
      if (g_sup_min_n < SUP_MIN_TICKS) g_sup_min_n++;
      else if (!g_sup_min_on) {
        sup_min_clamp(1);
        log("动态封顶：静置空闲，下限压到硬件最低");
      }
    }
  } else {
    /* 负载在释放线以下：保持当前档不升不降，
       下限维持原状——收口交给持续高载路径。 */
    g_sup_fall_n = 0;
    g_sup_up_n = 0;
  }
  /* 天花板写入：只写与当前值不同的拍（level 0 时等价于 1s 巡检压回）。
     内核把上限夹在更高处（目标低于该簇实际下限）时记住回读值并退避，
     不做每秒一次的无效写入。 */
  for (i = 0; i < g_npol; i++) {
    char path[256];
    long want = sup_cap_for(&g_pol[i]);
    snprintf(path, sizeof path, "%s/scaling_max_freq", g_pol[i].dir);
    long cur = read_num(path);
    /* 回读值不等于当初写不进去的那个值，或已经达到目标：退避前提已消失。
       不能因为一次瞬时 min>max 就把这一档锁 10 分钟。 */
    if (g_sup_stuck[i] && cur > 0 &&
        (cur != g_sup_stuck[i] || cur == want))
      g_sup_stuck[i] = 0;
    if (g_sup_stuck[i] && want <= g_sup_stuck[i] &&
        nows - g_sup_stuck_at[i] < 600)
      continue;                              /* 已知写不进去：退避 */
    if (cur > 0 && cur != want) {
      if (!write_journaled(NODES_JOURNAL, path, want)) {
        long got = read_num(path);
        if (got == cur && got != want) {     /* 写了没动：被内核夹住 */
          g_sup_stuck[i] = got;
          g_sup_stuck_at[i] = nows;
        } else {
          g_sup_stuck[i] = 0;                /* 写进去了（或值变了） */
        }
        g_pol[i].last_cap = want;
        g_pol[i].last_got = got > 0 ? got : want;
        be_apply_max(&g_pol[i], want);
      }
    }
  }
  /* 档位换了就换 uclamp.max / cpuset / hispeed；同一档内幂等补写，
     抵消厂商切前台、亮屏时对这些节点的改写。 */
  suppress_extra_apply();
}

/* ------------------------------------------------------------------ */
/* 模式切换                                                           */
/* ------------------------------------------------------------------ */

/* 配置指纹：变了才需要重新探测分档，重启时无需 */
static uint64_t cfg_stamp(void) {
  return file_stamp(CFG_FILE);
}

/*
 * force：配置变更或启动时为 1，无条件重写一遍。
 * 巡检逻辑是"厂商顶高了才压"，cur <= cap 就跳过；升档时新 cap 比当前值大，
 * 会落进跳过分支、节点停在旧低值，只有降档方向（cur > cap）正常写入。
 * GPU 的写入同样只在 changed 分支里。所以升档/改档时必须置 force。
 */
/* 建目录（含父级）。数据目录 /data/adb/soc_freqcap 不在解包范围内，
 * **首次运行时可能还不存在**（模块目录是解包出来的，数据目录不是），
 * 需要连父级一起建。 */
static void mkdir_p(const char *path) {
  char tmp[256];
  size_t n = strlen(path);
  if (n >= sizeof tmp) return;
  memcpy(tmp, path, n + 1);
  for (size_t i = 1; i <= n; i++) {
    if (tmp[i] == '/' || tmp[i] == 0) {
      char save = tmp[i];
      tmp[i] = 0;
      mkdir(tmp, 0700);          /* 已存在时失败无所谓，继续往下建 */
      tmp[i] = save;
    }
  }
}

/* 开机至今的秒数。用 /proc/uptime 而不是墙钟：
 * 开机阶段时间还要等 NTP 校准，date +%s 可能跳；
 * 而"开机后 60 秒"本来就是相对量，用单调的 uptime 才是原意。 */
static long uptime_sec(void) {
  char b[64];
  if (read_file("/proc/uptime", b, sizeof b)) return -1;
  double u = strtod(b, NULL);
  return u <= 0 ? -1 : (long)u;
}

/* 屏幕是否亮着。只在 SCREEN_UNCAP=1 时才被调用 ——
 * 默认关就一次 dumpsys 都不跑，不给巡检添开销。
 * 读不到（没有 dumpsys、超时、格式变了）一律当"亮着"：
 * 宁可照常限频，也不要在判断失败时把上限悄悄放开。 */
static int screen_awake(void) {
  FILE *f = popen("timeout 2 dumpsys power 2>/dev/null | grep -m1 mWakefulness", "r");
  if (!f) return 1;
  char line[256];
  int awake = 1, got = 0;
  while (fgets(line, sizeof line, f)) {
    if (strstr(line, "Awake")) { awake = 1; got = 1; break; }
    if (strstr(line, "Asleep") || strstr(line, "Dozing")) { awake = 0; got = 1; break; }
  }
  int rc = pclose(f);
  if (!got || rc != 0) return 1;
  return awake;
}

/* 亮屏信号取值：blank 语义 0=亮、1=灭；backlight 语义 >0=亮、0=灭。
 * 返回 1=亮、0=灭、-1=读不到。 */
int screen_value_on(long v, int invert) {
  if (v < 0) return -1;
  return invert ? (v == 0) : (v > 0);
}

/* current_now 归一化成 mA。PJZ110 实测是 mA 且充电为负（与 AOSP 常见约定相反），
 * 所以这里先取绝对值；µA 的 ROM 再除以 1000。读不到由调用方传 valid=0。 */
long batt_current_ma(long raw, int unit_ma) {
  long a = raw < 0 ? -raw : raw;
  return unit_ma ? a : a / 1000;
}

/* 深度空闲纯步进。返回 0=不变、1=进入深睡、2=电流突增（让调用方做一次亮屏确认）。
 * ema 用 8 拍滑动；读不到时只清 hold，不用坏值改基线。
 * 进入条件：连续 hold_cycle 拍都低于 idle_ma。
 * 唤醒提示：比 EMA 基线高出 wake_delta（绝对阈值在低亮度深色屏上不可靠）。 */
int idle_step(long *ema, int *hold, long ma, int valid,
              int idle_ma, int hold_cycle, int wake_delta) {
  if (!valid) { *hold = 0; return 0; }
  if (*ema <= 0) { *ema = ma; *hold = 0; return 0; }
  int wake = (ma > *ema + wake_delta);
  *ema = (*ema * 7 + ma) / 8;
  if (wake) { *hold = 0; return 2; }
  if (ma < idle_ma) {
    if (++*hold >= hold_cycle) return 1;
  } else {
    *hold = 0;
  }
  return 0;
}

/* 挑一个亮屏信号：用户指定 > fb0/blank > 任意 backlight/brightness。
 * PJZ110/Android 17 上 fb0/blank 不存在，实测 backlight 0/1127 与
 * dumpsys power 的 Dozing/Awake 完全一致。 */
static void screen_state_init(void) {
  char want[192];
  snprintf(want, sizeof want, "%s", cfg.screen_state_path);
  /* 已经因为假归零降级过，且用户没改 SCREEN_STATE_PATH：保持 dumpsys 兜底。
     否则每次保存配置都会重新拾起三星那个一直读 0 的 panel 节点。 */
  if (g_scr_fallback && !strcmp(want, g_scr_cfg_seen)) {
    g_scr_path[0] = 0;
    g_scr_invert = 0;
    g_scr_check = 0;
    log("亮屏信号继续使用 dumpsys 兜底（配置未变）");
    return;
  }
  snprintf(g_scr_cfg_seen, sizeof g_scr_cfg_seen, "%s", want);
  g_scr_fallback = 0;
  g_scr_path[0] = 0;
  g_scr_invert = 0;
  g_scr_bad = 0;
  g_scr_check = 0;
  if (cfg.screen_state_path[0]) {
    if (!access(cfg.screen_state_path, F_OK)) {
      snprintf(g_scr_path, sizeof g_scr_path, "%s", cfg.screen_state_path);
      g_scr_invert = strstr(g_scr_path, "blank") ? 1 : 0;
    } else {
      log("WARN 亮屏信号 %s 不存在，改为自动挑选", cfg.screen_state_path);
    }
  }
  /* 优先已知可用的节点：三星 One UI 的 panel0-backlight 才是真值，
     某些 ROM 的 panel/brightness 亮屏仍读 0。 */
  if (!g_scr_path[0]) {
    static const char *const pref[] = {
        "/sys/class/backlight/panel0-backlight/brightness",
        "/sys/class/backlight/panel0-backlight/actual_brightness",
        "/sys/class/leds/lcd-backlight/brightness",
        "/sys/class/backlight/panel/brightness",
        "/sys/class/backlight/panel/actual_brightness",
        NULL
    };
    for (int i = 0; pref[i]; i++) {
      if (access(pref[i], F_OK)) continue;
      snprintf(g_scr_path, sizeof g_scr_path, "%s", pref[i]);
      g_scr_invert = 0;
      break;
    }
  }
  if (!g_scr_path[0] && !access("/sys/class/graphics/fb0/blank", F_OK)) {
    snprintf(g_scr_path, sizeof g_scr_path, "%s", "/sys/class/graphics/fb0/blank");
    g_scr_invert = 1;
  }
  if (!g_scr_path[0]) {
    DIR *d = opendir("/sys/class/backlight");
    if (d) {
      struct dirent *e;
      while ((e = readdir(d))) {
        if (e->d_name[0] == '.') continue;
        char t[224];
        snprintf(t, sizeof t, "/sys/class/backlight/%s/brightness", e->d_name);
        if (!access(t, F_OK)) {
          snprintf(g_scr_path, sizeof g_scr_path, "%s", t);
          g_scr_invert = 0;
          break;
        }
      }
      closedir(d);
    }
  }
  if (g_scr_path[0])
    log("亮屏信号: %s（%s）", g_scr_path,
        g_scr_invert ? "blank 0=亮" : "亮度>0=亮");
  else {
    g_scr_fallback = 1;
    log("WARN 没有可用的亮屏信号，改用 dumpsys power 兜底");
  }
}

static int screen_sig_read(void) {
  if (!g_scr_path[0]) return -1;
  return screen_value_on(read_num(g_scr_path), g_scr_invert);
}

/* ACTIVE 态判断是否已经熄屏。信号说灭时用 dumpsys 复核一次，
 * 防止某些 ROM 的亮度节点假归零；连续 3 次对不上就永久停用该文件。 */
static int screen_is_off_now(int force_check) {
  int sig = screen_sig_read();
  if (sig == 0) {
    if (screen_awake()) {
      g_scr_bad++;
      log("WARN 亮屏信号说灭但系统仍 Awake（%d/3）", g_scr_bad);
      if (g_scr_bad >= 3 && g_scr_path[0]) {
        g_scr_path[0] = 0;
        g_scr_fallback = 1;
        log("停用亮屏信号，改用 dumpsys power 兜底（重载配置也不再启用）");
      }
      return 0;
    }
    g_scr_bad = 0;
    return 1;
  }
  if (sig < 0 && !force_check) return 0;   /* 暂时当亮屏，保守 */
  if (!force_check) return 0;
  return screen_awake() ? 0 : 1;           /* 每 6 轮兜底校验一次 */
}

/* SCREEN_OFF 态是否已经亮屏。主判据是 sysfs；读不到时每 6 轮问一次 dumpsys。 */
static int screen_wake_seen(void) {
  int sig = screen_sig_read();
  if (sig == 1) return 1;
  if (sig < 0 || ++g_scr_check >= 6) {
    g_scr_check = 0;
    return screen_awake();
  }
  return 0;
}

/* 开机满血窗口是否还在有效。service.sh 写的是"第几秒结束"（uptime 口径），
 * 到点由守护自己删文件并压回 —— 让 service.sh 去写 sysfs 不成立：
 * 它跑得很早，cpufreq 节点和厂商调度未必就绪，写失败还是静默的。 */
static int boot_boost_active(void) {
  long until = read_num(BOOT_BOOST_FILE);
  if (until <= 0) return 0;
  long up = uptime_sec();
  if (up < 0) return 0;                 /* 读不到 uptime 就当窗口不在，保守压回 */
  if (up >= until) { unlink(BOOT_BOOST_FILE); return 0; }
  return 1;
}

/* 只做 CPU 上限巡检，不碰 state/权限。apply_normal 和熄屏 keep 轻巡检共用。 */
static long g_capfloor_log_at = -600;  /* 初值 -600：开机头 10 分钟也能打第一条 */
/* 厂商 perf/热控每隔几秒把 max 顶回去时，巡检每拍都会写一次；
 * RESTORE 日志按簇 60 秒限流，写入照做，只避免日志被刷成几百行。 */
static long g_restore_log_at[MAX_POLICY];

static void caps_patrol(int force) {
  for (int i = 0; i < g_npol; i++) {
    char path[224];
    long cur;
    snprintf(path, sizeof path, "%s/scaling_max_freq", g_pol[i].dir);
    cur = read_num(path);
    if (cur < 0) {
      /* 核心全离线时 policy 节点会读不到：静默跳过，回来那拍自动重压。
         只在状态翻转时记一行，避免热插拔期间每拍刷日志。 */
      if (!g_pol[i].offline) {
        g_pol[i].offline = 1;
        log("  %-8s 节点暂不可读（核心离线/热插拔），暂停写入", g_pol[i].name);
      }
      continue;
    }
    if (g_pol[i].offline) {
      g_pol[i].offline = 0;
      log("  %-8s 已恢复，重新压回封顶", g_pol[i].name);
    }
    long want = g_pol[i].cap;
    /* 常态巡检：厂商把上限顶高了就压回去 */
    if (!force && cur <= want) continue;
    /* force 升帽时先确认当前值就是模块上一轮写的那个。
       若 cur 比 cap 低、又不是我们写的，说明厂商热管理压得更低，别盖。
       降帽（cur > cap）不受这条限制，热的时候必须压。 */
    if (force && cur <= want) {
      /* 厂商在模块写完后把上限压得更低：保留厂商值，不在 force 里抢回去。
         用户主动改低后 cur 会等于 last_got，不会命中这条。 */
      if (g_pol[i].last_got > 0 && cur < g_pol[i].last_got) continue;
      if (!(g_pol[i].last_got > 0 && cur == g_pol[i].last_got &&
            want > g_pol[i].last_cap))
        continue;
    }
    long now = mono_sec();
    /* 同一目标、同一回读值刚刚已经证明写不动：10 分钟内不再重试。
       内核的实际下限可能高于 scaling_min_freq 读到的数，单靠下面的
       floor 判断拦不住（本机写 1,017,600 会被夹在 1,958,400）。 */
    if (want == g_pol[i].unreach_cap && cur == g_pol[i].unreach_got &&
        now - g_pol[i].unreach_at < 600)
      continue;
    /* 内核可能把允许下限锁在 cpuinfo_min 之上（本机 1,017,600）。
       目标比这个下限还低时，写下去会被夹回当前值；不识别的话每拍都写一次、
       每拍记一行（BIG_MIN=1 时目标 1% = 43,200 会触发）。按低限生效即可，
       下一拍 cur <= want 自然就不写了。 */
    char mpath[224];
    snprintf(mpath, sizeof mpath, "%s/scaling_min_freq", g_pol[i].dir);
    long floor = read_num(mpath);
    if (floor > 0 && want < floor) {
      if (now - g_capfloor_log_at >= 600) {
        g_capfloor_log_at = now;
        log("%s 封顶目标 %ld 低于内核下限 %ld，按 %ld 生效", g_pol[i].name,
            want, floor, floor);
      }
      want = floor;
    }
    if (cur == want) {          /* 写下去也不会变，别做无效写入 */
      g_pol[i].last_cap = want;
      g_pol[i].last_got = cur;
      g_pol[i].unreach_cap = 0;
      g_pol[i].unreach_got = 0;
      g_pol[i].unreach_at = 0;
      continue;
    }
    if (!write_journaled(NODES_JOURNAL, path, want)) {
      long got = read_num(path);
      g_pol[i].last_cap = want;
      g_pol[i].last_got = got;
      be_apply_max(&g_pol[i], want);
      if (got > 0 && got == cur && got != want) {
        /* 写下去没动：内核真实下限比读到的 min 更高，记住这对值 */
        if (force) {
          char gov[32] = {0}, gp[256];
          snprintf(gp, sizeof gp, "%s/scaling_governor", g_pol[i].dir);
          if (!read_file(gp, gov, sizeof gov)) trim(gov);
          log("  %-8s 上限 -> %ld%s%s", g_pol[i].name, got,
              got < want ? "（厂商已压更低）" : "（写入未生效）",
              (got >= want && is_vendor_gov(gov)) ? "，厂商调速器接管" : "");
        }
        else if (now - g_capfloor_log_at >= 600) {
          g_capfloor_log_at = now;
          log("%s 上限被内核夹在 %ld，按 %ld 生效", g_pol[i].name, got, got);
        }
        g_pol[i].unreach_cap = want;
        g_pol[i].unreach_got = got;
        g_pol[i].unreach_at = now;
      } else {
        g_pol[i].unreach_cap = 0;
        g_pol[i].unreach_got = 0;
        g_pol[i].unreach_at = 0;
        if (force)
          log("  %-8s 上限 -> %ld%s", g_pol[i].name, got,
              got < want ? "（厂商已压更低）" : "");
        else if (now - g_restore_log_at[i] >= 60) {
          g_restore_log_at[i] = now;
          log("RESTORE %s: %ld -> %ld（厂商顶回后已压回，60s 内同类不再刷）",
              g_pol[i].name, cur, got);
        }
      }
    }
    apply_governor(&g_pol[i]);
  }
}

static void apply_normal(int force) {
  int changed = force || strcmp(g_state, "normal") != 0;
  if (changed) {
    log("→ 常态封顶");
    perms_restore(); /* 先收回游戏期交出去的写权限 */
    /* 交权时调速器被还原成出厂值；回常态要把用户选的那个再写回去。
       不能指望 caps_patrol 顺带做：封顶正好没变时那条路径会 continue。 */
    for (int i = 0; i < g_npol; i++) apply_governor(&g_pol[i]);
    /* 开关关掉时也要走一次还原：用户可能刚在页面上把它关掉。 */
    if (cfg.gpu_boost_off) boost_off_apply();
    else boost_off_restore();
    /* 后台分组常驻收口：与动态封顶无关，交权态已在 hand_back_full 还原。 */
    if (cfg.bg_light) bg_light_apply();
    else bg_light_restore();
    /* 动态封顶开启时：walt 拉频源中和 + 升频限速 + 调速器工作点参数
       随压制一起生效；关闭/交权时按账本还原。 */
    if (cfg.suppress) {
      if (!g_sup_chg_pause) {
        suppress_boost_apply();
        suppress_smooth_apply();
        suppress_uclamp_apply();
        suppress_extra_apply();
      } else {
        suppress_boost_restore();
        suppress_smooth_restore();
        suppress_gov_restore();
        suppress_uclamp_restore();
        suppress_extra_restore();
      }
    } else if (cfg.strategy == 1) {
      /* 智能模式不跑动态压制，但仍应用升/降频限速：
         否则 GOV_* 只在开压制时才生效，智能模式滑动时完全不受控。 */
      suppress_boost_restore();
      suppress_smooth_apply();
      suppress_gov_restore();
      suppress_uclamp_restore();
      suppress_extra_restore();
    } else {
      suppress_boost_restore();
      suppress_smooth_restore();
      suppress_gov_restore();
      suppress_uclamp_restore();
      suppress_extra_restore();
    }
    gpu_min_to_floor();
    apply_gpu_cap(1);
  }
  caps_patrol(changed);
  if (changed) cpu_min_refresh();
  if (!g_screen_off) cpu_min_patrol();
  if (changed) {
    snprintf(g_state, sizeof g_state, "normal");
    snprintf(g_reason, sizeof g_reason, "-");
  }
}

/* 交权态（游戏 / 满血 / 熄屏）下不能抢回节点：游戏分支只在包名变化时
 * 重新 unlock_game，抢回来之后同一个游戏就再也交不出去，只能切出再切回。
 * 配置和偏移照常重算进内存，等真正回到常态时由 apply_normal 一次带上。 */
static int reclaim_caps_allowed(void) {
  return strcmp(g_state, "game") != 0 && strcmp(g_state, "full") != 0;
}

/*
 * 配置变了就吸收新值。返回 1 表示"这一轮要重算封顶并立刻生效"。
 * 这里**故意不**算封顶：生效值还要叠加实时偏移（插电地板 / 温控 / PSI），
 * 而偏移是主循环里 adapt_tick 之后才新鲜的。以前在这里直接 assign_pct +
 * apply_normal，用的还是上一拍的快照，真机上表现为"改一次配置先按旧地板
 * 写一遍节点、下一拍才纠正"。
 */
static int reload_if_changed(uint64_t seen) {
  uint64_t now = cfg_stamp();
  if (now == seen) return 0;
  char prev_gov[32];
  snprintf(prev_gov, sizeof prev_gov, "%s", cfg.governor);
  log("检测到配置变更，重新计算封顶值");
  int prev_strategy = cfg.strategy;
  load_cfg();
  if (cfg.strategy != prev_strategy)
    smart_on_strategy_edge(prev_strategy, cfg.strategy);
  screen_state_init(); /* SCREEN_STATE_PATH / 策略变了要重新挑信号 */
  detect_gpu(0);        /* GPU 百分比变了要重新挑吸附频点 */
  /* 从某个调速器改成"不干预"：不能只是停止写入，要把模块改过的名字写回
   * 启动时的快照；否则节点会一直停在模块最后写入的那个调速器上。 */
  if (prev_gov[0] && !cfg.governor[0]) {
    if (!access(GOV_JOURNAL, F_OK)) restore_governors();
    else log("WARN 调速器快照缺失，无法恢复原值");
  }
  return 1;
}

/* 交还系统的公共动作：值放到硬件最高 + 写权限交给厂商框架。
 * 游戏解锁、熄屏解除、开机满血窗口三处都走这里，共用一份实现，
 * 避免任一处漏掉权限交换导致厂商调度接管不了。 */
/* 交还写权限：优先还原 NODES journal 里记的出厂权限，没有才用 0666。
 * 不能直接 read_mode()：那时节点已被运行期 chmod 成 0644，
 * 记下来的"原始权限"就是 0644，出厂 0664（root:system 可写）的机型
 * 从此让厂商框架写不动节点。 */
static void hand_back_mode(const char *path) {
  if (access(path, F_OK)) return;
  int orig = journal_mode(NODES_JOURNAL, path);
  if (!journal_has(PERM_JOURNAL, path))
    journal_add(PERM_JOURNAL, path, 0, orig >= 0 ? orig : read_mode(path));
  chmod(path, orig >= 0 ? (mode_t)orig : 0666);
}

static void hand_back_full(const char *why) {
  log("→ %s", why);
  /* 先放掉 PPM/msm 第二道锁，否则 sysfs 写回硬件最高也会被厂商硬限压着。 */
  be_handback();
  for (int i = 0; i < g_npol; i++) {
    char path[256];
    snprintf(path, sizeof path, "%s/scaling_max_freq", g_pol[i].dir);
    long cur = read_num(path);
    if (cur < 0) continue;   /* 簇离线：别往不存在的节点写 */
    /* 只撤模块自己写的帽：current 等于模块最近一次目标或设定帽，才写回硬件最高。
       厂商游戏助手/热控已经把上限压低时保留它，否则进游戏的一瞬间会把它盖回满频。 */
    long own = g_pol[i].last_cap > 0 ? g_pol[i].last_cap : g_pol[i].cap;
    if (cur > 0 && cur != own && cur != g_pol[i].cap) {
      log("  %-8s 保留厂商上限 %ld（模块帽 %ld）", g_pol[i].name, cur, own);
      continue;
    }
    if (!write_journaled(NODES_JOURNAL, path, snap_freq(&g_pol[i], cap_base(&g_pol[i]))))
      log("  %-8s -> 厂商上限 %ld", g_pol[i].name, cap_base(&g_pol[i]));
  }
  if (g_gpu.ok) {
    if (g_gpu.ged) {
      /* GED 节点读回的是 OPP 序号，不能和 Hz 的 active 直接比；
         解锁按账本写回原序号。 */
      write_gpu(g_gpu.max_hz, 1);
    } else {
      long gcur = read_num(g_gpu.max_node);
      if (g_gpu.max_is_mhz && gcur > 0) gcur *= 1000000;
      /* 同理：厂商已经把 GPU 上限压得更低时，交权不要再把它抬回硬件最高。 */
      if (gcur > 0 && g_gpu.active > 0 && gcur != g_gpu.active) {
        log("  GPU 保留厂商上限 %ldHz", gcur);
      } else {
        write_gpu(g_gpu.max_hz, 1);
      }
    }
    if (g_gpu.pwr_node[0]) write_journaled(NODES_JOURNAL, g_gpu.pwr_node, 0);
  }

  /*
   * 权限交换：值解锁之后再把写权限交给系统，厂商框架才能真正接管。
   * 只放开实际探测到的节点，不遍历全部候选路径。
   */
  for (int i = 0; i < g_npol; i++) {
    char path[256];
    snprintf(path, sizeof path, "%s/scaling_max_freq", g_pol[i].dir);
    hand_back_mode(path);
    snprintf(path, sizeof path, "%s/scaling_min_freq", g_pol[i].dir);
    hand_back_mode(path);
  }
  const char *nodes[] = {g_gpu.max_node, g_gpu.min_node, g_gpu.pwr_node};
  for (size_t i = 0; i < 3; i++) {
    if (!nodes[i][0]) continue;
    hand_back_mode(nodes[i]);
  }
  /* 调速器也属于"官方调度"：模块改过就还原成接管前的名字，没改过则不动。
     账本保留——回常态要按用户的选择再写一次，卸载时还要靠它还原。 */
  restore_governors_core(1);
  /* GPU Boost 开关是常态省电项，交权态一律放回去。 */
  boost_off_restore();
  /* 后台分组常驻收口也属于常态省电项，交权态还干净原值。 */
  bg_light_restore();
  /* 动态封顶带的 walt 拉频源中和与升频限速：交权给厂商干净的原值。 */
  suppress_boost_restore();
  suppress_smooth_restore();
  /* 工作点参数：交权后系统可能切换调速器，这里一并还原。 */
  suppress_gov_restore();
  suppress_uclamp_restore();
  /* uclamp.max / cpuset / 分级 hispeed 也属于动态封顶，交权时一起还。 */
  suppress_extra_restore();
  /* 动态封顶的下限与标志一并清理（天花板由上面的满频写入处理）。 */
  sup_cancel();
  /* CPU 下限是常态省电项：交权（游戏/满血/熄屏解除）时还给系统原值。 */
  cpu_min_restore();
  log("  CPU/GPU 节点写权限已交由系统接管");
  /* state 由调用方决定：游戏/满血应用是 game，熄屏交还是 full。
     hand_back_full 自己写死 game 会让熄屏状态显示成"游戏中"。 */
}

/* 游戏解锁路径的日志文案保持稳定：外部脚本按这一行判断解锁是否生效。 */
static void unlock_game(void) {
  char why[PKG_LEN + 24];
  snprintf(g_reason, sizeof g_reason, "game");
  snprintf(why, sizeof why, "游戏解锁并交还系统: %s", g_game);
  hand_back_full(why);
  snprintf(g_state, sizeof g_state, "game");
}

/* 熄屏专属：把每簇的 scaling_min_freq 压到下限目标（用户最低或硬件最低）。
 * 亮屏时不动：perfd 会为了响应把 min 抬到 556800，每 5 秒压回去等于新增一个
 * 对顶面，还会拖慢唤醒。只在 cap 策略的熄屏轻巡检里做，亮屏立刻还原。 */
static void cpu_min_to_floor(void) {
  int n = 0;
  for (int i = 0; i < g_npol; i++) {
    if (g_pol[i].hw_min <= 0) continue;
    long target = min_floor_for(&g_pol[i]);
    if (target <= 0) continue;
    char path[256];
    snprintf(path, sizeof path, "%s/scaling_min_freq", g_pol[i].dir);
    long cur = read_num(path);
    if (cur <= 0 || cur == target) continue;
    if (write_journaled(NODES_JOURNAL, path, target)) continue;
    /* 写下去回读不符：可能是内核把下限锁在更高处，也可能是用户最低
       高于硬件最低、写下去被夹回。如实说，不冒充“已压到目标”。 */
    long got = read_num(path);
    if (got > 0 && got != target) {
      log("熄屏：%s 下限目标 %ld，实际 %ld", g_pol[i].name, target, got);
    } else {
      n++;
    }
  }
  if (n) log("熄屏：CPU 下限已压到目标（%d 个簇）", n);
}

/* 亮屏常态的 CPU 下限巡检（CPU_MIN_LOCK）。
 * 不像熄屏那样无条件写：perfd 会把 min 抬回去，每拍对写会拖慢唤醒。
 * 这里先读、偏离才写，全局 30 秒最多写一次；连续 3 次被内核夹回
 * 就停 10 分钟（本机内核把下限锁在 556800，写 384000 会被夹回）。 */
static long g_min_writes, g_min_last, g_min_fail_at;
static int  g_min_fails;
/* 每簇的下限战况：累计被夹回 9 次（约 3 轮退避）判定"系统把下限钉死"，
 * 本启动放弃该簇、每 30 分钟复探一次（系统放开自动恢复）——
 * 不再无限退避循环，UI 也如实显示"被系统钉住"而不是永远"退避中"。 */
static int  g_min_pfails[MAX_POLICY];
static int  g_min_giveup[MAX_POLICY];
static long g_min_pinned[MAX_POLICY];
static long g_min_target[MAX_POLICY];
static long g_min_give_at;

/* 配置刚改过：清掉 30 秒节流，下一拍立刻按新下限写一次。 */
static void cpu_min_refresh(void) {
  g_min_last = 0;
}

/* 只还原本模块按“进阶最低频/下限锁”压过的簇，不动 suppression 或厂商
 * 自己抬高的其它簇。配置变更时用这个，避免改一簇最低频把别簇的 vendor
 * 下限也一起恢复。 */
static void cpu_min_restore_user(void) {
  for (int i = 0; i < g_npol; i++) {
    if (g_min_target[i] <= 0) continue;
    char path[256];
    snprintf(path, sizeof path, "%s/scaling_min_freq", g_pol[i].dir);
    boost_restore_path(path);
    g_min_target[i] = 0;
  }
}

static void cpu_min_patrol(void) {
  int user_any = 0;
  for (int i = 0; i < g_npol; i++)
    if (cfg.min_pct[g_pol[i].tier & 3] > 0) { user_any = 1; break; }
  /* 动态封顶开启时，硬件最低由压制的低载静置接管；但用户明确设了
     进阶最低频时仍要守住，不能因为压制而掉回系统默认。 */
  if (cfg.suppress && !user_any) return;
  if (!cfg.cpu_min_lock && !user_any) return;
  /* 省电静态档的下限已由压制改为硬件最低；巡检这时再写用户下限，
     会跟 960MHz 天花板打架（min > max 必被拒）。离开地板后自然恢复。 */
  if (cfg.suppress && cfg.sup_style && g_sup_level == SUP_FLOOR_LV) return;
  long now = mono_sec();
  if (g_min_fails >= 3) {
    if (now - g_min_fail_at < 600) return;
    /* 退避到期必须清零，否则 g_min_fails 永远 >=3，之后每拍都写、
       每拍被夹回，再也不进退避。 */
    g_min_fails = 0;
    g_min_fail_at = 0;
  }
  if (g_min_last && now - g_min_last < 30) return;
  for (int i = 0; i < g_npol; i++) {
    if (g_pol[i].hw_min <= 0) continue;
    long user_target = user_min_for(&g_pol[i]);
    if (user_target <= 0 && !cfg.cpu_min_lock) continue;
    long target = user_target > 0 ? user_target : g_pol[i].hw_min;
    if (target != g_min_target[i]) {
      g_min_target[i] = target;
      g_min_giveup[i] = 0;
      g_min_pfails[i] = 0;
    }
    char path[256];
    snprintf(path, sizeof path, "%s/scaling_min_freq", g_pol[i].dir);
    long cur = read_num(path);
    if (cur <= 0 || cur == target) continue;
    if (g_min_giveup[i]) {
      /* 钉死簇：30 分钟复探一次，其余时间跳过。 */
      if (now - g_min_give_at < 1800) continue;
      g_min_give_at = now;
    }
    if (write_journaled(NODES_JOURNAL, path, target)) continue;
    g_min_writes++;
    g_min_last = now;
    long got = read_num(path);
    /* 用户最低频只要“不低于目标”就算成功；CPU_MIN_LOCK 的下限是最低频，
       got 比它高说明被内核钉住了，仍按失败退避。 */
    int ok = got == target || (user_target > 0 && got > target);
    if (!ok) {
      if (++g_min_pfails[i] >= 9 && !g_min_giveup[i]) {
        g_min_giveup[i] = 1;
        g_min_pinned[i] = got;
        g_min_give_at = now;
        log("CPU 下限：%s 被系统钉在 %ld，本启动不再尝试（30 分钟复探一次）",
            g_pol[i].name, got);
      }
      int before = g_min_fails;
      if (++g_min_fails >= 3) {
        g_min_fail_at = now;
        /* 一轮里多个簇先后被夹回时只在刚跨过阈值那一下打一行 */
        if (before < 3)
          log("CPU 下限目标 %ld（%s）连续 3 次没达成，暂停 10 分钟",
              target, g_pol[i].name);
      }
    } else {
      g_min_fails = 0;
      g_min_pfails[i] = 0;
      if (g_min_giveup[i]) {
        g_min_giveup[i] = 0;
        log("CPU 下限：%s 系统已放开，恢复下限巡检", g_pol[i].name);
      }
    }
  }
}

static void cpu_min_restore(void) {
  for (int i = 0; i < g_npol; i++) {
    char path[256];
    snprintf(path, sizeof path, "%s/scaling_min_freq", g_pol[i].dir);
    long orig;
    if (!journal_value(NODES_JOURNAL, path, &orig)) continue;
    long target = orig;
    /* 账本里的"原值"可能已经是厂商瞬时 boost（本机 policy6 是 1,958,400）。
       直接还原会把下限顶到当前封顶，整簇再也降不下来；这种值按硬件最低还原，
       性能需要时由调速器 / perfd 自己再抬。 */
    if (g_pol[i].cap > 0 && g_pol[i].hw_min > 0 && orig >= g_pol[i].cap) {
      target = g_pol[i].hw_min;
      log("%s 下限原值 %ld 会顶住封顶 %ld，按硬件最低 %ld 还原",
          g_pol[i].name, orig, g_pol[i].cap, target);
    }
    if (read_num(path) == target) continue;
    write_num(path, target);
    int m = journal_mode(NODES_JOURNAL, path);
    if (m >= 0) chmod(path, (mode_t)m);
  }
}

/* 进入熄屏轻巡检：只有常态封顶才需要交还；游戏/满血应用已经是交权态，
 * 保留原 state/reason，亮屏后不会先压一拍再重新解锁。 */
/* 熄屏时放宽定时器松弛度，让 30/60s 的巡检唤醒与系统 Alarm/基带事件合并；
 * 亮屏立刻恢复 50µs，避免影响交互。 */
static void set_timer_slack(unsigned long ns) {
  (void)prctl(PR_SET_TIMERSLACK, ns, 0, 0, 0);
}

static void enter_screen_off(void) {
  if (g_screen_off) return;
  int mpct = 0, mbig = 0, mlit = 0;
  /* 熄屏白名单优先：pkg=soff 的应用在前台时，熄屏照样交还系统，
     其余应用才吃全局 cap。keep 仍然是"熄屏也封顶"。 */
  int have_mode = !strcmp(g_state, "normal") && g_fg[0] &&
                  mode_lookup(g_fg, &mpct, &mbig, &mlit, NULL);
  int soff_full = have_mode && mpct == MODE_SOFF;
  int global_cap = cfg.screen_policy == SCREEN_CAP && !strcmp(g_state, "normal") &&
                   !soff_full;
  int keep = global_cap || (have_mode && mpct == MODE_KEEP);
  g_screen_off = 1;
  set_timer_slack(3000000000UL);
  g_scr_check = 0;
  g_deep = 0;
  g_idle_ema = 0;
  g_idle_hold = 0;
  g_soff_th = 0;
  /* 动态封顶同步收口：保持封顶的路径把天花板交还生效封顶；
     交还路径随后 hand_back_full 自己写满频。 */
  if (keep) sup_exit();
  else sup_cancel();
  g_soff_keep = keep;
  snprintf(g_soff_pkg, sizeof g_soff_pkg, "%s",
           keep && !global_cap ? g_fg : "");
  /* smart + 保持封顶（global cap 或分应用 keep）：收到空闲并重立基线。
     分应用 keep 随后若走 set_caps，不会把显式帽改写成空闲比例。 */
  if (keep) smart_on_enter_screen_off(1);
  if (keep) {
    if (global_cap) {
      /* 交权态/PSI 额度不能带到熄屏；下限只在熄屏压，亮屏还原。 */
      adapt_cancel();
      cpu_min_to_floor();
    }
    /* 亮屏时 keep 不动分档；熄屏时把可能残留的应用档位收回全局，再做轻巡检。 */
    if (g_app_pct || g_app_big || g_app_little || g_app_gpu) {
      if (global_cap) assign_pct(g_pol, g_npol);
      else set_caps(0, "熄屏 keep");
      g_app_pct = 0;
      g_app_big = 0;
      g_app_little = 0;
      g_app_gpu = 0;
      apply_gpu_cap(1);
    }
    g_app[0] = 0;
    /* 充电地板在熄屏时不参与（eff_pct/gpu_target 已按 g_screen_off 跳过），
       所以这里重算一遍，把插电时的 100% 收回设定值。 */
    if (global_cap) assign_pct(g_pol, g_npol);
    caps_patrol(0);
    gpu_patrol();
    log("进入熄屏轻巡检（%d s，保持封顶%s）", cfg.soff_interval,
        global_cap ? "，不吃充电地板" : "");
    return;
  }
  if (!strcmp(g_state, "normal")) {
    g_app[0] = 0;
    g_app_pct = 0;
    g_app_big = 0;
    g_app_little = 0;
    g_app_gpu = 0;
    hand_back_full("熄屏解除限频，交还系统");
    snprintf(g_state, sizeof g_state, "full");
    snprintf(g_reason, sizeof g_reason, "screen");
  }
  log("进入熄屏轻巡检（%d s，不查前台/不采样）", cfg.soff_interval);
}

static void leave_screen_off(void) {
  if (!g_screen_off) return;
  g_screen_off = 0;
  set_timer_slack(50000UL);
  g_scr_check = 0;
  g_deep = 0;
  g_idle_ema = 0;
  g_idle_hold = 0;
  g_soff_keep = 0;
  g_soff_th = 0;
  sup_exit();
  g_soff_pkg[0] = 0;
  log("亮屏，恢复常态巡检");
  /* 重立占用基线；smart 且预热档打开且非游戏时，本圈 smart_tick 只升不降预热。 */
  smart_on_leave_screen_off();
  /* cap：下限还原、封顶重算（充电地板重新生效）。 */
  if (cfg.screen_policy == SCREEN_CAP && !strcmp(g_state, "normal")) {
    cpu_min_restore();
    apply_normal(1);
  }
  /* 熄屏交还的才需要压回；游戏态/keep 态保持原样，交给主循环重新判定。 */
  if (!strcmp(g_state, "full")) {
    g_app[0] = 0;
    g_app_pct = 0;
    g_app_big = 0;
    g_app_little = 0;
    g_app_gpu = 0;
    apply_normal(1);
  }
}

/* ------------------------------------------------------------------ */
/* 配置解析：坏值一律回落到默认值，绝不让脏配置生效                   */
/* ------------------------------------------------------------------ */

static int cfg_get(const char *key, char *out) {
  FILE *f = fopen(CFG_FILE, "r");
  if (!f) return -1;
  char line[512], k[128];
  int found = -1;
  while (fgets(line, sizeof line, f)) {
    const char *s = line;
    while (*s && isspace((unsigned char)*s)) s++;
    if (*s == '#' || !*s) continue;
    if (sscanf(s, "%127[^= \t]=%511[^\n]", k, out) == 2 && !strcmp(k, key)) {
      found = 0;
      break;
    }
  }
  fclose(f);
  return found;
}

/* cfg_get 的 %[^\n] 要求值至少一个字符，空值会被当成键不存在。
 * CPU_GOVERNOR= 的"不干预"就是空值，需要单独认键名。 */
static int cfg_key_present(const char *key) {
  FILE *f = fopen(CFG_FILE, "r");
  if (!f) return 0;
  char line[512], k[128];
  int found = 0;
  while (fgets(line, sizeof line, f)) {
    const char *s = line;
    while (*s && isspace((unsigned char)*s)) s++;
    if (*s == '#' || !*s) continue;
    if (sscanf(s, "%127[^= \t]", k) == 1 && !strcmp(k, key)) {
      found = 1;
      break;
    }
  }
  fclose(f);
  return found;
}

static int clampi(int v, int lo, int hi, int dflt) {
  return (v < lo || v > hi) ? dflt : v;
}

static void load_cfg(void) {
  static const char *keys[4] = {"CPU_PCT_BIG", "CPU_PCT_MID2", "CPU_PCT_MID",
                                "CPU_PCT_LITTLE"};
  static const int dflt[4] = {65, 64, 66, 65};
  char v[512];
  cfg.interval = 5;
  cfg.grace = 30;
  cfg.gpu_pct = 45;
  cfg.gpu_min_lock = 1;
  cfg.gpu_boost_off = 1;
  cfg.bg_light = 1;
  cfg.big_min = 0;
  cfg.cpu_min_lock = 0;
  cfg.cap_backend = CAP_BE_AUTO;
  /* 熄屏策略：基准 keep（旧行为）。全新安装的 conf 写 uncap；
     升级用户没有 SCREEN_POLICY 时按旧 SCREEN_UNCAP 保持现状；
     两个键都没有的手写/极老配置按新装默认 uncap（见下面的映射）。 */
  cfg.screen_uncap = 0;
  /* 熄屏轻巡检（保持封顶 + 30s 轻巡检）是正收益，固定默认开；页面不再
     提供开关。显式写了 SCREEN_POLICY=keep/uncap 的手工配置仍尊重，
     安装器升级时会把存量配置统一改成 cap。 */
  cfg.screen_policy = SCREEN_CAP;
  cfg.soff_interval = 15;
  cfg.screen_state_path[0] = 0;
  cfg.idle_current_ma = 250;
  cfg.idle_hold_cycle = 2;
  cfg.strategy = 0;
  cfg.suppress = 0;
  cfg.sup_style = 0;
  cfg.app_switch_tier = 2;
  /* 按簇给不同的升降频节奏。这组等于旧默认/均衡基准，gov_rate_for()
     会按 SUP_STYLE 换表：省电升得更慢、降得更快；用户改过的簇按用户值。 */
  cfg.gov_up_us[0] = 3000; cfg.gov_down_us[0] = 1000;
  cfg.gov_up_us[1] = 2000; cfg.gov_down_us[1] = 1500;
  cfg.gov_up_us[2] = 1000; cfg.gov_down_us[2] = 2000;
  cfg.idle_interval = 30;
  cfg.wake_delta_ma = 150;
  snprintf(cfg.batt_current_path, sizeof cfg.batt_current_path,
           "/sys/class/power_supply/battery/current_now");
  cfg.batt_current_ma_unit = 0;
  cfg.boot_full_s = 60;
  /* 默认不碰调速器：部分厂商内核（荣耀/华为）切到 conservative 会硬重启。
     旧版这里写的是 conservative，升级用户的配置里可能还留着那一行，
     customize.sh 会做一次迁移清掉。 */
  cfg.governor[0] = 0;
  /* 实时偏移的默认值。插电放宽默认开（电从充电器来，没必要压着）；
     温控闭环默认**关**——交给内核热管理，想主动压再开；PSI 默认开但
     只借一档（+5%）：护栏要的是"偶尔让一下"，不是把封顶顶回去。
     每个来源各有上限，合计再有一对总闸（默认 +15 / -30），
     避免"每一项都合法、叠起来不可用"。 */
  cfg.ad.psi = 1;   cfg.ad.psi_gain = 5;   cfg.ad.psi_step = 5;
  cfg.ad.psi_hold = 30;  cfg.ad.psi_back = 15;
  cfg.ad.th = 0;    cfg.ad.th_high = 75;   cfg.ad.th_low = 68;
  cfg.ad.th_step = 5;   cfg.ad.th_max = 25;  cfg.ad.th_back = 20;
  cfg.ad.chg = 1;   cfg.ad.chg_pct = 100;
  cfg.ad.up_max = 15;    cfg.ad.down_max = 30;
  cfg.ad.batt = 0;  cfg.ad.batt_low = 20;  cfg.ad.batt_low_cut = 5;
  cfg.ad.batt_crit = 10; cfg.ad.batt_crit_cut = 10;
  for (int i = 0; i < 4; i++) cfg.pct[i] = dflt[i];
  for (int i = 0; i < 4; i++) cfg.min_pct[i] = 0;
  cfg.cap_floor_m = 0;

  if (cfg_get("INTERVAL", v) == 0) cfg.interval = clampi(atoi(v), 2, 60, 5);
  {
    /* 旧键仍读：只给 keep 策略下那条旧的熄屏解锁分支用，不再影响策略选择。 */
    if (cfg_get("SCREEN_UNCAP", v) == 0)
      cfg.screen_uncap = (!strcmp(v, "1") || !strcasecmp(v, "true")) ? 1 : 0;
    /* 没有 SCREEN_POLICY 的手写/极老配置一律按 cap（轻巡检常开）；
       显式写了 keep / uncap 的高级配置仍尊重。 */
    if (cfg_get("SCREEN_POLICY", v) == 0) {
      if (!strcasecmp(v, "uncap")) cfg.screen_policy = SCREEN_UNCAP;
      else if (!strcasecmp(v, "keep")) cfg.screen_policy = SCREEN_KEEP;
      else if (!strcasecmp(v, "cap") || !strcasecmp(v, "cap_off"))
        cfg.screen_policy = SCREEN_CAP;
    }
  }
  if (cfg_get("SOFF_INTERVAL", v) == 0)
    cfg.soff_interval = clampi(atoi(v), 5, 300, 15);
  if (cfg_get("SCREEN_STATE_PATH", v) == 0 && v[0] == '/') {
    char *e = v + strlen(v);
    while (e > v && isspace((unsigned char)e[-1])) *--e = 0;
    if (strlen(v) < sizeof cfg.screen_state_path)
      snprintf(cfg.screen_state_path, sizeof cfg.screen_state_path, "%s", v);
  }
  if (cfg_get("IDLE_CURRENT_MA", v) == 0) cfg.idle_current_ma = clampi(atoi(v), 20, 2000, 250);
  if (cfg_get("IDLE_HOLD_CYCLE", v) == 0) cfg.idle_hold_cycle = clampi(atoi(v), 1, 10, 2);
  if (cfg_get("IDLE_INTERVAL", v) == 0) cfg.idle_interval = clampi(atoi(v), 10, 300, 30);
  if (cfg_get("WAKE_DELTA_MA", v) == 0) cfg.wake_delta_ma = clampi(atoi(v), 20, 2000, 150);
  if (cfg_get("BATT_CURRENT_PATH", v) == 0 && v[0] == '/') {
    char *e = v + strlen(v);
    while (e > v && isspace((unsigned char)e[-1])) *--e = 0;
    if (strlen(v) < sizeof cfg.batt_current_path)
      snprintf(cfg.batt_current_path, sizeof cfg.batt_current_path, "%s", v);
  }
  if (cfg_get("BATT_CURRENT_UNIT", v) == 0)
    cfg.batt_current_ma_unit = !strcasecmp(v, "ma");
  if (cfg_get("STRATEGY", v) == 0)
    cfg.strategy = !strcasecmp(v, "smart") ? 1 : 0;
  /* 开机满血窗口上限 600s：再长就不是"开机提速"而是"忘了限频"了，
     而且窗口越长，越容易盖过厂商开机的热管理。 */
  if (cfg_get("BOOT_FULL_S", v) == 0)
    cfg.boot_full_s = clampi(atoi(v), 0, 600, 60);
  if (cfg_get("GAME_GRACE_SEC", v) == 0)
    cfg.grace = clampi(atoi(v), cfg.interval, 300, 30);
  if (cfg_get("SUPPRESS", v) == 0)
    cfg.suppress = (!strcmp(v, "0") || !strcasecmp(v, "false")) ? 0 : 1;
  if (cfg_get("SUP_STYLE", v) == 0)
    cfg.sup_style = !strcasecmp(v, "sav") ? 1 : 0;
  if (cfg_get("APP_SWITCH_TIER", v) == 0)
    cfg.app_switch_tier = clampi(atoi(v), 0, 3, 2);
  {
    /* 分簇限速；某簇没写就用旧键（旧版是三簇统一值）。 */
    static const char *const upk[3] = {
      "GOV_UP_BIG", "GOV_UP_MID", "GOV_UP_LITTLE",
    };
    static const char *const dnk[3] = {
      "GOV_DOWN_BIG", "GOV_DOWN_MID", "GOV_DOWN_LITTLE",
    };
    int have_up[3] = {0, 0, 0}, have_dn[3] = {0, 0, 0};
    for (int i = 0; i < 3; i++) {
      if (cfg_get(upk[i], v) == 0) {
        cfg.gov_up_us[i] = clampi(atoi(v), 100, 50000, cfg.gov_up_us[i]);
        have_up[i] = 1;
      }
      if (cfg_get(dnk[i], v) == 0) {
        cfg.gov_down_us[i] = clampi(atoi(v), 100, 50000, cfg.gov_down_us[i]);
        have_dn[i] = 1;
      }
    }
    int old_up = -1, old_dn = -1;
    if (cfg_get("GOV_UP_US", v) == 0)
      old_up = clampi(atoi(v), 100, 50000, 1000);
    if (cfg_get("GOV_DOWN_US", v) == 0)
      old_dn = clampi(atoi(v), 100, 50000, 1000);
    for (int i = 0; i < 3; i++) {
      if (!have_up[i] && old_up >= 0) cfg.gov_up_us[i] = old_up;
      if (!have_dn[i] && old_dn >= 0) cfg.gov_down_us[i] = old_dn;
    }
  }
  if (cfg_get("GPU_PCT", v) == 0)
    cfg.gpu_pct = clampi(atoi(v), 1, 100, 45);
  /* GPU 下限锁定和 Boost 源中和已合并成一个开关。旧配置里可能只有
     GPU_MIN_LOCK：没有 GPU_BOOST_OFF 时按旧值迁移；两个都没有按开。
     cfg.gpu_min_lock 只作为旧代码的别名，不再单独开放。 */
  int gbo_seen = 0, gml_seen = 0, gbo_val = 1, gml_val = 1;
  if (cfg_get("GPU_BOOST_OFF", v) == 0) {
    gbo_seen = 1;
    gbo_val = (!strcmp(v, "0") || !strcasecmp(v, "false")) ? 0 : 1;
  }
  if (cfg_get("GPU_MIN_LOCK", v) == 0) {
    gml_seen = 1;
    gml_val = (!strcmp(v, "0") || !strcasecmp(v, "false")) ? 0 : 1;
  }
  cfg.gpu_boost_off = gbo_seen ? gbo_val : (gml_seen ? gml_val : 1);
  cfg.gpu_min_lock = cfg.gpu_boost_off;
  if (cfg_get("BG_LIGHT", v) == 0)
    cfg.bg_light = (!strcmp(v, "0") || !strcasecmp(v, "false")) ? 0 : 1;
  if (cfg_get("CPU_GOVERNOR", v) == 0) {
    trim(v);
    /* 只接受白名单内的名字，避免把任意字符串写进 sysfs */
    cfg.governor[0] = 0;
    if (v[0] && !strpbrk(v, "/ \t;|&$`\\()")) {
      for (char *c = v; *c; c++)
        if (!isalnum((unsigned char)*c) && *c != '_') {
          v[0] = 0;
          break;
        }
      if (v[0]) snprintf(cfg.governor, sizeof cfg.governor, "%s", v);
    }
  } else if (cfg_key_present("CPU_GOVERNOR")) {
    /* "不干预"写成空值：保留空，运行时/退出时按快照还原原调速器。 */
    cfg.governor[0] = 0;
  }
  if (cfg_get("BIG_MIN", v) == 0)
    cfg.big_min = (!strcmp(v, "0") || !strcasecmp(v, "false")) ? 0 : 1;
  if (cfg_get("CPU_MIN_LOCK", v) == 0)
    cfg.cpu_min_lock = (!strcmp(v, "0") || !strcasecmp(v, "false")) ? 0 : 1;
  if (cfg_get("CAP_BACKEND", v) == 0) {
    trim(v);
    if (!strcasecmp(v, "sysfs")) cfg.cap_backend = CAP_BE_SYSFS;
    else if (!strcasecmp(v, "ppm")) cfg.cap_backend = CAP_BE_PPM;
    else if (!strcasecmp(v, "msm")) cfg.cap_backend = CAP_BE_MSM;
    else cfg.cap_backend = CAP_BE_AUTO;
  }
  for (int i = 0; i < 4; i++)
    if (cfg_get(keys[i], v) == 0)
      cfg.pct[i] = clampi(atoi(v), 1, 100, dflt[i]);
  {
    static const char *const mkeys[4] = {
      "CPU_MIN_PCT_BIG", "CPU_MIN_PCT_MID2",
      "CPU_MIN_PCT_MID", "CPU_MIN_PCT_LITTLE",
    };
    for (int i = 0; i < 4; i++)
      if (cfg_get(mkeys[i], v) == 0)
        cfg.min_pct[i] = clampi(atoi(v), 0, 100, 0);
  }
  if (cfg_get("CPU_FLOOR_M", v) == 0)
    cfg.cap_floor_m = clampi(atoi(v), 0, 10000000, 0);

  /* 实时偏移。区间故意收窄：这些数直接决定"最坏能比设定值宽/严多少"，
     放开了填会让模块看起来"没生效"或"压太狠"。 */
  if (cfg_get("PSI_ADAPT", v) == 0)
    cfg.ad.psi = (!strcmp(v, "0") || !strcasecmp(v, "false")) ? 0 : 1;
  if (cfg_get("PSI_GAIN", v) == 0) cfg.ad.psi_gain = clampi(atoi(v), 0, 30, 5);
  if (cfg_get("PSI_STEP", v) == 0) cfg.ad.psi_step = clampi(atoi(v), 1, 10, 5);
  if (cfg_get("PSI_HOLD", v) == 0) cfg.ad.psi_hold = clampi(atoi(v), 5, 600, 30);
  if (cfg_get("PSI_BACK", v) == 0) cfg.ad.psi_back = clampi(atoi(v), 5, 600, 15);
  if (cfg_get("TH_CAP", v) == 0)
    cfg.ad.th = (!strcmp(v, "0") || !strcasecmp(v, "false")) ? 0 : 1;
  if (cfg_get("TH_HIGH", v) == 0) cfg.ad.th_high = clampi(atoi(v), 35, 110, 75);
  if (cfg_get("TH_LOW", v) == 0)  cfg.ad.th_low = clampi(atoi(v), 30, 105, 68);
  if (cfg_get("TH_STEP", v) == 0) cfg.ad.th_step = clampi(atoi(v), 1, 10, 5);
  if (cfg_get("TH_MAX", v) == 0)  cfg.ad.th_max = clampi(atoi(v), 0, 60, 25);
  if (cfg_get("TH_BACK", v) == 0) cfg.ad.th_back = clampi(atoi(v), 5, 600, 20);
  if (cfg_get("CHG_UNCAP", v) == 0)
    cfg.ad.chg = (!strcmp(v, "0") || !strcasecmp(v, "false")) ? 0 : 1;
  if (cfg_get("CHG_PCT", v) == 0) cfg.ad.chg_pct = clampi(atoi(v), 20, 100, 100);
  if (cfg_get("ADAPT_UP_MAX", v) == 0) cfg.ad.up_max = clampi(atoi(v), 0, 100, 15);
  if (cfg_get("ADAPT_DOWN_MAX", v) == 0) cfg.ad.down_max = clampi(atoi(v), 0, 100, 30);
  if (cfg_get("BATT_STEP", v) == 0)
    cfg.ad.batt = (!strcmp(v, "1") || !strcasecmp(v, "true")) ? 1 : 0;
  if (cfg_get("BATT_LOW", v) == 0) cfg.ad.batt_low = clampi(atoi(v), 5, 95, 20);
  if (cfg_get("BATT_LOW_CUT", v) == 0) cfg.ad.batt_low_cut = clampi(atoi(v), 0, 30, 5);
  if (cfg_get("BATT_CRIT", v) == 0) cfg.ad.batt_crit = clampi(atoi(v), 1, 95, 10);
  if (cfg_get("BATT_CRIT_CUT", v) == 0) cfg.ad.batt_crit_cut = clampi(atoi(v), 0, 30, 10);
  /* 两档必须错开，否则 10% 以下会同时叠两刀、数值不可预期。 */
  if (cfg.ad.batt_crit >= cfg.ad.batt_low) {
    cfg.ad.batt_crit = cfg.ad.batt_low - 5;
    if (cfg.ad.batt_crit < 1) cfg.ad.batt_crit = 1;
  }
  /* 恢复线必须低于触发线，否则温度在阈值附近时会逐档来回抖。
     填反了就贴着触发线往下留 5 度，而不是直接关掉温控。 */
  if (cfg.ad.th_low >= cfg.ad.th_high) cfg.ad.th_low = cfg.ad.th_high - 5;
  if (cfg.ad.th_low < 30) cfg.ad.th_low = 30;
  /* 0 = 整条环路关。GAIN/MAX 连一个 STEP 都凑不齐时按"关"处理，
     不能兜底成"至少一档"——那会让界面上的 0 实际仍然 -5/+5。 */
  if (cfg.ad.psi_gain > 0 && cfg.ad.psi_gain < cfg.ad.psi_step) {
    log("WARN PSI_GAIN=%d 小于 PSI_STEP=%d，PSI 护栏停用（填 0 或至少一档）",
        cfg.ad.psi_gain, cfg.ad.psi_step);
    cfg.ad.psi_gain = 0;
  }
  if (cfg.ad.th_max > 0 && cfg.ad.th_max < cfg.ad.th_step) {
    log("WARN TH_MAX=%d 小于 TH_STEP=%d，温控收紧停用（填 0 或至少一档）",
        cfg.ad.th_max, cfg.ad.th_step);
    cfg.ad.th_max = 0;
  }
}

/* ------------------------------------------------------------------ */
/* 状态发布                                                           */
/* ------------------------------------------------------------------ */

static char g_status_cache[4096];
static size_t g_status_len;

/* 往固定缓冲区追加；状态很短，不需要动态分配。 */
static size_t ps_append(char *b, size_t cap, size_t n, const char *fmt, ...) {
  if (n >= cap) return n;
  va_list ap;
  va_start(ap, fmt);
  int w = vsnprintf(b + n, cap - n, fmt, ap);
  va_end(ap);
  if (w < 0) return n;
  size_t add = (size_t)w;
  if (add > cap - n - 1) add = cap - n - 1;
  return n + add;
}

static void publish_status(void) {
  char buf[4096];
  size_t n = 0;
  /* 生效中的应用档位。"" 表示没有专属档位，走全局百分比。 */
  char mode[16], gmode[8];
  if (g_app_pct == MODE_FULL) snprintf(mode, sizeof mode, "full");
  else if (g_app_big > 0 || g_app_little > 0)
    snprintf(mode, sizeof mode, "%d/%d", g_app_big, g_app_little);
  else if (g_app_pct > 0) snprintf(mode, sizeof mode, "%d", g_app_pct);
  else mode[0] = 0;
  /* 空 = GPU 跟随全局；和 app_mode 分开报，前端不用去拆 70:40 这种串 */
  if (g_app_gpu > 0) snprintf(gmode, sizeof gmode, "%d", g_app_gpu);
  else gmode[0] = 0;
  /* fg 是"此刻前台是谁"，game_pkg 是"命中名单的那个"。
   * 两个必须分开：页面上"把当前前台应用设为满血"要的是 fg，
   * 而它大部分时候根本不是游戏（相机、地图、播放器）。
   * 只报 game_pkg 的话，非游戏态那半永远是空，按钮就永远点不动。 */
  /* 这台机实际用掉几档（1..4）。api.sh 的按应用建议要拿它算"没设档位的包"
   * 的基准：2 簇机型把 MID2/MID 的配置值也平均进去，基准会差 5~10 个点。 */
  int ntier = 0;
  {
    int used[4] = {0, 0, 0, 0};
    for (int i = 0; i < g_npol; i++)
      if (g_pol[i].tier >= 0 && g_pol[i].tier < 4) used[g_pol[i].tier] = 1;
    for (int t = 0; t < 4; t++) ntier += used[t];
  }
  int cmin_paused = cfg.cpu_min_lock && g_min_fails >= 3 &&
                    mono_sec() - g_min_fail_at < 600;
  int cmin_give = 0;
  for (int i = 0; i < g_npol; i++) cmin_give += g_min_giveup[i];
  n = ps_append(buf, sizeof buf, n,
             "state=%s\nscreen=%s\nsoff=%d\nsoff_keep=%d\ngame_pkg=%s\nreason=%s\n"
             "fg=%s\napp_mode=%s\napp_big=%d\napp_little=%d\napp_gpu=%s\n"
             "pid=%d\nver=%s\nntier=%d\ncapbe=%s\n"
             "strat=%d\nsmart=%d\nprime=%d\nsup=%d\ntick=%ld\nfgprobe=%ld\ngminw=%ld\n"
             "cminw=%ld\ncminf=%d\ncminpaused=%d\ncming=%d\n",
          g_state, g_deep ? "deep" : (g_screen_off ? "off" : "on"),
          g_deep ? cfg.idle_interval : cfg.soff_interval, g_soff_keep,
          g_game[0] ? g_game : "-", g_reason,
          g_fg[0] ? g_fg : "-", mode, g_app_big, g_app_little, gmode,
          getpid(), SF_VERSION, ntier,
          g_npol > 0 ? cap_backend_name(g_pol[0].be) : "sysfs",
          cfg.strategy, g_sm.state, g_prime_state,
          cfg.suppress ? sup_pct() : 0,
          g_tick_n, g_fg_probe_n, g_gmin_writes,
          g_min_writes, g_min_fails, cmin_paused, cmin_give);
  n = ps_append(buf, sizeof buf, n,
             "supup=%d\nsupfall=%d\nsupminn=%d\nsupbusy=%d\nsupfloor=%d\n"
             "supstuck0=%ld\nsupstuck1=%ld\nsupstuck2=%ld\nsupstuck3=%ld\n",
             g_sup_up_n, g_sup_fall_n, g_sup_min_n, g_sup_last_busy,
             g_sup_floor_busy_n,
             MAX_POLICY > 0 ? g_sup_stuck[0] : 0,
             MAX_POLICY > 1 ? g_sup_stuck[1] : 0,
             MAX_POLICY > 2 ? g_sup_stuck[2] : 0,
             MAX_POLICY > 3 ? g_sup_stuck[3] : 0);
  /* 实时偏移的三个来源一起发出去：页面上"实际比设定宽/严了多少"必须说得出是谁干的，
   * 只剩一个合计数就等于让人猜。读不到的传感器发 -1，页面据此不显示那一项。 */
  {
    struct adapt a;
    adapt_snapshot(&a);
    n = ps_append(buf, sizeof buf, n,
               "dlt=%d\nbatt=%d\nbcut=%d\nstall=%d\npsib=%d\navg10=%d\ntemp=%d\n"
               "chg=%d\npsi=%d\nth=%d\npsifrz=%d\n",
            effective_delta(&a), a.capacity, a.batt_cut,
            (a.have_psi && a.psi_valid) ? a.stall : -1, a.base, a.avg10x100,
            a.temp_m > 0 ? a.temp_m / 1000 : -1, a.charging, a.psi_steps, a.th_steps,
            a.base_frozen);
  }
  /* 熄屏轻巡检周期长、内容经常一模一样；一样就不落盘，省掉一次
     tmp 写 + rename 的 flash 元数据。亮屏仍每拍写，页面要实时数。 */
  if (g_screen_off && access(STATUS_FILE, F_OK) == 0 && g_status_len &&
      n == g_status_len && !memcmp(buf, g_status_cache, n))
    return;
  char tmp[256];
  snprintf(tmp, sizeof tmp, "%s.tmp", STATUS_FILE);
  FILE *out = fopen(tmp, "w");
  if (!out) return;
  int ok = fwrite(buf, 1, n, out) == n;
  ok = (fclose(out) == 0) && ok;
  if (!ok || rename(tmp, STATUS_FILE) != 0) {
    unlink(tmp);
    return;
  }
  memcpy(g_status_cache, buf, n);
  g_status_len = n;
}

/* ------------------------------------------------------------------ */
/* 清理                                                               */
/* ------------------------------------------------------------------ */

static void cleanup(void) {
  if (!g_have_lock) return;
  log("停止，恢复启动前状态");
  restore_governors();
  /* 顺序：先还原数值，再收权限。反了会写不进需要放开才能写的节点 */
  if (g_gpu.mtk) mtk_restore_row();
  /* 第二道锁先放掉；否则 sysfs 写回原值会被厂商硬限压着。 */
  be_restore_cleanup();
  journal_restore(NODES_JOURNAL);
  cpuset_restore_all();             /* 字符串账本：cpuset 原掩码 */
  suppress_uclamp_max_restore();    /* 字符串账本：uclamp.max 原值 */
  bg_light_restore();               /* 字符串账本：后台分组原值 */
  perms_restore();
  unlink(STATE_FILE);
  unlink(STATUS_FILE);
  unlink(HEARTBEAT_FILE);
  /* 锁文件只清空、不删除：删了会让下一个实例锁到新的 inode，
   * 和还没退干净的旧实例各锁一份，出现两个守护同时巡检。 */
  if (g_lock_fd >= 0) {
    if (!ftruncate(g_lock_fd, 0)) lseek(g_lock_fd, 0, SEEK_SET);
  }
  g_have_lock = 0;
}

static void on_signal(int sig) {
  (void)sig;
  /*
   * 信号处理里只置标志：恢复要写 sysfs，绝不能在这里做。
   * 标志在 sleep() 结束后才被看到，最长延迟一个巡检周期。
   */
  g_stop = 1;
}

/* ------------------------------------------------------------------ */
/* main                                                               */
/* ------------------------------------------------------------------ */

/*
 * pid 是否确实是本守护。
 * pid 会被系统回收给别的进程，只 kill(pid,0) 不够——
 * 那样一次陈旧的锁文件就能让 stop/restart 打死一个无辜进程。
 */
static int pid_is_daemon(long pid) {
  if (pid <= 1) return 0;
  if (kill((pid_t)pid, 0)) return 0; /* 不存在 */
  char path[64], name[32];
  snprintf(path, sizeof path, "/proc/%ld/comm", pid);
  if (read_file(path, name, sizeof name)) return 0; /* 读不到就不信 */
  trim(name);
  return !strncmp(name, "socfreqd", 8);
}

/*
 * 守护是否真的在跑。
 * 不能只看锁文件在不在：被 kill -9 时不会执行 cleanup，锁文件会残留，
 * 那样看门狗/WebUI 会永远认为"有人在跑"。判据必须是 pid 还活着。
 */
static int daemon_alive(void) {
  char b[32];
  long pid;
  if (read_file(LOCK_FILE, b, sizeof b)) return 0;
  pid = atol(b);
  if (pid <= 1) return 0;
  /* kill(pid,0) 返回 0 表示进程存在；EPERM 表示存在但无权限，同样算活着 */
  if (kill((pid_t)pid, 0)) return 0;
  return 1;
}

/* 锁文件里有没有"上次的 pid"。干净退出会把它清空，不算残留。 */
static int lock_has_pid(void) {
  char b[32];
  if (read_file(LOCK_FILE, b, sizeof b)) return 0;
  return atol(b) > 1;
}

static int acquire_lock(void) {
  /*
   * 残留锁自愈：上一实例被 kill -9 时不会走到 cleanup，锁文件会留下。
   * flock 已经随进程退出发放，所以拿得到锁；但要让内容反映真实 pid，
   * 否则 service.sh 与 WebUI 会读到陈旧 pid 而误判。
   */
  int stale = lock_has_pid() && !daemon_alive();
  int fd = open(LOCK_FILE, O_RDWR | O_CREAT, 0644);
  if (fd < 0) return -1;
  if (flock(fd, LOCK_EX | LOCK_NB)) {
    close(fd);
    return -1;
  }
  if (!ftruncate(fd, 0)) {
    char b[32];
    int n = snprintf(b, sizeof b, "%d\n", getpid());
    ssize_t w = write(fd, b, n);
    (void)w;
    if (stale) log("清理残留锁文件（上次非正常退出）");
  }
  g_lock_fd = fd;
  g_have_lock = 1;
  /* fd 故意不关：flock 随进程退出自动释放；cleanup 只清空内容，不删文件。
   * 以前 cleanup 里 unlink 锁文件，会出现"旧进程 unlink、新进程刚建好同名文件"
   * 的时序：两个进程各自锁住不同的 inode，于是能同时跑两个守护（实测出现过）。
   * 文件不删，所有实例锁的就是同一个 inode，flock 才有意义。 */
  return 0;
}

/* 定义 SF_TEST 时不编 main，直接包含测试文件跑内部函数。 */
#ifdef SF_TEST
#include "test_real.c"
#else
/* 逐核状态。update=1 时把这一拍的增量推进 5 秒环（WebUI 每秒调 cores）；
 * update=0 只读窗口快照（export 每 5 秒被 status 调一次，不能再喂样本，
 * 否则 5 秒的大增量会把 1 秒的小样本挤掉）。ring 为空时先初始化一次。 */
static void dump_cores(int update) {
  core_state_lock();
  core_state_load();
  int dirty = 0;
  long st_total[MAX_CORES], st_idle[MAX_CORES];
  memset(st_total, 0, sizeof st_total);
  memset(st_idle, 0, sizeof st_idle);
  int have_stat = core_stat_read(st_total, st_idle) > 0;
  int cores[MAX_CORES];
  int nc = 0;
  for (int c = 0; c < MAX_CORES; c++)
    if (core_exists(c)) cores[nc++] = c;
  printf("ncores=%d\n", nc);
  for (int i = 0; i < nc; i++) {
    const int c = cores[i];
    char b[96];
    core_path(b, sizeof b, c, "cpuinfo_cur_freq");
    long cur = read_num(b);
    if (cur <= 0) {
      core_path(b, sizeof b, c, "scaling_cur_freq");
      cur = read_num(b);
    }
    printf("corehz_%d=%ld\n", c, cur > 0 ? cur : 0);

    core_path(b, sizeof b, c, "cpuinfo_max_freq");
    long maxf = read_num(b);
    printf("coremax_%d=%ld\n", c, maxf > 0 ? maxf : 0);

    core_path(b, sizeof b, c, "cpuinfo_min_freq");
    long minf = read_num(b);
    printf("coremin_%d=%ld\n", c, minf > 0 ? minf : 0);

    core_path(b, sizeof b, c, "scaling_max_freq");
    long tgt = read_num(b);
    if (tgt <= 0) tgt = maxf;
    printf("coretgt_%d=%ld\n", c, tgt > 0 ? tgt : 0);

    printf("corepol_%d=%d\n", c, core_policy_of(c));

    struct core_hist *h = &g_ch[c];
    int load = 0;
    if (update) {
      if (have_stat && h->have_prev)
        load = core_load_pct(st_total[c], st_idle[c], h->prev_total, h->prev_idle);
      core_hist_push(h, cur, load);
      if (have_stat) {
        h->prev_total = st_total[c];
        h->prev_idle = st_idle[c];
        h->have_prev = 1;
      }
      dirty = 1;
    } else if (h->n > 0) {
      load = (int)h->load[h->n - 1];
    }

    long lo = 0, hi = 0;
    core_hist_range(h, &lo, &hi);
    if (lo <= 0 && hi <= 0 && cur > 0) { lo = cur; hi = cur; }
    printf("coreload_%d=%d\n", c, load);
    printf("corefreqs_%d=", c);
    for (int k = 0; k < h->n; k++) printf("%ld%s", h->freq[k], k + 1 < h->n ? "," : "");
    printf("\n");
    printf("coreloads_%d=", c);
    for (int k = 0; k < h->n; k++) printf("%ld%s", h->load[k], k + 1 < h->n ? "," : "");
    printf("\n");
    printf("coreobsmin_%d=%ld\n", c, lo);
    printf("coreobsmax_%d=%ld\n", c, hi);
  }
  printf("coredet=");
  for (int i = 0; i < nc; i++) printf("%d%s", cores[i], i + 1 < nc ? "," : "");
  printf("\n");
  if (dirty) core_state_save();
  core_state_unlock();
}

int main(int argc, char **argv) {
  ovr_load();   /* 适配覆盖：只给后面"探测不到"那条路用，正常机器读不到这文件 */
  const char *cmd = argc > 1 ? argv[1] : "start";

  if (!strcmp(cmd, "version")) {
    printf("socfreqd %s\n", SF_VERSION);
    return 0;
  }
  if (!strcmp(cmd, "status")) {
    char b[256];
    read_file(STATUS_FILE, b, sizeof b);
    printf("%s", b[0] ? b : "state=unknown\n");
    return 0;
  }
  if (!strcmp(cmd, "uninstall")) {
    /*
     * 卸载：先停掉在跑的实例（它自己会恢复），再强制按 journal 兜底。
     * 守护被 kill -9 或看门狗没拉起时，这是唯一的清理路径。
     */
    char b[32];
    long pid = 0;
    if (!read_file(LOCK_FILE, b, sizeof b)) pid = atol(b);
    if (pid_is_daemon(pid) && pid != getpid()) {
      kill((pid_t)pid, SIGTERM);
      for (int i = 0; i < 50; i++) {
        struct timespec ts = {0, 100000000};
        nanosleep(&ts, NULL);
        if (kill((pid_t)pid, 0)) break;
      }
      if (!kill((pid_t)pid, 0)) {
        kill((pid_t)pid, SIGKILL);
        nanosleep(&(struct timespec){0, 200000000}, NULL);
      }
    }
    log_open();
    log("卸载清理 pid=%d", getpid());
    g_have_lock = 1; /* 让 cleanup() 执行恢复 */
    cleanup();
    /*
     * 补一道兜底：只修"谁都写不动"的情况。
     * 不能无条件压成 0644 —— 出厂就是 0664/0666 的机型（system 组需要写）
     * 会被改得比原厂更严，反而弄坏厂商调度。
     */
    DIR *d = opendir(CPUFREQ);
    if (d) {
      struct dirent *e;
      while ((e = readdir(d))) {
        char path[256];
        if (strncmp(e->d_name, "policy", 6)) continue;
        snprintf(path, sizeof path, "%s/%s/scaling_max_freq", CPUFREQ, e->d_name);
        if ((read_mode(path) & 0222) == 0) chmod(path, 0644);
        snprintf(path, sizeof path, "%s/%s/scaling_governor", CPUFREQ, e->d_name);
        if ((read_mode(path) & 0222) == 0) chmod(path, 0644);
      }
      closedir(d);
    }
    unlink(PAUSE_FILE);
    printf("cleaned\n");
    return 0;
  }
  if (!strcmp(cmd, "stop") || !strcmp(cmd, "restart")) {
    /*
     * 只对确实持有 flock 的进程下手：读锁文件里的 pid，确认它还活着再发信号。
     * 拿不到锁说明没在跑，省掉一次无谓的系统调用。
     */
    char b[32];
    long pid = 0;
    if (!read_file(LOCK_FILE, b, sizeof b)) pid = atol(b);
    if (pid_is_daemon(pid) && pid != getpid()) {
      kill((pid_t)pid, SIGTERM);
      printf("sent SIGTERM to pid %ld\n", pid);
    } else {
      printf("not running\n");
    }
    if (!strcmp(cmd, "stop")) {
      /*
       * 先落 pause，否则看门狗 30 秒后就把守护复活了 ——
       * "停止"必须真的是停住。
       */
      int pfd = open(PAUSE_FILE, O_CREAT | O_WRONLY, 0644);
      if (pfd >= 0) close(pfd);
      printf("paused and stopped\n");
      return 0;
    }
    /* restart：必须清掉 pause，否则 start 侧的守卫会静默拒绝 */
    unlink(PAUSE_FILE);
    /* restart：等旧实例退出（它退出时要把节点恢复回原值）再接手，最多 5 秒 */
    if (pid > 1) {
      for (int i = 0; i < 50; i++) {
        struct timespec ts = {0, 100000000};
        nanosleep(&ts, NULL);
        if (!pid_is_daemon(pid)) break;
      }
    }
    /*
     * 守护循环是前台常驻的，所以必须交给子进程去跑，不能在这里 exec 自己：
     * 那样"重启守护"这条命令永远不返回，调它的 WebUI 请求、action.sh、
     * 适配包导入回执全被吊住，管理器那头只会看到超时。
     * setsid 让它脱离调用者的进程组——管理器掐掉请求进程组时不该顺带杀掉守护。
     */
    pid_t f = fork();
    if (f < 0) { perror("fork"); return 1; }
    if (f == 0) {
      setsid();
      int fd = open("/dev/null", O_RDWR);
      if (fd >= 0) {
        dup2(fd, 0); dup2(fd, 1); dup2(fd, 2);
        if (fd > 2) close(fd);
      }
      execl(SF_MODDIR "/socfreqd", "socfreqd", "start", (char *)NULL);
      _exit(127);
    }
    printf("restart issued\n");
    return 0;
  }
  if (!strcmp(cmd, "export")) {
    /*
     * 给 WebUI 用的只读快照，输出 key=value 行。
     * 走 stdout 而不是一个 webroot 临时文件：省一次临时文件往返，
     * 也避免 WebUI 把文件写进模块目录。
     */
    load_cfg();
    struct policy p[MAX_POLICY];
    int n = detect_policies(p);
    /* 智能模式的档位活在守护进程里，export 是独立进程：不读 status 的话
       g_sm.state 永远是 0，页面会把"空闲档目标"当成当前封顶显示。 */
    {
      FILE *sf = fopen(STATUS_FILE, "r");
      if (sf) {
        char ln[128];
        while (fgets(ln, sizeof ln, sf)) {
          if (!strncmp(ln, "smart=", 6))
            g_sm.state = clampi(atoi(ln + 6), 0, 3, 0);
          else if (!strncmp(ln, "prime=", 6))
            g_prime_state = clampi(atoi(ln + 6), -1, 3, -1);
        }
        fclose(sf);
      }
    }
    assign_pct(p, n); /* 让 WebUI 显示的是当前百分比算出的封顶值 */
    /* 不加载的话 npkg 恒为 0，WebUI 的"游戏名单"计数就是错的 */
    load_game_pkgs();
    load_app_modes();
    printf("ver=%s\n", SF_VERSION);
    printf("nmode=%d\n", g_nmode);
    printf("alive=%d\n", daemon_alive());
    printf("paused=%d\n", !access(PAUSE_FILE, F_OK));
    printf("interval=%d\n", cfg.interval);
    printf("grace=%d\n", cfg.grace);
    printf("pct_big=%d\n", cfg.pct[0]);
    printf("pct_mid2=%d\n", cfg.pct[1]);
    printf("pct_mid=%d\n", cfg.pct[2]);
    printf("pct_little=%d\n", cfg.pct[3]);
    printf("gpu_pct=%d\n", cfg.gpu_pct);
    printf("gpu_min_lock=%d\n", cfg.gpu_min_lock);
    printf("gpu_boost_off=%d\n", cfg.gpu_boost_off);
    printf("big_min=%d\n", cfg.big_min);
    printf("cpu_min_lock=%d\n", cfg.cpu_min_lock);
    printf("cpu_floor_m=%d\n", cfg.cap_floor_m);
    printf("screen_uncap=%d\n", cfg.screen_uncap);
    printf("screen_policy=%s\n", cfg.screen_policy == SCREEN_UNCAP ? "uncap"
                              : cfg.screen_policy == SCREEN_CAP ? "cap" : "keep");
    printf("soff_interval=%d\n", cfg.soff_interval);
    printf("idle_interval=%d\nidle_current_ma=%d\nidle_hold=%d\nwake_delta=%d\n",
           cfg.idle_interval, cfg.idle_current_ma, cfg.idle_hold_cycle, cfg.wake_delta_ma);
    printf("batt_unit=%s\n", cfg.batt_current_ma_unit ? "ma" : "ua");
    printf("boot_full=%d\n", cfg.boot_full_s);
    /* 实时偏移：页面配置页要能显示、能改，所以和上面这些一样原样发出去 */
    printf("psi_adapt=%d\npsi_gain=%d\npsi_step=%d\n", cfg.ad.psi, cfg.ad.psi_gain, cfg.ad.psi_step);
    printf("th_cap=%d\nth_high=%d\nth_low=%d\nth_step=%d\nth_max=%d\n",
           cfg.ad.th, cfg.ad.th_high, cfg.ad.th_low, cfg.ad.th_step, cfg.ad.th_max);
    printf("chg_uncap=%d\nchg_pct=%d\n", cfg.ad.chg, cfg.ad.chg_pct);
    printf("governor=%s\n", cfg.governor[0] ? cfg.governor : "");
    printf("gov_locked=%d\n", governor_locked());
    printf("npkg=%d\n", g_npkg);
    char soc[128];
    read_soc_name(soc, sizeof soc);
    printf("soc=%s\n", soc);
    cap_backend_report(p, n);

    dump_cores(0);

    for (int i = 0; i < n; i++) {
      char path[256];
      long cur;
      snprintf(path, sizeof path, "%s/scaling_max_freq", p[i].dir);
      cur = read_num(path); /* 失败返回 -1，下面单独判 */
      char vbuf[64] = "0";
      if (cur > 0) snprintf(vbuf, sizeof vbuf, "%ld", cur);
      /* cpu_N=硬件最高频，cpucur_N=当前实际封顶。
       * WebUI 要拿这两个算"66% 到底是多少 MHz"，只给一个不够。 */
      printf("cpu_%s=%ld\n", p[i].name + 6, p[i].hw_max);
      printf("cpucur_%s=%s\n", p[i].name + 6, vbuf);
      printf("cpucap_%s=%ld\n", p[i].name + 6, p[i].cap);
      printf("cpupct_%s=%ld\n", p[i].name + 6, p[i].pct);
      /* 档位 → 配置键名。WebUI 拖滑杆时要知道自己改的是 BIG 还是 MID2，
       * 不给的话它只能反推，两个 policy 同百分比时会分错。 */
      static const char *tier_names[4] = {"CPU_PCT_BIG", "CPU_PCT_MID2",
                                          "CPU_PCT_MID", "CPU_PCT_LITTLE"};
      printf("cpukey_%s=%s\n", p[i].name + 6,
             tier_names[p[i].tier & 3]);
      /* 频点表原样导出去，让前端做和守护 snap_freq 一样的吸附，
       * 避免前端草稿态直接乘百分比得到的显示值和守护实际吸附值对不上。 */
      {
        char fb[4096], fpath[256];
        fb[0] = 0;
        snprintf(fpath, sizeof fpath, "%s/scaling_available_frequencies", p[i].dir);
        /* read_file 返回 0 才是成功；写反了就会把栈残值当频点表吐给前端。 */
        if (!read_file(fpath, fb, sizeof fb))
          printf("policyfreq_%s=%s\n", p[i].name + 6, fb);
      }
    }

    /* ── 每个档位具体管着哪几颗核 ──────────────────────────────────
     * cpukey_N 的 N 是 **policy 号**不是核心号，一个 policy 可管多颗核心，
     * 这里按档位反查它名下的所有 CPU 号，逐档报一行：
     *   coretier_CPU_PCT_BIG=6,7
     * 缺失的档位**也要报一行、值留空**（coretier_BIG= 而不是报 -1）：
     * 前端靠"这个键在不在且非空"判断有没有这一档，从而区分"未检测到"。
     */
    {
      const char *keys[4] = {"CPU_PCT_BIG", "CPU_PCT_MID2",
                              "CPU_PCT_MID", "CPU_PCT_LITTLE"};
      /* 阶梯要用**未去重**的 policy 列表算，否则同一硬件上限的多个
       * policy 只剩一个，另一个管的核心整档丢失。 */
      struct policy all[MAX_POLICY];
      int na = detect_policies_raw(all);
      long ladder[MAX_POLICY];
      int m = build_ladder(all, na, ladder);
      for (int t = 0; t < 4; t++) {
        int ncpu = 0;
        /* 缺档也要报一行、值留空：前端靠"这个键在不在且非空"判断
         * 有没有这一档，从而区分未落到的档和读不出来的情况。 */
        printf("coretier_%s=", keys[t]);
        for (int i = 0; i < na; i++) {
          if (tier_key_of(ladder, m, all[i].hw_max) != t) continue;
          for (int c = 0; c < MAX_CORES; c++) {
            if (!core_exists(c)) continue;
            if (core_policy_of(c) != all[i].pol_no) continue;
            printf("%s%d", ncpu ? "," : "", c);
            ncpu++;
          }
        }
        printf("\n");
      }
      /* 这台机实际有几档。前端靠它区分
       * "这台机没这一档"（m=2 时 MID/MID2 恒定落空）
       * 和"这一档在但没读到核心"。
       * 报的是**被用掉的档位数**，不是 m：
       * m=2 时 tier_key_of 只会返回 0 和 3，实际用掉 2 档。 */
      int used[4] = {0, 0, 0, 0};
      for (int i = 0; i < na; i++) used[tier_key_of(ladder, m, all[i].hw_max)] = 1;
      int nt = 0;
      for (int t = 0; t < 4; t++) nt += used[t];
      printf("ntier=%d\n", nt);
    }
    /* GPU 同样要硬件最高与当前封顶，否则 45% 对用户没意义 */
    detect_gpu(1);
    /*
     * export 是独立进程，g_gpu.active 永远是 0，不能直接报它。
     * 运行中的守护每轮把生效值的前提（state / app_gpu / dlt）写进 status，
     * 这里按同一张频点表重算；status 不存在（守护没跑）才退回设定值。
     * 交权态（游戏/满血/熄屏）GPU 是解开的，报硬件最高。
     */
    long gcap = g_gpu.normal;
    int gpu_dlt = 0;
    {
      FILE *sf = fopen(STATUS_FILE, "r");
      if (sf) {
        char ln[128];
        int state_seen = 0, normal = 0, agpu = 0, bcut = 0, chg = 0, th = 0;
        while (fgets(ln, sizeof ln, sf)) {
          if (!strncmp(ln, "state=", 6)) {
            state_seen = 1;
            normal = !strncmp(ln + 6, "normal", 6);
          } else if (!strncmp(ln, "app_gpu=", 8)) {
            agpu = atoi(ln + 8);
          } else if (!strncmp(ln, "bcut=", 5)) {
            bcut = atoi(ln + 5);
          } else if (!strncmp(ln, "chg=", 4)) {
            chg = atoi(ln + 4);
          } else if (!strncmp(ln, "th=", 3)) {
            th = atoi(ln + 3);
          }
        }
        fclose(sf);
        /* 草稿预览要按同一个偏移算，否则滑杆显示 50%→600、保存后却变成
         * 偏移后的 282，看起来像守护没按百分比走。
         * GPU 不吃 PSI：显示值只扣温控档和电量阶梯。 */
        int gdlt = -(th * cfg.ad.th_step) - bcut;
        if (agpu > 0) gdlt += bcut;
        gpu_dlt = gdlt;
        if (state_seen && !normal) gcap = g_gpu.max_hz;
        else if (state_seen) {
          /* 应用 GPU 档不吃电量阶梯/充电地板，和 CPU 专属档同一个口径。 */
          int baseg = agpu > 0 ? agpu : cfg.gpu_pct;
          if (agpu <= 0 && chg == 1 && cfg.ad.chg && cfg.ad.chg_pct > baseg &&
              gdlt >= 0)
            baseg = cfg.ad.chg_pct;
          gcap = gpu_target_for(baseg, gdlt);
        }
      }
    }
    printf("gpu_max=%ld\n", g_gpu.max_hz);
    printf("gpu_cap=%ld\n", gcap);
    printf("gpu_dlt=%d\n", gpu_dlt);
    if (g_gpu.ok && g_gpu.ntbl > 0) {
      printf("gpufreq=");
      for (int i = 0; i < g_gpu.ntbl; i++)
        printf("%ld%s", g_gpu.tbl[i], i + 1 < g_gpu.ntbl ? " " : "");
      printf("\n");
    }
    printf("gpu_ok=%d\n", g_gpu.ok);
    /* max_hz / normal 恒为 Hz：detect_gpu 里 MHz 频点表已经 ×1e6 归一。
       不能用 max_is_mhz 来判断这两个数——那个标志说的是"往哪个节点写"时
       要不要 ×1e6，是写入单位，跟这两个值无关。混用会让选 MHz 节点的
       机型显示成 1200000 MHz，差 1000 倍。 */
    printf("gpu_unit=Hz\n");
    printf("gpu_kind=%s\n", g_gpu.mtk ? "MTK"
                              : strstr(g_gpu.max_node, "kgsl") ? "KGSL"
                              : strstr(g_gpu.max_node, "mali") ? "Mali" : "");
    return 0;
  }
  if (!strcmp(cmd, "cores")) {
    /* WebUI 每秒调一次：只读逐核频率/分布，不重新解析配置和温控。 */
    dump_cores(1);
    return 0;
  }
  if (!strcmp(cmd, "icon")) {
    /* 从 APK 取图标，输出 data URI。取不到就什么都不输出——
       页面据此退回首字母色块。名单里大部分包在手机上根本没装，
       这是常态而不是错误状态，报错会让整个名单页变成一个错误提示。
       argv[3] 可选：appinfo 已经确定该用哪张图时直接告诉它，
       省掉"猜"那一轮（资源名被缩短过的包靠猜会猜错，见 appinfo.c 头）。 */
    if (argc > 2) { icon_from_apk(argv[2], argc > 3 ? argv[3] : NULL); return 0; }
    return 0;
  }
  if (!strcmp(cmd, "iconpath")) {
    /* manifest 的 android:icon 声明的那张**位图**在 zip 里的路径。
       一行路径，取不到就一行空 —— 调用方据此决定要不要交给 icon 子命令。 */
    char path[200];
    path[0] = 0;
    if (argc > 2) appinfo_iconpath(argv[2], path, sizeof path);
    printf("%s\n", path);
    return 0;
  }
  if (!strcmp(cmd, "label")) {
    char name[128];
    name[0] = 0;
    if (argc > 2) appinfo_label(argv[2], name, sizeof name);
    printf("%s\n", name);
    return 0;
  }
  if (!strcmp(cmd, "labels")) {
    /* 批量：stdin 每行 "包名<TAB>APK 路径"，stdout 每行 "包名<TAB>应用名"。
       批量是因为一次读名字要重新走一遍中央目录，
       逐包 fork 几百次的开销比 IO 还大（见 appinfo.c 末尾）。 */
    return appinfo_labels_stdin();
  }
  if (!strcmp(cmd, "score")) {
    /* 纯函数式子命令：读 stdin、写 stdout、不碰任何节点、不需要 root。
     * api.sh 用它给 unzip 兜底挑图——挑图规则留在 C 里，
     * shell 那侧只负责把 `unzip -l` 的名字抠出来喂进来。 */
    return icon_score_stdin();
  }
  if (!strcmp(cmd, "probe")) {
    /* 只读探测：把将要施加的封顶打印出来，不写任何节点 */
    load_cfg();
    struct policy p[MAX_POLICY];
    int n = detect_policies(p);
    printf("=== cpufreq policy ===\n");
    for (int i = 0; i < n; i++) {
      char path[224];
      snprintf(path, sizeof path, "%s/scaling_max_freq", p[i].dir);
      printf("  %-8s hw=%-9ld vendor=%-9ld cur=%-9ld\n", p[i].name, p[i].hw_max,
             p[i].vendor_max, read_num(path));
    }
    assign_pct(p, n);
    printf("=== 计算封顶 ===\n");
    for (int i = 0; i < n; i++)
      printf("  %-8s cap=%-9ld (%ld%%)\n", p[i].name, p[i].cap, p[i].pct);
    printf("cpu_floor_m=%d\n", cfg.cap_floor_m);
    printf("=== cap backend ===\n");
    cap_backend_report(p, n);
    printf("=== GPU ===\n");
    detect_gpu(1);
    printf("  node=%s 最高=%ldHz 封顶=%ldHz\n", g_gpu.max_node[0] ? g_gpu.max_node : "无",
           g_gpu.max_hz, g_gpu.normal);
    return 0;
  }
  if (!strcmp(cmd, "probe_min")) {
    /* 下限探测：写一次 cpuinfo_min、立刻读回、再写回原值。
       失败只打印，不改账本、不留状态。 */
    load_cfg();
    struct policy p[MAX_POLICY];
    int n = detect_policies(p);
    printf("=== CPU 下限（写一次立刻还原）===\n");
    for (int i = 0; i < n; i++) {
      char path[256];
      snprintf(path, sizeof path, "%s/scaling_min_freq", p[i].dir);
      long cur = read_num(path);
      long want = p[i].hw_min;
      if (want <= 0 || cur <= 0) {
        printf("  %-8s 读不到当前值/硬件最低，跳过\n", p[i].name);
        continue;
      }
      if (cur <= want) {
        printf("  %-8s 已在硬件最低 %ld\n", p[i].name, cur);
        continue;
      }
      if (write_num(path, want)) {
        printf("  %-8s %ld -> %ld 写入失败（内核拒收）\n", p[i].name, cur, want);
        continue;
      }
      long got = read_num(path);
      write_num(path, cur);
      long back = read_num(path);
      printf("  %-8s %ld -> %ld %s（已还原 %ld）\n", p[i].name, cur, got,
             got == want ? "可写" : "被夹到别的值", back);
    }
    return 0;
  }
  if (!access(PAUSE_FILE, F_OK)) {
    printf("paused\n");
    return 0;
  }

  /* 数据目录不在解包范围内（模块升级会重建模块目录），
     所以首次运行必须自己把它建出来；RUN_DIR 在它下面。 */
  mkdir_p(SF_DATADIR);
  mkdir_p(RUN_DIR);
  tmp_runtime_init();
  log_open();
  log("===== socfreqd %s 启动 pid=%d =====", SF_VERSION, getpid());

  if (acquire_lock()) {
    log("已有实例在运行，本次退出");
    return 0;
  }
  g_stop = 0;
  signal(SIGINT, on_signal);
  signal(SIGTERM, on_signal);
  signal(SIGHUP, SIG_IGN);

  load_cfg();
  g_npol = detect_policies(g_pol);
  g_nraw = detect_policies_raw(g_polraw);
  if (!g_nraw) {
    memcpy(g_polraw, g_pol, sizeof g_pol);
    g_nraw = g_npol;
  }
  for (int i = 0; i < g_npol; i++) { g_pol[i].last_cap = 0; g_pol[i].last_got = 0; }
  if (!g_npol) {
    log("WARN 未探测到 cpufreq policy，本模块不工作");
    return 1;
  }
  cap_backend_init();
  assign_pct(g_pol, g_npol);
  detect_gpu(0);
  suppress_gov_load();   /* adapt/<soc>.conf 的 gov_ 行：有数据才调节工作点 */

  /*
   * 先按持久化快照回收上次崩溃留下的写入，再取新基准。
   * 所有数值写入都走 journal，所以这里恢复出来的就是真正的原始值。
   * 调速器单独走一条：必须先恢复上次运行留下的快照，再取基准；
   * 反过来先把被模块改过的当前值 snapshot 进去，原始调速器就永久丢了。
   */
  journal_restore(NODES_JOURNAL);
  cpuset_restore_all();             /* 上次被 kill -9 时留下的 cpuset 原掩码 */
  suppress_uclamp_max_restore();    /* 上次被 kill -9 时留下的 uclamp.max 原值 */
  bg_light_restore();               /* 上次被 kill -9 时留下的后台分组原值 */
  perms_restore();
  restore_governors();
  if (access(GOV_JOURNAL, F_OK))
    log("WARN 调速器快照未还原，保留到下次启动重试");
  else
    snapshot_governors();

  load_game_pkgs();
  load_app_modes();
  /* 传感器路径的钩子在这里读一次环境变量，之后每轮直接按路径取 */
  adapt_init();
  screen_state_init();
  log("调度策略=%s", cfg.strategy ? "智能（状态机）" : "限频（固定百分比）");
  log("巡检 日常%d s / 游戏%d s / 熄屏%d s，退出宽限 %d s，熄屏策略=%s", cfg.interval,
      cfg.interval * 2, cfg.soff_interval, cfg.grace,
      cfg.screen_policy == SCREEN_UNCAP ? "交还系统"
      : cfg.screen_policy == SCREEN_CAP ? "保持封顶（轻巡检）" : "保持封顶");
  apply_normal(1);
  heartbeat();

  long missing_since = 0; /* 前台丢失的起始秒，0 = 未丢失 */
  long ad_last = 0;       /* 上一次算实时偏移的时刻，用来量真实的巡检间隔 */
  uint64_t seen = cfg_stamp();
  for (; !g_stop;) {
    /* 每轮开头复位：这一轮只要偏移动过，后面几处 apply_normal 就得 force 写 */
    int adapt_changed = 0;
    /* pause 自查：手工 touch pause 与 WebUI 的"暂停"都在一个巡检周期内生效。
     * break 出去走 cleanup()，顺带还原频率、收回权限、删锁文件。 */
    if (!access(PAUSE_FILE, F_OK)) {
      log("检测到 pause，恢复并退出");
      break;
    }
    /* 管理器里停用/卸载只会写标记文件，不会通知已经在跑的守护。
       不自查的话，用户看到的是"停用了还在限频"，直到下次重启。 */
    if (!access(SF_MODDIR "/disable", F_OK) ||
        !access(SF_MODDIR "/remove", F_OK)) {
      log("检测到模块停用/卸载标记，恢复并退出");
      break;
    }
    heartbeat();
    int cfg_changed = reload_if_changed(seen);
    seen = cfg_stamp();
    /* 熄屏轻巡检：SCREEN_OFF 下只读一个亮屏信号，不 popen dumpsys、
       不跑 PSI/温控/学习。SCREEN_POLICY=keep 时整段跳过，行为与旧版一致；
       uncap 与 cap 共用这条轻路径，区别只在进/出熄屏时是否交还封顶。 */
    if (cfg.screen_policy != SCREEN_KEEP) {
      if (g_screen_off) {
        int woke = screen_wake_seen();
        if (!woke && !g_soff_keep) {
          long raw = 0;
          int valid = read_signed(cfg.batt_current_path, &raw);
          long ma = valid ? batt_current_ma(raw, cfg.batt_current_ma_unit) : 0;
          int r = idle_step(&g_idle_ema, &g_idle_hold, ma, valid,
                            cfg.idle_current_ma, cfg.idle_hold_cycle,
                            cfg.wake_delta_ma);
          if (r == 2) {
            /* 电流突增只当"可能亮屏"的提示，必须再用 dumpsys 确认；
               否则后台下载也会把深睡打断。 */
            if (screen_awake()) woke = 1;
            else g_deep = 0;
          } else if (r == 1 && !g_deep) {
            g_deep = 1;
            set_timer_slack(5000000000UL);
            log("进入深度空闲（%d s 轻巡检，电流 %ldmA）", cfg.idle_interval, ma);
          } else if (g_deep && (!valid || ma >= cfg.idle_current_ma)) {
            g_deep = 0;
            set_timer_slack(3000000000UL);
            log("电流回升，回到熄屏巡检");
          }
        }
        if (!woke) {
          if (g_soff_keep) {
            /* keep 应用：不交还，只把被厂商顶高的上限压回去。 */
            caps_patrol(0);
            gpu_patrol();
            /* cap 策略：温控每 4 拍（≈60s）才采一次，只在温度越过阈值时重算封顶，
               其余时间只读两个频率节点。 */
            if (cfg.screen_policy == SCREEN_CAP && ++g_soff_th >= 4) {
              g_soff_th = 0;
              if (adapt_screen_off_tick(&cfg.ad, cfg.soff_interval * 4)) {
                /* 温控只改了 adapt 快照；cap 还是进熄屏时算的旧值。
                   不重算 assign_pct 的话 CPU 帽整夜不动（GPU 走
                   gpu_target() 实时读快照，所以只有 GPU 在降）。 */
                assign_pct(g_pol, g_npol);
                apply_normal(1);
              }
            }
          }
          publish_status();
          sleep(g_deep ? cfg.idle_interval : cfg.soff_interval);
          continue;
        }
        leave_screen_off();
        missing_since = 0;
      }
      /* ACTIVE：先看 sysfs 信号，熄屏后就不必再跑一次 dumpsys window。
         信号说亮时每 60 轮（5 分钟）做一次 dumpsys power 兜底校验，
         信号说灭时立刻复核；熄屏态的无信号兜底仍是每 6 轮。 */
      int verify = (++g_scr_check >= 60);
      if (verify) g_scr_check = 0;
      if (screen_is_off_now(verify)) {
        enter_screen_off();
        missing_since = 0;
        publish_status();
        sleep(cfg.soff_interval);
        continue;
      }
    } else if (g_screen_off) {
      /* 策略被改回 keep：退出轻巡检，让下面的常态路径重新压回。 */
      g_screen_off = 0;
      set_timer_slack(50000UL);
      g_deep = 0;
      g_soff_keep = 0;
      g_soff_pkg[0] = 0;
      g_idle_ema = 0;
      g_idle_hold = 0;
      if (!strcmp(g_state, "full")) apply_normal(1);
    }
    /* 灯亮才算一拍：熄屏轻巡检直接 continue，tick 不涨，
       status 内容才能稳定到"不变就不落盘"。 */
    g_tick_n++;
    /* 实时偏移：每轮读一次 PSI / 最热温度传感器 / 充电态。
     * 生效值变了就把封顶重算一遍，并且这一轮必须 force 写 ——
     * 巡检的判断是 cur<=cap 就跳过，"放宽"这个方向正好落在跳过分支里，
     * 和换应用档位时是同一个坑。 */
    {
      long anow = mono_sec();
      int adt = ad_last ? (int)(anow - ad_last) : cfg.interval;
      if (adt < 1) adt = 1;
      if (adt > 120) adt = 120;          /* 被暂停/长眠隔久了：按上限算，别把整段当成一轮 */
      ad_last = anow;
      /* PSI 基线只在常态更新。以前还要求 delta==0：温度只要停在迟滞带
         （默认 68~75℃）delta 就永远不为 0，基线会被无限期冻结。
         游戏/满血/熄屏仍然不更新；交权态也不推进步进机（adv=0）。 */
      int base_ok = !strcmp(g_state, "normal");
      int adv = base_ok && !g_screen_off;
      /* 智能模式整条冻结 PSI：它已经按逐簇负载给了目标，PSI 再借额度
         只会把目标顶回去；更糟的是 PSI 档位变化会触发 adapt_changed，
         封顶没变也走一遍 force 重写 + 日志。 */
      struct adapt_cfg ac = cfg.ad;
      if (cfg.strategy == 1) ac.psi = 0;
      if (adapt_tick_ex(&ac, adt, base_ok, adv)) {
        struct adapt a;
        adapt_snapshot(&a);
        adapt_changed = 1;
        log("  实时偏移 %+d 个百分点（PSI %d 档 / 温控 %d 档 / %s）",
            effective_delta(&a), a.psi_steps, a.th_steps,
            a.chg_on ? "插电放宽" : "未插电");
      }
    }
    /* 先探前台：智能模式要用"这一拍是否换人"做首拍预热，
       所以前台探测必须早于状态机推进。 */
    char fg[PKG_LEN] = {0};
    load_game_pkgs();
    load_app_modes();
    int fg_rc = foreground_pkg_throttled(fg);
    /* 游戏态下 top-app PID 集合可能没变（小窗和游戏同进程组），
       缓存会一直返回小窗包名；这时直接重探一次，切回游戏才能恢复。 */
    if (fg_rc == 0 && !strcmp(g_state, "game") && !is_game(fg))
      fg_rc = foreground_pkg_throttled_ex(fg, 1);
    int game = fg_rc == 0 && g_npkg && is_game(fg);
    /* 前台包名无条件记下来（命中名单与否都要）。
     * 只在游戏态记的话，页面上"把当前前台设为满血"在相机、地图这些
     * 最需要它的场景里永远是空的。 */
    int fg_changed = fg[0] && strcmp(fg, g_fg) != 0;
    if (fg[0]) snprintf(g_fg, sizeof g_fg, "%s", fg);
    else g_fg[0] = 0;

    /* 配置和偏移都看过之后，统一在这里重算生效封顶。
     * 顺序是有意的：偏移的快照必须先新鲜，否则这里算出来的是旧地板。 */
    /* 智能模式：每拍推进一次状态机。档位变了就走和"配置变了"同一条
       重算路径，保证频率立刻跟上，而不是等下一次配置变更。
       切到游戏的那一拍不预热：马上要交权，预热只会白写一次节点。 */
    int smart_changed = 0;
    if (cfg.strategy == 1) smart_changed = smart_tick(fg_changed && !game);
    if (cfg_changed || adapt_changed || smart_changed) {
      assign_pct(g_pol, g_npol);
      /* 配置变更时压制收口一次：天花板/下限回到新封顶，压制随后
         按新值继续；关闭压制则在此彻底交还。 */
      if (cfg_changed) {
        sup_exit();
        /* 进阶最低频改了：先按账本还原旧下限，再让巡逻按新目标写一次；
           否则把最低频从 50% 改成 0 时，旧下限会一直留着。 */
        cpu_min_restore_user();
        cpu_min_refresh();
      }
      /* 全局分档刚被重算，生效中的应用专属档位要盖回去，
       * 否则保存配置会让正在生效的专属档位静默退回全局百分比。 */
      if (g_app_pct > 0 || g_app_big > 0 || g_app_little > 0)
        set_caps_tiers(g_app_pct, g_app_big, g_app_little,
                       g_app[0] ? g_app : "应用专属");
      if (reclaim_caps_allowed()) apply_normal(1);
    }

    /* 切应用/冷启动时系统会重新写 input_boost_ms 和抬高 GPU 底频；
       检测到前台变化就立刻补写，不等下一拍，缩短拉频窗口。 */
    if (fg_changed && cfg.suppress && !g_sup_chg_pause && !game) {
      suppress_boost_apply();
      suppress_uclamp_apply();
      suppress_extra_apply();
      boost_off_apply();
    }
    /* 切应用时厂商可能顺手重写 cgroup 参数；后台收口随前台变化补一次，
       不跟着 1s/5s 巡检每拍刷节点。 */
    if (fg_changed && cfg.bg_light && !game) bg_light_apply();

    /* 满血窗口：开机后前 N 秒、或（可选）熄屏期间。
     * 顺序有讲究——先算 boot 再算 screen，screen 那条带 dumpsys 开销，
     * 只有开了 SCREEN_UNCAP 才会去读。 */
    int boost = 0;
    const char *bwhy = "-";
    if (cfg.boot_full_s > 0 && boot_boost_active()) { boost = 1; bwhy = "boot"; }
    else if (cfg.screen_policy == SCREEN_KEEP && cfg.screen_uncap &&
             !screen_awake())                        { boost = 1; bwhy = "screen"; }

    if (game) {
      missing_since = 0;
      adapt_cancel();   /* 交权态不攒 PSI/温控档位 */
      if (strcmp(g_game, fg)) {
        snprintf(g_game, sizeof g_game, "%s", fg);
        unlock_game();
      }
      publish_status();
      sleep(cfg.interval * 2);
      continue;
    }

    if (boost) {
      missing_since = 0;
      adapt_cancel();
      if (strcmp(g_state, "game") || strcmp(g_reason, bwhy)) {
        snprintf(g_reason, sizeof g_reason, "%s", bwhy);
        hand_back_full(strcmp(bwhy, "boot") ? "熄屏解除限频，交还系统"
                                            : "开机满血窗口，暂不封顶");
        snprintf(g_state, sizeof g_state, "game");
      }
      publish_status();
      sleep(cfg.interval);
      continue;
    }

    /* 分应用档位。优先级 游戏名单 > 满血窗口 > 应用专属 > 全局百分比：
     * 熄屏解除是用户主动开的全局开关，屏幕都灭了还守着某个应用的 80%
     * 没有意义，所以排在 boost 后面。 */
    int mpct = 0, mbig = 0, mlit = 0, mgpu = 0;
    int has_mode = (!game && !boost && fg[0])
                     ? mode_lookup(fg, &mpct, &mbig, &mlit, &mgpu) : 0;
    int is_full = has_mode && mpct == MODE_FULL;
    /* keep 只影响熄屏：亮屏时按没有专属档位处理，继续走全局分档/学习。 */
    if (has_mode && (mpct == MODE_KEEP || mpct == MODE_SOFF)) has_mode = 0;
    int want_pct = (has_mode && !is_full && mpct > 0) ? mpct : 0;
    int want_big = (has_mode && !is_full) ? mbig : 0;
    int want_little = (has_mode && !is_full) ? mlit : 0;
    int want_gpu = (has_mode && !is_full) ? mgpu : 0;

    if (is_full) {
      missing_since = 0;
      adapt_cancel();
      snprintf(g_fg, sizeof g_fg, "%s", fg);
      /* full 两者都交还；把生效值标成 full/0，离开时才会按全局重新算。
       * 状态里的 app_mode 也因此能报出 full（以前这一支从来没写过它）。 */
      g_app_pct = MODE_FULL;
      g_app_big = 0;
      g_app_little = 0;
      g_app_gpu = 0;
      if (strcmp(g_app, fg) || strcmp(g_state, "game") || strcmp(g_reason, "app")) {
        snprintf(g_app, sizeof g_app, "%s", fg);
        snprintf(g_reason, sizeof g_reason, "app");
        hand_back_full("应用设为满血，交还系统");
        snprintf(g_state, sizeof g_state, "game");
      }
      publish_status();
      sleep(cfg.interval);
      continue;
    }

    /* 封顶档位要不要换：只在数值变了时重算。
     * 换了必须 force 写一遍——巡检的判断是 cur<=cap 就跳过，
     * 从 70% 的应用切到 80% 的应用时新 cap 比当前值大，
     * 正好落在"不用管"的分支里，于是永远停在旧应用的下限上。 */
    int caps_changed = (want_pct != g_app_pct) ||
                       (want_big != g_app_big) ||
                       (want_little != g_app_little);
    int gpu_changed = (want_gpu != g_app_gpu);
    if (caps_changed) {
      set_caps_tiers(want_pct, want_big, want_little,
                     (want_pct || want_big || want_little) ? fg : "全局分档");
      g_app_pct = want_pct;
      g_app_big = want_big;
      g_app_little = want_little;
    }
    g_app_gpu = want_gpu;
    snprintf(g_app, sizeof g_app, "%s", has_mode ? fg : "");
    /* GPU 只换了应用档位、CPU 没换时也要立刻写，巡检只往回压、不会主动升 */
    if (gpu_changed) {
      if (want_gpu > 0) log("  封顶重算（%s 专属 GPU %d%%）", fg, want_gpu);
      else log("  GPU 回到全局 %d%%", cfg.gpu_pct);
      apply_gpu_cap(1);
    }
    if (has_mode) {
      missing_since = 0;
      apply_normal(caps_changed || adapt_changed);
      gpu_patrol();     /* 这一支提前 continue，不巡检的话 Boost 会把 40% 顶回去 */
      publish_status();
      sleep(cfg.interval);
      continue;
    }

    /* 熄屏 / 开机窗口结束：直接压回，不吃"退出宽限"。
     * 那个宽限是给"切后台、弹窗造成前台包名短暂丢失"用的，
     * 满血窗口是明确到点的，多等 10 秒只会让人以为没生效。 */
    if (!strcmp(g_state, "game") && strcmp(g_reason, "game")) {
      /* 这一支同时兜"满血窗口到期"和"离开满血应用"两种：
       * 都是已交还系统要压回封顶，但原因不同，日志要分得开——
       * 排查时"应用档位没生效"和"开机窗口没结束"是完全不同的方向。 */
      log("%s，压回常态封顶", !strcmp(g_reason, "app") ? "离开满血应用"
                                                       : "满血窗口结束");
      g_game[0] = 0;
      g_app[0] = 0;
      apply_normal(1);
    }

    if (!strcmp(g_state, "game")) {
      /* 迟滞：切后台/弹窗造成的短暂丢失不立刻收回 */
      if (!missing_since) {
        missing_since = mono_sec();
        log("  游戏离开前台，%d s 内仍保持解锁", cfg.grace);
      } else if (mono_sec() - missing_since >= cfg.grace) {
        g_game[0] = 0;
        log("游戏已离开前台，复位到常态封顶");
        apply_normal(1);
      }
    } else {
      missing_since = 0;
      /*
       * 稳态巡检：CPU 上限也必须压回来。
       * 厂商侧（perfd / fpsgo / 热管控）会把 scaling_max_freq 抬回硬件最高，
       * 这里不调 apply_normal 就永远没人管，只能等改配置或进出游戏才恢复。
       * force=0：状态没变，走 RESTORE 分支，不重复做"→ 常态封顶"那套。
       */
      /* force 带上 caps_changed：封顶档位这一轮刚换过（离开专属应用回到全局），
       * 走巡检的 cur<=cap 就跳过这条，新（更高）的 cap 就永远写不上去。
       * adapt_changed 同理，而且更常见：PSI 借出额度、或凉下来还档，都是升档。 */
      apply_normal(caps_changed || adapt_changed);
      gpu_patrol();
      /* 工作点参数周期性补应用：系统会动态切 walt↔scx，切走的窗口里
         walt 节点消失、这里自动跳过；切回后 5s 内重新生效（幂等：
         值相同不写）。 */
      suppress_gov_apply();
    }
    publish_status();
    /* 动态封顶：亮屏常态把长睡切成 1s 快拍（快拍里只做压制与压回），
       其余路径维持原节奏；熄屏/游戏/满血分支各自 continue，不经过这里。
       插电时暂停：插电不封顶是既定策略，压制的相对阶梯此时会把满频
       又按 80% 压住，与策略矛盾——交还并记暂停，拔电下一拍自动恢复。 */
    {
      struct adapt a;
      adapt_snapshot(&a);
      if (cfg.suppress && !a.chg_on) {
        if (g_sup_chg_pause) {
          g_sup_chg_pause = 0;
          log("动态封顶：拔电恢复");
          /* 充电期间交还过 boost/uclamp；拔电立刻补回，不能等下一次状态变化 */
          suppress_boost_apply();
          suppress_smooth_apply();
          suppress_uclamp_apply();
          suppress_extra_apply();
          g_sup_reapply_at = mono_sec();
        }
        for (int k = 0; k < cfg.interval && !g_stop; k++) {
          suppress_tick();
          sleep(1);
        }
      } else {
        if (cfg.suppress && !g_sup_chg_pause) {
          sup_exit();
          g_sup_chg_pause = 1;
          log("动态封顶：充电中暂停（插电不封顶）");
        }
        sleep(cfg.interval);
      }
    }
  }

  cleanup();
  return 0;
}
#endif /* !SF_TEST */